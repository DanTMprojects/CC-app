import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { createPageUrl } from '@/utils';
import { findOrCreateThread, dedupeThreads, isThreadBetweenProfiles } from '@/components/utils/threadUtils';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Search, Users, Loader2 } from 'lucide-react';
import TradeCard from '@/components/cards/TradeCard';
import ProfileCardModal from '@/components/cards/ProfileCardModal';
import NewThreadModal from '@/components/messaging/NewThreadModal';
import ThreadSelectionModal from '@/components/messaging/ThreadSelectionModal';

export default function Rolodex() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [myProfile, setMyProfile] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [showNewThread, setShowNewThread] = useState(false);
  const [messageTarget, setMessageTarget] = useState(null);
  const [showThreadSelection, setShowThreadSelection] = useState(false);
  const [selectedContactThreads, setSelectedContactThreads] = useState([]);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    
    const profiles = await base44.entities.TradeProfile.filter({
      created_by: currentUser.email
    });
    if (profiles.length > 0) {
      setMyProfile(profiles[0]);
    }
  };

  const { data: connections = [], isLoading } = useQuery({
    queryKey: ['myConnections', user?.id],
    queryFn: () => base44.entities.RolodexConnection.filter({ owner_user_id: user?.id }),
    enabled: !!user
  });

  const { data: profiles = [] } = useQuery({
    queryKey: ['connectionProfiles', connections],
    queryFn: async () => {
      const profileIds = connections.map(c => c.contact_profile_id);
      if (profileIds.length === 0) return [];
      
      const allProfiles = await base44.entities.TradeProfile.list();
      return allProfiles.filter(p => profileIds.includes(p.id));
    },
    enabled: connections.length > 0
  });

  const filteredProfiles = useMemo(() => {
    return profiles.filter(profile => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return (
        profile.company_name?.toLowerCase().includes(query) ||
        profile.owner_name?.toLowerCase().includes(query)
      );
    });
  }, [profiles, searchQuery]);

  const handleMessage = useCallback((profile) => {
    setMessageTarget(profile);
    setShowNewThread(true);
    setSelectedProfile(null);
  }, []);

  const handleCreateThread = useCallback(async (projectName) => {
    const thread = await findOrCreateThread({
      projectName,
      currentUserEmail: user.email,
      contactUserEmail: messageTarget.created_by,
      currentProfileId: myProfile.id,
      contactProfileId: messageTarget.id,
    });

    setShowNewThread(false);
    navigate(createPageUrl('Messages') + `?thread=${thread.id}`);
  }, [user?.email, messageTarget, myProfile, navigate]);

  const handleShare = useCallback((profile) => {
    const inviteUrl = `${window.location.origin}${createPageUrl('Onboarding')}?invite=${profile.invite_code}`;
    navigator.clipboard.writeText(inviteUrl);
    alert('Invite link copied to clipboard!');
  }, []);

  const removeFromRolodex = useCallback(async (profile) => {
    const connections = await base44.entities.RolodexConnection.filter({
      owner_user_id: user.id,
      contact_profile_id: profile.id
    });
    if (connections.length > 0) {
      await base44.entities.RolodexConnection.delete(connections[0].id);
      queryClient.invalidateQueries(['myConnections']);
    }
  }, [user?.id, queryClient]);

  const handleViewMessages = useCallback(async (profile) => {
    if (!user?.email || !myProfile?.id || !profile?.id) return;

    // 1. Get ALL threads where my profile participates
    const threadsAsA = await base44.entities.ProjectThread.filter({
      user_a_profile_id: myProfile.id,
    });

    const threadsAsB = await base44.entities.ProjectThread.filter({
      user_b_profile_id: myProfile.id,
    });

    const allMyThreads = [...threadsAsA, ...threadsAsB];

    // 2. Filter to ONLY threads between my profile and this contact's profile
    const betweenUs = allMyThreads.filter((t) =>
      isThreadBetweenProfiles(t, myProfile.id, profile.id)
    );

    // Temporary diagnostic log (remove after verification)
    console.log('Rolodex messages for', profile.company_name, {
      currentProfileId: myProfile.id,
      contactProfileId: profile.id,
      threads: betweenUs.map(t => ({
        id: t.id,
        project_name: t.project_name,
        user_a_profile_id: t.user_a_profile_id,
        user_b_profile_id: t.user_b_profile_id,
      })),
    });

    // 3. Dedupe and sort newest → oldest
    const deduped = dedupeThreads(betweenUs);

    const sorted = deduped.sort(
      (a, b) =>
        new Date(b.last_message_at || b.created_date) -
        new Date(a.last_message_at || a.created_date)
    );

    // 4. Set modal state
    setMessageTarget(profile);
    setSelectedContactThreads(sorted);
    setShowThreadSelection(true);
  }, [user?.email, myProfile?.id]);

  const handleSelectThread = useCallback((thread) => {
    setShowThreadSelection(false);
    navigate(createPageUrl('Messages') + `?thread=${thread.id}`);
  }, [navigate]);

  const handleNewThreadFromSelection = useCallback(() => {
    setShowThreadSelection(false);
    setShowNewThread(true);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-4">
            <Link to={createPageUrl('Dashboard')} className="p-2 -ml-2 hover:bg-slate-100 rounded-xl transition-colors">
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </Link>
            <h1 className="text-xl font-bold text-slate-900">My Rolodex</h1>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search contacts..."
              className="pl-10 h-11 bg-slate-50 border-slate-200"
            />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
          </div>
        ) : filteredProfiles.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {filteredProfiles.map((profile) => (
              <TradeCard
                key={profile.id}
                profile={profile}
                onView={setSelectedProfile}
                onAdd={() => {}}
                onRemove={removeFromRolodex}
                onViewMessages={handleViewMessages}
                isInRolodex={true}
              />
            ))}
          </div>
        ) : connections.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-7 h-7 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-1">No contacts yet</h3>
            <p className="text-slate-500 mb-6">Start exploring and add trades to your Rolodex</p>
            <Link
              to={createPageUrl('Explore')}
              className="inline-flex items-center justify-center h-11 px-6 bg-slate-900 text-white rounded-xl font-medium hover:bg-slate-800 transition-colors"
            >
              Explore Trades
            </Link>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-slate-500">No contacts match your search</p>
          </div>
        )}
      </div>

      <ProfileCardModal
        profile={selectedProfile}
        isOpen={!!selectedProfile}
        onClose={() => setSelectedProfile(null)}
        onMessage={handleMessage}
        onAdd={() => {}}
        onRemove={(p) => { removeFromRolodex(p); setSelectedProfile(null); }}
        onShare={handleShare}
        isInRolodex={true}
      />

      <ThreadSelectionModal
        isOpen={showThreadSelection}
        onClose={() => setShowThreadSelection(false)}
        contactProfile={messageTarget}
        threads={selectedContactThreads}
        onSelectThread={handleSelectThread}
        onNewThread={handleNewThreadFromSelection}
      />

      <NewThreadModal
        isOpen={showNewThread}
        onClose={() => setShowNewThread(false)}
        contactProfile={messageTarget}
        onCreateThread={handleCreateThread}
      />
    </div>
  );
}