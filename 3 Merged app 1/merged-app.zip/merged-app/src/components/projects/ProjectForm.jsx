import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Upload, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { base44 } from '@/api/base44Client';
import { MOCK_TEAM_MEMBERS } from "@/components/config/mockData";

const trades = [
  { value: "electrician", label: "Electrical" },
  { value: "plumber", label: "Plumbing" },
  { value: "carpenter", label: "Carpentry" },
  { value: "hvac", label: "HVAC" },
  { value: "painter", label: "Paint" },
  { value: "roofer", label: "Roofing" },
  { value: "mason", label: "Masonry" },
  { value: "landscaper", label: "Landscaping" },
  { value: "flooring", label: "Flooring" },
  { value: "drywall", label: "Drywall" },
  { value: "other", label: "Other" }
];

export default function ProjectForm({ project, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(project || {
    name: "",
    status: "pending",
    trades: [],
    team_emails: [],
    scope_of_work: "",
    house_plan_url: ""
  });
  const [newEmail, setNewEmail] = useState("");
  const [uploading, setUploading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addTrade = (trade) => {
    if (!formData.trades.includes(trade)) {
      setFormData({ ...formData, trades: [...formData.trades, trade] });
    }
  };

  const removeTrade = (trade) => {
    setFormData({ ...formData, trades: formData.trades.filter(t => t !== trade) });
  };

  const addTeamMember = () => {
    if (newEmail && !formData.team_emails.includes(newEmail)) {
      setFormData({ ...formData, team_emails: [...formData.team_emails, newEmail] });
      setNewEmail("");
    }
  };

  const removeTeamMember = (email) => {
    setFormData({ ...formData, team_emails: formData.team_emails.filter(e => e !== email) });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData({ ...formData, house_plan_url: file_url });
    } catch (error) {
      console.error('Failed to upload file:', error);
    }
    setUploading(false);
  };

  const removeFile = () => {
    setFormData({ ...formData, house_plan_url: "" });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-slate-900">
          {project ? "Edit Project" : "New Project"}
        </h2>
        <Button type="button" variant="ghost" size="icon" onClick={onCancel}>
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="space-y-2">
        <Label htmlFor="name">Project Address *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g., 123 Main St"
          required
          className="h-11"
        />
      </div>

      <div className="space-y-2">
        <Label>Status</Label>
        <Select
          value={formData.status}
          onValueChange={(value) => setFormData({ ...formData, status: value })}
        >
          <SelectTrigger className="h-11">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Trades Involved</Label>
        <Select onValueChange={addTrade}>
          <SelectTrigger className="h-11">
            <SelectValue placeholder="Add a trade" />
          </SelectTrigger>
          <SelectContent>
            {trades.filter(t => !formData.trades.includes(t.value)).map((trade) => (
              <SelectItem key={trade.value} value={trade.value}>
                {trade.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {formData.trades.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.trades.map((trade) => (
              <Badge key={trade} variant="secondary" className="py-1 px-3">
                {trades.find(t => t.value === trade)?.label || trade}
                <button type="button" onClick={() => removeTrade(trade)} className="ml-2">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-2">
        <Label>Team Members (Email)</Label>
        <div className="flex gap-2 mb-2">
          <Button 
            type="button" 
            onClick={() => {
              const mockEmails = MOCK_TEAM_MEMBERS.map(m => m.email);
              const uniqueEmails = [...new Set([...formData.team_emails, ...mockEmails])];
              setFormData({ ...formData, team_emails: uniqueEmails });
            }}
            variant="outline"
            size="sm"
            className="text-xs"
          >
            + Add Test Team
          </Button>
        </div>
        <div className="flex gap-2">
          <Input
            value={newEmail}
            onChange={(e) => setNewEmail(e.target.value)}
            placeholder="trade@email.com"
            type="email"
            className="h-11"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addTeamMember();
              }
            }}
          />
          <Button type="button" onClick={addTeamMember} variant="outline" className="h-11">
            Add
          </Button>
        </div>
        {formData.team_emails.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.team_emails.map((email) => (
              <Badge key={email} variant="secondary" className="py-1 px-3">
                {email}
                <button type="button" onClick={() => removeTeamMember(email)} className="ml-2">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="scope">Scope of Work</Label>
        <Input
          id="scope"
          value={formData.scope_of_work}
          onChange={(e) => setFormData({ ...formData, scope_of_work: e.target.value })}
          placeholder="Brief description of work"
          className="h-11"
        />
      </div>

      <div className="space-y-2">
        <Label>Attach Files</Label>
        <input
          type="file"
          onChange={handleFileUpload}
          className="hidden"
          id="file-upload"
          disabled={uploading}
        />
        {!formData.house_plan_url ? (
          <label htmlFor="file-upload">
            <div className="flex items-center justify-center gap-2 h-11 px-4 border-2 border-dashed border-slate-300 rounded-lg hover:border-slate-400 hover:bg-slate-50 cursor-pointer transition-colors">
              <Upload className="w-4 h-4 text-slate-500" />
              <span className="text-sm text-slate-600">
                {uploading ? "Uploading..." : "Upload house plans or documents"}
              </span>
            </div>
          </label>
        ) : (
          <div className="flex items-center gap-2 p-3 border border-slate-200 rounded-lg bg-slate-50">
            <FileText className="w-4 h-4 text-slate-600" />
            <span className="text-sm text-slate-700 flex-1">File attached</span>
            <button type="button" onClick={removeFile} className="text-slate-500 hover:text-slate-700">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1 h-11">
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading} className="flex-1 h-11 bg-slate-900 hover:bg-slate-800">
          {isLoading ? "Saving..." : project ? "Update" : "Create"}
        </Button>
      </div>
    </form>
  );
}