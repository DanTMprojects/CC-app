import React, { useState } from 'react';
import { MapPin, Building2, Trash2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import moment from 'moment';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function ThreadItem({ thread, contactProfile, onClick, isActive, onDelete, unreadCount = 0 }) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);

  const confirmDelete = (e) => {
    e.stopPropagation();
    onDelete(thread);
    setShowDeleteDialog(false);
  };

  return (
    <>
      <button
      onClick={onClick}
      className={`w-full p-4 text-left transition-all relative group border-l-4 ${
        isActive 
          ? 'bg-slate-100 border-l-blue-500' 
          : 'bg-white hover:bg-slate-50 border-l-transparent'
      }`}
    >
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
          {contactProfile?.profile_photo_url ? (
            <img 
              src={contactProfile.profile_photo_url} 
              alt={contactProfile.company_name}
              className="w-full h-full object-cover rounded-xl"
            />
          ) : (
            <Building2 className="w-5 h-5 text-slate-400" />
          )}
        </div>

        <div className="flex-1 min-w-0 pr-2">
          <div className="flex items-start justify-between gap-3 mb-1">
            <p className="font-medium text-slate-900 flex items-center gap-1.5 flex-1 min-w-0">
              <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <span className="truncate">{thread.project_name}</span>
            </p>
            
            <div className="flex items-center gap-2 flex-shrink-0">
              {thread.last_message_at && (
                <span className="text-xs text-slate-400 whitespace-nowrap">
                  {moment(thread.last_message_at).fromNow()}
                </span>
              )}
              {unreadCount > 0 && (
                <span className="inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-blue-500 text-white text-xs font-medium">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
              <div
                onClick={(e) => {
                  e.stopPropagation();
                  setShowDeleteDialog(true);
                }}
                className="p-1.5 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-red-50 transition-all"
              >
                <Trash2 className="w-4 h-4 text-red-500" />
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <p className="text-sm text-slate-500 truncate">
              {contactProfile?.company_name}
            </p>
            {contactProfile?.trade_category && (
              <Badge variant="secondary" className="text-xs flex-shrink-0">
                {contactProfile.trade_category.replace(/_/g, ' ')}
              </Badge>
            )}
          </div>
          
          {thread.last_message && (
            <p className={`text-sm mt-1 truncate ${unreadCount > 0 ? 'text-slate-900 font-medium' : 'text-slate-500'}`}>
              {thread.last_message}
            </p>
          )}
        </div>
      </div>
    </button>

    <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete conversation?</AlertDialogTitle>
          <AlertDialogDescription>
            This will permanently delete this conversation and all its messages. This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={(e) => e.stopPropagation()}>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
}