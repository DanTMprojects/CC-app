import React from 'react';
import Layout from './Layout.jsx';

// Import all page components. When adding new pages, be sure to
// include them here and update the route configuration in
// `src/components/config/routes.jsx` accordingly.
import Onboarding from './Onboarding';
import Dashboard from './Dashboard';
import Explore from './Explore';
import Rolodex from './Rolodex';
import Messages from './Messages';
import MyCard from './MyCard';
import Projects from './Projects';
import Directory from './Directory';
import Profile from './Profile';
import ProjectDetail from './ProjectDetail';
import DemoProject from './DemoProject';

import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
  useLocation,
} from 'react-router-dom';

import { APP_ROUTES } from '@/components/config/routes';

// Map route names to components. This lookup table allows the routing
// logic to remain declarative while still supporting computed
// navigation highlighting.
const PAGE_COMPONENTS = {
  Onboarding,
  Dashboard,
  Explore,
  Rolodex,
  Messages,
  MyCard,
  Projects,
  Directory,
  Profile,
  ProjectDetail,
  DemoProject,
};

// Determine the current page name based on the browser pathname. This
// helper matches the start of the pathname against the configured
// route paths and returns the associated route name. If no match is
// found the first route in APP_ROUTES is used as a default.
function getCurrentPageName(pathname) {
  for (const route of APP_ROUTES) {
    if (pathname.startsWith(route.path)) {
      return route.name;
    }
  }
  return APP_ROUTES[0].name;
}

function PagesContent() {
  const location = useLocation();
  const currentPageName = getCurrentPageName(location.pathname);

  return (
    <Layout currentPageName={currentPageName}>
      <Routes>
        {/* Define a route for every page declared in APP_ROUTES */}
        {APP_ROUTES.map((route) => {
          const Component = PAGE_COMPONENTS[route.name];
          // Skip any route that does not have a corresponding component.
          if (!Component) return null;
          return (
            <Route key={route.path} path={route.path} element={<Component />} />
          );
        })}
        {/* Provide a default redirect for unmatched routes. */}
        <Route path="/" element={<Navigate to={APP_ROUTES[0].path} replace />} />
        <Route path="*" element={<Navigate to={APP_ROUTES[0].path} replace />} />
      </Routes>
    </Layout>
  );
}

export default function Pages() {
  return (
    <Router>
      <PagesContent />
    </Router>
  );
}