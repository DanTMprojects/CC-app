import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Paperclip, FileText, X } from "lucide-react";
import { base44 } from '@/api/base44Client';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function BidSubmissionDialog({ open, onOpenChange, onSubmit, isLoading, jobTitle }) {
  const [formData, setFormData] = useState({
    amount: "",
    notes: "",
    file_url: ""
  });
  const [uploadingFile, setUploadingFile] = useState(false);
  const [fileName, setFileName] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData({ amount: "", notes: "", file_url: "" });
    setFileName("");
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setUploadingFile(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, file_url }));
      setFileName(file.name);
    } catch (error) {
      console.error('Failed to upload file:', error);
    }
    setUploadingFile(false);
  };

  const removeFile = () => {
    setFormData(prev => ({ ...prev, file_url: "" }));
    setFileName("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-white">
        <DialogHeader>
          <DialogTitle className="text-slate-900">Submit Bid</DialogTitle>
          <p className="text-sm text-slate-600">{jobTitle}</p>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Bid Amount ($) *</Label>
            <Input
              id="amount"
              type="number"
              min="0"
              step="0.01"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
              placeholder="e.g., 5000"
              required
              className="h-11"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Message (Optional)</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Add any details about your bid..."
              className="min-h-[80px]"
            />
          </div>

          <div className="space-y-2">
            <Label>Attach Files (Optional)</Label>
            <input
              type="file"
              onChange={handleFileUpload}
              className="hidden"
              id="bid-file-upload"
              disabled={uploadingFile}
            />
            {!formData.file_url ? (
              <label htmlFor="bid-file-upload">
                <div className="flex items-center justify-center gap-2 h-11 px-4 border-2 border-dashed border-slate-300 rounded-lg hover:border-slate-400 hover:bg-slate-50 cursor-pointer transition-colors">
                  <Paperclip className="w-4 h-4 text-slate-500" />
                  <span className="text-sm text-slate-600">
                    {uploadingFile ? "Uploading..." : "Upload breakdown or documents"}
                  </span>
                </div>
              </label>
            ) : (
              <div className="flex items-center gap-2 p-3 border border-slate-200 rounded-lg bg-slate-50">
                <FileText className="w-4 h-4 text-slate-600" />
                <span className="text-sm text-slate-700 flex-1">{fileName}</span>
                <button type="button" onClick={removeFile} className="text-slate-500 hover:text-slate-700">
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          <div className="flex gap-3 pt-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => onOpenChange(false)} 
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading || !formData.amount} 
              className="flex-1 bg-slate-900 hover:bg-slate-800"
            >
              {isLoading ? "Submitting..." : "Submit Bid"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}