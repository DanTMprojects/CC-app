import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { dedupeThreads } from '@/components/utils/threadUtils';
import {
  Search,
  MessageSquare,
  BookOpen,
  UserCircle,
  ArrowRight,
  Loader2,
} from 'lucide-react';

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    loadUser();
  }, []);

  const {
    data: messageSummary,
    isLoading: messagesLoading,
  } = useQuery({
    queryKey: ['dashboardThreadsSummary', user?.email],
    enabled: !!user?.email,
    queryFn: async () => {
      const currentUser = await base44.auth.me();

      const threadsAsUserA = await base44.entities.ProjectThread.filter({
        user_a_id: currentUser.email,
      });
      const threadsAsUserB = await base44.entities.ProjectThread.filter({
        user_b_id: currentUser.email,
      });

      const threads = dedupeThreads([
        ...threadsAsUserA,
        ...threadsAsUserB,
      ]);

      let unreadTotal = 0;

      threads.forEach((thread) => {
        const isUserA = thread.user_a_id === currentUser.email;
        const archived = isUserA
          ? !!thread.archived_by_a
          : !!thread.archived_by_b;

        if (archived) return;

        const myUnread = isUserA
          ? thread.unread_count_a || 0
          : thread.unread_count_b || 0;

        unreadTotal += myUnread;
      });

      return { threads, unreadTotal };
    },
  });

  const unreadCount = messageSummary?.unreadTotal || 0;

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Header */}
        <header className="mb-6">
          <h1 className="text-2xl font-semibold text-slate-900">
            TradeRolodex
          </h1>
          <p className="mt-1 text-sm text-slate-500">
            {user ? `Welcome back, ${user.name || user.email}` : 'Loading...'}
          </p>
        </header>

        {/* Main cards */}
        <div className="space-y-3 mb-8">
          {/* Explore Trades */}
          <Link
            to={createPageUrl('Explore')}
            className="block rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow px-4 py-3"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-500 flex items-center justify-center">
                  <Search className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">
                    Explore Trades
                  </p>
                  <p className="text-sm text-slate-500">
                    Discover contractors and trades nearby
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-300" />
            </div>
          </Link>

          {/* My Rolodex */}
          <Link
            to={createPageUrl('Rolodex')}
            className="block rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow px-4 py-3"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">
                    My Rolodex
                  </p>
                  <p className="text-sm text-slate-500">
                    Your saved connections
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-300" />
            </div>
          </Link>

          {/* Messages */}
          <Link
            to={createPageUrl('Messages')}
            className="block rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow px-4 py-3"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500 flex items-center justify-center relative">
                  <MessageSquare className="w-5 h-5 text-white" />
                  {/* Badge */}
                  {messagesLoading ? (
                    <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-white flex items-center justify-center">
                      <Loader2 className="w-3 h-3 text-purple-500 animate-spin" />
                    </div>
                  ) : unreadCount > 0 ? (
                    <div className="absolute -top-1 -right-1 min-w-[18px] h-[18px] rounded-full bg-red-500 text-[10px] text-white flex items-center justify-center px-1">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </div>
                  ) : null}
                </div>
                <div>
                  <p className="font-medium text-slate-900 flex items-center gap-2">
                    Messages
                    {!messagesLoading && unreadCount > 0 && (
                      <span className="inline-flex items-center justify-center rounded-full bg-red-100 text-red-600 text-[11px] px-2 py-0.5">
                        {unreadCount} unread
                      </span>
                    )}
                  </p>
                  <p className="text-sm text-slate-500">
                    Project conversations
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-300" />
            </div>
          </Link>

          {/* My Card */}
          <Link
            to={createPageUrl('MyCard')}
            className="block rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow px-4 py-3"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center">
                  <UserCircle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <p className="font-medium text-slate-900">
                    My Card
                  </p>
                  <p className="text-sm text-slate-500">
                    View and edit your profile
                  </p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-300" />
            </div>
          </Link>
        </div>

        {/* Quick Actions */}
        <section>
          <h2 className="text-sm font-medium text-slate-700 mb-2">
            Quick Actions
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Link
              to={createPageUrl('Explore')}
              className="flex items-center justify-center rounded-2xl bg-white border border-slate-100 py-4 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-2 text-slate-700 text-sm">
                <Search className="w-4 h-4" />
                <span>Find Trades</span>
              </div>
            </Link>
            <Link
              to={createPageUrl('Rolodex')}
              className="flex items-center justify-center rounded-2xl bg-white border border-slate-100 py-4 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-2 text-slate-700 text-sm">
                <MessageSquare className="w-4 h-4" />
                <span>Invite Contact</span>
              </div>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
}