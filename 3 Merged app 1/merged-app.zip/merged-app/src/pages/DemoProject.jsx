import React, { useState } from "react";
import { ArrowLeft, MessageSquare, Calendar, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const DEMO_PROJECT = {
  name: "115 Saluda St – Duplex build",
  address: "115 Saluda St, Spartanburg, SC",
  gcName: "Prime Builders Group",
  clientName: "John & Sarah Doe",
};

const DEMO_MESSAGES = [
  {
    id: 1,
    author: "GC · Prime Builders",
    role: "gc",
    text: "Hey team, this thread is just for 115 Saluda duplex. Please post all updates here.",
    timestamp: "Mon 8:02 AM",
  },
  {
    id: 2,
    author: "Elite Electrical",
    role: "trade",
    text: "Got it. We're planning rough-in for Thursday. Need final lighting plan confirmed by tomorrow.",
    timestamp: "Mon 8:15 AM",
  },
  {
    id: 3,
    author: "GC · Prime Builders",
    role: "gc",
    text: "Lighting plan is in the shared folder. Please confirm counts on kitchen cans.",
    timestamp: "Mon 8:20 AM",
  },
  {
    id: 4,
    author: "Elite Electrical",
    role: "trade",
    text: "Saw it – 12 cans in kitchen, 6 pendants over island. Will send material list EOD.",
    timestamp: "Mon 8:37 AM",
  },
];

const DEMO_SCHEDULE = [
  { id: 1, label: "Excavation + footings", date: "Mon 10/14" },
  { id: 2, label: "Framing start", date: "Thu 10/17" },
  { id: 3, label: "Electrical rough-in", date: "Thu 10/24" },
];

export default function DemoProject() {
  const [activeTab, setActiveTab] = useState("messages");
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      <div className="max-w-5xl mx-auto px-4 py-4 space-y-4">
        <header className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full border border-slate-800"
              onClick={() => navigate(createPageUrl("Projects"))}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-sm font-semibold">{DEMO_PROJECT.name}</h1>
              <p className="text-[11px] text-slate-400">
                {DEMO_PROJECT.address}
              </p>
            </div>
          </div>
        </header>

        <section className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 text-sm">
          <div className="flex flex-wrap gap-4 text-xs text-slate-300">
            <div>
              <p className="text-[11px] uppercase tracking-wide text-slate-500">
                General contractor
              </p>
              <p>{DEMO_PROJECT.gcName}</p>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-wide text-slate-500">
                Homeowner
              </p>
              <p>{DEMO_PROJECT.clientName}</p>
            </div>
          </div>
        </section>

        <section className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4">
          <div className="flex gap-2 text-xs border-b border-slate-800 mb-3">
            <button
              type="button"
              onClick={() => setActiveTab("messages")}
              className={cn(
                "inline-flex items-center gap-1 px-3 py-2 border-b-2 -mb-px",
                activeTab === "messages"
                  ? "border-sky-500 text-sky-100"
                  : "border-transparent text-slate-400 hover:text-slate-100"
              )}
            >
              <MessageSquare className="w-3 h-3" />
              Messages
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("schedule")}
              className={cn(
                "inline-flex items-center gap-1 px-3 py-2 border-b-2 -mb-px",
                activeTab === "schedule"
                  ? "border-sky-500 text-sky-100"
                  : "border-transparent text-slate-400 hover:text-slate-100"
              )}
            >
              <Calendar className="w-3 h-3" />
              Schedule
            </button>
          </div>

          {activeTab === "messages" && (
            <div className="space-y-3">
              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {DEMO_MESSAGES.map((msg) => (
                  <div
                    key={msg.id}
                    className={cn(
                      "rounded-xl border px-3 py-2 text-xs max-w-[80%]",
                      msg.role === "gc"
                        ? "ml-auto bg-sky-500/10 border-sky-500/50 text-sky-50"
                        : "mr-auto bg-slate-950 border-slate-700 text-slate-100"
                    )}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <span className="font-medium">{msg.author}</span>
                      <span className="text-[10px] text-slate-400">
                        {msg.timestamp}
                      </span>
                    </div>
                    <p className="leading-relaxed">{msg.text}</p>
                  </div>
                ))}
              </div>

              <div className="mt-3 border-t border-slate-800 pt-3">
                <p className="text-[11px] text-slate-500 mb-1">
                  In the real project view, you'll type here to chat with your
                  trades or GC. This demo composer is disabled.
                </p>
                <Textarea
                  disabled
                  placeholder="Message your team about this job…"
                  className="bg-slate-950 border-slate-800 text-xs text-slate-400"
                  rows={3}
                />
                <div className="mt-2 flex justify-end">
                  <Button
                    size="sm"
                    disabled
                    className="h-8 rounded-full bg-sky-500/40 text-[11px]"
                  >
                    <Send className="w-3 h-3 mr-1" />
                    Send (demo)
                  </Button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "schedule" && (
            <div className="space-y-3 text-xs">
              <p className="text-slate-400 mb-1">
                Example milestones for this job:
              </p>
              <ul className="space-y-2">
                {DEMO_SCHEDULE.map((item) => (
                  <li
                    key={item.id}
                    className="flex items-center justify-between rounded-lg bg-slate-950 border border-slate-800 px-3 py-2"
                  >
                    <span className="text-slate-100">{item.label}</span>
                    <span className="text-[11px] text-slate-400">
                      {item.date}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}