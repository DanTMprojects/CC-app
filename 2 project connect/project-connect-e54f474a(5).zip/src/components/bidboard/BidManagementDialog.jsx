import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { FileText, X, Check } from "lucide-react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function BidManagementDialog({ open, onOpenChange, job, bids, onUpdateBid, isLoading }) {
  const statusColors = {
    pending: "bg-yellow-100 text-yellow-800 border-yellow-300",
    accepted: "bg-green-100 text-green-800 border-green-300",
    rejected: "bg-red-100 text-red-800 border-red-300"
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl bg-white max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-slate-900">Manage Bids</DialogTitle>
          <p className="text-sm text-slate-600">{job?.title}</p>
        </DialogHeader>
        
        <ScrollArea className="max-h-[60vh] pr-4">
          <div className="space-y-4 pt-4">
            {bids.length === 0 ? (
              <div className="text-center py-8 text-sm text-slate-600">
                No bids received yet
              </div>
            ) : (
              bids.map((bid) => (
                <div key={bid.id} className="border border-slate-200 rounded-lg p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium text-slate-900">{bid.bidder_name}</p>
                      <p className="text-xs text-slate-500">
                        {format(new Date(bid.created_date), "MMM d, yyyy 'at' h:mm a")}
                      </p>
                    </div>
                    <Badge className={`${statusColors[bid.status]} border`}>
                      {bid.status}
                    </Badge>
                  </div>

                  <div className="bg-slate-50 rounded-lg p-3">
                    <p className="text-2xl font-bold text-slate-900">
                      ${bid.amount.toLocaleString()}
                    </p>
                  </div>

                  {bid.notes && (
                    <div>
                      <p className="text-xs font-medium text-slate-700 mb-1">Message:</p>
                      <p className="text-sm text-slate-600 bg-slate-50 rounded p-2">
                        {bid.notes}
                      </p>
                    </div>
                  )}

                  {bid.file_url && (
                    <a 
                      href={bid.file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 p-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-sm"
                    >
                      <FileText className="w-4 h-4 text-slate-600" />
                      <span className="text-slate-700">View attached documents</span>
                    </a>
                  )}

                  {bid.status === 'pending' && (
                    <div className="flex gap-2 pt-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onUpdateBid(bid.id, 'rejected')}
                        disabled={isLoading}
                        className="flex-1 border-red-200 text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4 mr-1" />
                        Reject
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => onUpdateBid(bid.id, 'accepted')}
                        disabled={isLoading}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        <Check className="w-4 h-4 mr-1" />
                        Accept
                      </Button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}