import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const Message = base44.entities.Message;

export const Schedule = base44.entities.Schedule;

export const Review = base44.entities.Review;

export const Bid = base44.entities.Bid;



// auth sdk:
export const User = base44.auth;