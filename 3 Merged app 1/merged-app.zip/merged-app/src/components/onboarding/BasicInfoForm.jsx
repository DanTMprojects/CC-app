import React from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Building2, User, Mail, Phone, MapPin, Globe, FileText, X, FileCheck } from 'lucide-react';

const TRADE_GROUPS = [
  {
    value: 'site_earthwork',
    label: 'Site & Earthwork',
    tags: [
      { value: 'excavation', label: 'Excavation' },
      { value: 'grading', label: 'Grading' },
      { value: 'demolition', label: 'Demolition' },
      { value: 'land_clearing', label: 'Land Clearing' },
      { value: 'site_prep', label: 'Site Prep' },
      { value: 'underground_utilities', label: 'Underground Utilities' },
      { value: 'septic_installation', label: 'Septic Installation' },
      { value: 'asphalt_paving', label: 'Asphalt / Paving' },
      { value: 'concrete', label: 'Concrete' },
    ]
  },
  {
    value: 'structural_exterior',
    label: 'Structural & Exterior',
    tags: [
      { value: 'framing', label: 'Framing' },
      { value: 'roofing', label: 'Roofing' },
      { value: 'siding', label: 'Siding' },
      { value: 'windows_doors', label: 'Windows & Doors' },
      { value: 'masonry', label: 'Masonry' },
      { value: 'stucco', label: 'Stucco' },
      { value: 'stone_veneer', label: 'Stone Veneer' },
      { value: 'hardscaping', label: 'Hardscaping' },
      { value: 'decks_porches', label: 'Decks / Porches' },
      { value: 'gutters', label: 'Gutters' },
      { value: 'fencing', label: 'Fencing' },
    ]
  },
  {
    value: 'interior_finishes',
    label: 'Interior Finishes',
    tags: [
      { value: 'drywall', label: 'Drywall' },
      { value: 'painting', label: 'Painting' },
      { value: 'flooring', label: 'Flooring' },
      { value: 'tile', label: 'Tile' },
      { value: 'trim_millwork', label: 'Trim / Millwork' },
      { value: 'cabinetry', label: 'Cabinetry' },
      { value: 'countertops', label: 'Countertops' },
      { value: 'acoustical_ceilings', label: 'Acoustical Ceilings (ACT)' },
      { value: 'glass_mirrors', label: 'Glass & Mirrors' },
      { value: 'carpet', label: 'Carpet' },
    ]
  },
  {
    value: 'mep',
    label: 'MEP (Mechanical, Electrical, Plumbing)',
    tags: [
      { value: 'electrician', label: 'Electrical' },
      { value: 'plumber', label: 'Plumbing' },
      { value: 'hvac', label: 'HVAC' },
      { value: 'low_voltage_data', label: 'Low Voltage / Data' },
      { value: 'mechanical_commercial', label: 'Mechanical (Commercial HVAC)' },
    ]
  },
  {
    value: 'specialty_systems',
    label: 'Specialty Systems',
    tags: [
      { value: 'fire_alarm', label: 'Fire Alarm' },
      { value: 'fire_sprinkler', label: 'Fire Sprinkler' },
      { value: 'security_systems', label: 'Security Systems' },
      { value: 'access_control', label: 'Access Control' },
      { value: 'automation_controls', label: 'Automation / Controls' },
      { value: 'solar', label: 'Solar' },
      { value: 'generators', label: 'Generators' },
      { value: 'welding_fabrication', label: 'Welding / Fabrication' },
      { value: 'environmental_abatement', label: 'Environmental / Abatement' },
      { value: 'elevator_installation', label: 'Elevator Installation' },
    ]
  }
];

const GC_MAIN_CATEGORIES = [
  { value: 'residential_gc', label: 'Residential General Contractor' },
  { value: 'commercial_gc', label: 'Commercial General Contractor' },
  { value: 'industrial_contractor', label: 'Industrial Contractor' },
  { value: 'government_public_works', label: 'Government / Public Works Contractor' },
  { value: 'specialty_niche_gc', label: 'Specialty / Niche GC' },
];

const GC_TAGS = {
  residential_gc: [
    { value: 'custom_homes', label: 'Custom Homes' },
    { value: 'spec_homes', label: 'Spec Homes' },
    { value: 'remodeling', label: 'Remodeling' },
    { value: 'additions', label: 'Additions' },
    { value: 'residential_renovation', label: 'Residential Renovation' },
    { value: 'single_family', label: 'Single-Family' },
    { value: 'multi_family_2_4', label: 'Multi-Family (2–4 units)' },
    { value: 'residential_repair', label: 'Residential Repair' },
  ],
  commercial_gc: [
    { value: 'retail', label: 'Retail' },
    { value: 'tenant_buildout', label: 'Tenant Build-Out' },
    { value: 'office', label: 'Office' },
    { value: 'restaurant', label: 'Restaurant' },
    { value: 'medical_dental', label: 'Medical / Dental' },
    { value: 'hospitality', label: 'Hospitality' },
    { value: 'warehouse_flex', label: 'Warehouse / Flex Spaces' },
    { value: 'multi_family_5_plus', label: 'Multi-Family (5+ units)' },
  ],
  industrial_contractor: [
    { value: 'manufacturing_facilities', label: 'Manufacturing Facilities' },
    { value: 'distribution_centers', label: 'Distribution Centers' },
    { value: 'industrial_renovation', label: 'Industrial Renovation' },
    { value: 'plant_maintenance', label: 'Plant Maintenance' },
    { value: 'industrial_electrical_mechanical', label: 'Industrial Electrical / Mechanical' },
    { value: 'heavy_equipment_foundations', label: 'Heavy Equipment Foundations' },
  ],
  government_public_works: [
    { value: 'municipal', label: 'Municipal (City/County)' },
    { value: 'state_projects', label: 'State Projects' },
    { value: 'federal_projects', label: 'Federal Projects' },
    { value: 'schools_universities', label: 'Schools / Universities' },
    { value: 'dot_infrastructure', label: 'DOT / Infrastructure' },
    { value: 'public_safety_buildings', label: 'Public Safety Buildings (Fire, Police)' },
  ],
  specialty_niche_gc: [
    { value: 'disaster_recovery', label: 'Disaster Recovery' },
    { value: 'insurance_restoration', label: 'Insurance Restoration' },
    { value: 'green_building_leed', label: 'Green Building / LEED' },
    { value: 'historical_restoration', label: 'Historical Restoration' },
    { value: 'modular_construction', label: 'Modular Construction' },
    { value: 'smart_building_integration', label: 'Smart Building Integration' },
  ]
};

const US_STATES = [
  { value: 'AL', label: 'Alabama' },
  { value: 'AK', label: 'Alaska' },
  { value: 'AZ', label: 'Arizona' },
  { value: 'AR', label: 'Arkansas' },
  { value: 'CA', label: 'California' },
  { value: 'CO', label: 'Colorado' },
  { value: 'CT', label: 'Connecticut' },
  { value: 'DE', label: 'Delaware' },
  { value: 'FL', label: 'Florida' },
  { value: 'GA', label: 'Georgia' },
  { value: 'HI', label: 'Hawaii' },
  { value: 'ID', label: 'Idaho' },
  { value: 'IL', label: 'Illinois' },
  { value: 'IN', label: 'Indiana' },
  { value: 'IA', label: 'Iowa' },
  { value: 'KS', label: 'Kansas' },
  { value: 'KY', label: 'Kentucky' },
  { value: 'LA', label: 'Louisiana' },
  { value: 'ME', label: 'Maine' },
  { value: 'MD', label: 'Maryland' },
  { value: 'MA', label: 'Massachusetts' },
  { value: 'MI', label: 'Michigan' },
  { value: 'MN', label: 'Minnesota' },
  { value: 'MS', label: 'Mississippi' },
  { value: 'MO', label: 'Missouri' },
  { value: 'MT', label: 'Montana' },
  { value: 'NE', label: 'Nebraska' },
  { value: 'NV', label: 'Nevada' },
  { value: 'NH', label: 'New Hampshire' },
  { value: 'NJ', label: 'New Jersey' },
  { value: 'NM', label: 'New Mexico' },
  { value: 'NY', label: 'New York' },
  { value: 'NC', label: 'North Carolina' },
  { value: 'ND', label: 'North Dakota' },
  { value: 'OH', label: 'Ohio' },
  { value: 'OK', label: 'Oklahoma' },
  { value: 'OR', label: 'Oregon' },
  { value: 'PA', label: 'Pennsylvania' },
  { value: 'RI', label: 'Rhode Island' },
  { value: 'SC', label: 'South Carolina' },
  { value: 'SD', label: 'South Dakota' },
  { value: 'TN', label: 'Tennessee' },
  { value: 'TX', label: 'Texas' },
  { value: 'UT', label: 'Utah' },
  { value: 'VT', label: 'Vermont' },
  { value: 'VA', label: 'Virginia' },
  { value: 'WA', label: 'Washington' },
  { value: 'WV', label: 'West Virginia' },
  { value: 'WI', label: 'Wisconsin' },
  { value: 'WY', label: 'Wyoming' },
  { value: 'DC', label: 'District of Columbia' }
];

export default function BasicInfoForm({ data, onChange, onNext, onBack }) {
  const isGC = data.trade_category === 'general_contractor';
  const selectedTradeTags = data.trade_tags || [];
  
  const currentTradeGroup = TRADE_GROUPS.find(g => g.value === data.trade_category);
  const availableTags = isGC 
    ? (data.gc_main_category ? GC_TAGS[data.gc_main_category] || [] : [])
    : currentTradeGroup?.tags || [];

  const toggleTag = (tagValue) => {
    const current = selectedTradeTags || [];
    const newTags = current.includes(tagValue)
      ? current.filter(t => t !== tagValue)
      : [...current, tagValue];
    onChange({ ...data, trade_tags: newTags });
  };

  const isValid =
    data.company_name?.trim() &&
    data.owner_name?.trim() &&
    data.trade_category &&
    selectedTradeTags.length > 0 &&
    data.email?.trim() &&
    data.phone?.trim() &&
    data.business_address?.trim() &&
    data.service_radius &&
    (!isGC || (data.gc_license_number?.trim() && data.gc_license_state));

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold text-slate-900 mb-2">
          Business Information
        </h2>
        <p className="text-slate-500">
          Tell us about your company and specialties
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <Label htmlFor="company_name" className="flex items-center gap-2 mb-2">
            <Building2 className="w-4 h-4 text-slate-400" />
            Company Name *
          </Label>
          <Input
            id="company_name"
            value={data.company_name || ''}
            onChange={(e) => onChange({ ...data, company_name: e.target.value })}
            placeholder="ABC Construction LLC"
            className="h-11"
          />
        </div>

        <div>
          <Label htmlFor="owner_name" className="flex items-center gap-2 mb-2">
            <User className="w-4 h-4 text-slate-400" />
            Owner Name *
          </Label>
          <Input
            id="owner_name"
            value={data.owner_name || ''}
            onChange={(e) => onChange({ ...data, owner_name: e.target.value })}
            placeholder="John Smith"
            className="h-11"
          />
        </div>

        {isGC && (
          <>
            <div>
              <Label htmlFor="gc_license_number" className="flex items-center gap-2 mb-2">
                <FileCheck className="w-4 h-4 text-slate-400" />
                License Number *
              </Label>
              <Input
                id="gc_license_number"
                value={data.gc_license_number || ''}
                onChange={(e) => onChange({ ...data, gc_license_number: e.target.value })}
                placeholder="Enter your license number"
                className="h-11"
              />
            </div>

            <div>
              <Label htmlFor="gc_license_state" className="mb-2 block">
                Issuing State *
              </Label>
              <Select
                value={data.gc_license_state || ''}
                onValueChange={(value) => onChange({ ...data, gc_license_state: value })}
              >
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Select issuing state" />
                </SelectTrigger>
                <SelectContent>
                  {US_STATES.map((state) => (
                    <SelectItem key={state.value} value={state.value}>
                      {state.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="gc_main_category" className="mb-2 block">
                GC Main Category *
              </Label>
              <Select
                value={data.gc_main_category || ''}
                onValueChange={(value) => onChange({ ...data, gc_main_category: value, trade_tags: [] })}
              >
                <SelectTrigger className="h-11">
                  <SelectValue placeholder="Select your main category" />
                </SelectTrigger>
                <SelectContent>
                  {GC_MAIN_CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </>
        )}

        {!isGC && (
          <div>
            <Label htmlFor="trade_category" className="mb-2 block">
              Primary Trade Group *
            </Label>
            <Select
              value={data.trade_category || ''}
              onValueChange={(value) => onChange({ ...data, trade_category: value, trade_tags: [] })}
            >
              <SelectTrigger className="h-11">
                <SelectValue placeholder="Select your primary trade group" />
              </SelectTrigger>
              <SelectContent>
                {TRADE_GROUPS.map((group) => (
                  <SelectItem key={group.value} value={group.value}>
                    {group.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {((isGC && data.gc_main_category) || (!isGC && data.trade_category)) && (
          <div>
            <Label className="mb-2 block">
              {isGC ? 'GC Specialties *' : 'Trade Specialties *'}
            </Label>
            <p className="text-sm text-slate-500 mb-3">
              Select all that apply
            </p>
            
            <div className="flex flex-wrap gap-2">
              {availableTags.map((tag) => (
                <button
                  key={tag.value}
                  type="button"
                  onClick={() => toggleTag(tag.value)}
                  className={`px-3 py-1.5 rounded-full text-sm border transition-colors ${
                    selectedTradeTags.includes(tag.value)
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {tag.label}
                </button>
              ))}
            </div>

            {selectedTradeTags.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                <p className="text-xs text-slate-500 w-full">Selected:</p>
                {selectedTradeTags.map((tagValue) => {
                  const tag = availableTags.find(t => t.value === tagValue);
                  return (
                    <Badge key={tagValue} variant="secondary" className="gap-1">
                      {tag?.label || tagValue}
                      <button
                        type="button"
                        onClick={() => toggleTag(tagValue)}
                        className="ml-1 hover:text-slate-900"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Badge>
                  );
                })}
              </div>
            )}
          </div>
        )}

        <div>
          <Label htmlFor="email" className="flex items-center gap-2 mb-2">
            <Mail className="w-4 h-4 text-slate-400" />
            Business Email *
          </Label>
          <Input
            id="email"
            type="email"
            value={data.email || ''}
            onChange={(e) => onChange({ ...data, email: e.target.value })}
            placeholder="contact@abcconstruction.com"
            className="h-11"
          />
        </div>

        <div>
          <Label htmlFor="phone" className="flex items-center gap-2 mb-2">
            <Phone className="w-4 h-4 text-slate-400" />
            Business Phone *
          </Label>
          <Input
            id="phone"
            type="tel"
            value={data.phone || ''}
            onChange={(e) => onChange({ ...data, phone: e.target.value })}
            placeholder="(555) 123-4567"
            className="h-11"
          />
        </div>

        <div>
          <Label htmlFor="business_address" className="flex items-center gap-2 mb-2">
            <MapPin className="w-4 h-4 text-slate-400" />
            Full Business Address *
          </Label>
          <Input
            id="business_address"
            value={data.business_address || ''}
            onChange={(e) => {
              const address = e.target.value;
              // Extract zip code from address (simple regex for 5-digit zip)
              const zipMatch = address.match(/\b\d{5}\b/);
              const zip = zipMatch ? zipMatch[0] : '';
              onChange({ ...data, business_address: address, zip_code: zip });
            }}
            placeholder="123 Main St, City, State 12345"
            className="h-11"
          />
          {data.zip_code && (
            <p className="text-xs text-slate-500 mt-1">
              Detected zip code: {data.zip_code}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="service_radius" className="mb-2 block">
            Service Radius *
          </Label>
          <Select
            value={data.service_radius?.toString() || ''}
            onValueChange={(value) => onChange({ ...data, service_radius: parseInt(value) })}
          >
            <SelectTrigger className="h-11">
              <SelectValue placeholder="Select service radius" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="25">25 miles</SelectItem>
              <SelectItem value="50">50 miles</SelectItem>
              <SelectItem value="75">75 miles</SelectItem>
              <SelectItem value="100">100 miles</SelectItem>
              <SelectItem value="125">125 miles</SelectItem>
              <SelectItem value="150">150 miles</SelectItem>
              <SelectItem value="175">175 miles</SelectItem>
              <SelectItem value="200">200 miles</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="website_url" className="flex items-center gap-2 mb-2">
            <Globe className="w-4 h-4 text-slate-400" />
            Website (Optional)
          </Label>
          <Input
            id="website_url"
            type="url"
            value={data.website_url || ''}
            onChange={(e) => onChange({ ...data, website_url: e.target.value })}
            placeholder="https://www.abcconstruction.com"
            className="h-11"
          />
        </div>

        <div>
          <Label htmlFor="profile_bio" className="flex items-center gap-2 mb-2">
            <FileText className="w-4 h-4 text-slate-400" />
            Short Bio (Optional, max 180 chars)
          </Label>
          <Textarea
            id="profile_bio"
            value={data.profile_bio || ''}
            onChange={(e) => onChange({ ...data, profile_bio: e.target.value })}
            placeholder="Tell potential clients about your experience and specialty..."
            maxLength={180}
            rows={3}
          />
          <p className="text-xs text-slate-400 mt-1">
            {data.profile_bio?.length || 0} / 180 characters
          </p>
        </div>
      </div>

      <div className="flex gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={onBack}
          className="flex-1 h-11"
        >
          Back
        </Button>
        <Button
          onClick={onNext}
          disabled={!isValid}
          className="flex-1 h-11 bg-slate-900 hover:bg-slate-800 disabled:opacity-50"
        >
          Continue to Projects
        </Button>
      </div>
    </div>
  );
}