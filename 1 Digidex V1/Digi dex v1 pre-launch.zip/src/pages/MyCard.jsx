import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { 
  ArrowLeft, Building2, User, Phone, Mail, MapPin, Globe, 
  Share2, Edit, Copy, Check, Briefcase, Users, ChevronLeft, ChevronRight, Loader2
} from 'lucide-react';

const TRADE_LABELS = {
  general_contractor: 'General Contractor',
  electrician: 'Electrician',
  plumber: 'Plumber',
  hvac: 'HVAC',
  carpenter: 'Carpenter',
  roofer: 'Roofer',
  excavator: 'Excavator',
  painter: 'Painter',
  mason: 'Mason',
  landscaper: 'Landscaper',
  flooring: 'Flooring',
  drywall: 'Drywall',
  insulation: 'Insulation',
  siding: 'Siding',
  windows_doors: 'Windows & Doors',
  concrete: 'Concrete',
  framing: 'Framing',
  demolition: 'Demolition',
  tile: 'Tile',
  cabinetry: 'Cabinetry',
  other: 'Other'
};

export default function MyCard() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showShare, setShowShare] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeProject, setActiveProject] = useState(0);
  const [activePhoto, setActivePhoto] = useState(0);

  useEffect(() => {
    loadUser();
    
    // Check if share modal should open
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('share') === 'true') {
      setShowShare(true);
    }
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
  };

  const { data: profile, isLoading } = useQuery({
    queryKey: ['myProfile', user?.email],
    queryFn: async () => {
      const profiles = await base44.entities.TradeProfile.filter({
        created_by: user?.email
      });
      return profiles[0] || null;
    },
    enabled: !!user
  });

  const inviteUrl = profile 
    ? `${window.location.origin}${createPageUrl('Onboarding')}?invite=${profile.invite_code}`
    : '';

  const handleCopy = () => {
    navigator.clipboard.writeText(inviteUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const projects = profile?.projects || [];
  const references = profile?.references || [];
  const currentProject = projects[activeProject];

  const nextPhoto = () => {
    if (currentProject && activePhoto < currentProject.photos.length - 1) {
      setActivePhoto(activePhoto + 1);
    }
  };

  const prevPhoto = () => {
    if (activePhoto > 0) {
      setActivePhoto(activePhoto - 1);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <p className="text-slate-500">Profile not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link to={createPageUrl('Dashboard')} className="p-2 -ml-2 hover:bg-slate-100 rounded-xl transition-colors">
                <ArrowLeft className="w-5 h-5 text-slate-600" />
              </Link>
              <h1 className="text-xl font-bold text-slate-900">My Card</h1>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="border-slate-200"
                onClick={() => setShowShare(true)}
              >
                <Share2 className="w-4 h-4 mr-1.5" />
                Invite
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Profile Header */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl p-6 text-white">
          <div className="flex items-start gap-4">
            <div className="w-20 h-20 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
              {profile.profile_photo_url ? (
                <img 
                  src={profile.profile_photo_url} 
                  alt={profile.company_name}
                  className="w-full h-full object-cover rounded-xl"
                />
              ) : (
                <Building2 className="w-8 h-8 text-white/60" />
              )}
            </div>
            <div className="flex-1">
              <h2 className="text-2xl font-bold">{profile.company_name}</h2>
              <p className="text-white/70 flex items-center gap-1.5 mt-1">
                <User className="w-4 h-4" />
                {profile.owner_name}
              </p>
              <Badge className="mt-2 bg-white/10 text-white border-0">
                {TRADE_LABELS[profile.trade_category]}
              </Badge>
            </div>
          </div>

          {profile.profile_bio && (
            <p className="mt-4 text-white/80 leading-relaxed">{profile.profile_bio}</p>
          )}

          <div className="grid grid-cols-2 gap-4 mt-6 text-sm">
            <a href={`mailto:${profile.email}`} className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
              <Mail className="w-4 h-4" />
              {profile.email}
            </a>
            <a href={`tel:${profile.phone}`} className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
              <Phone className="w-4 h-4" />
              {profile.phone}
            </a>
            <div className="flex items-center gap-2 text-white/70">
              <MapPin className="w-4 h-4" />
              {profile.zip_code}
            </div>
            {profile.website_url && (
              <a href={profile.website_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
                <Globe className="w-4 h-4" />
                Website
              </a>
            )}
          </div>
        </div>

        {/* Projects Section */}
        <div className="mt-6 bg-white rounded-2xl p-6 border border-slate-100">
          <div className="flex items-center gap-2 mb-4">
            <Briefcase className="w-5 h-5 text-slate-700" />
            <h3 className="text-lg font-semibold text-slate-900">Projects ({projects.length})</h3>
          </div>

          {projects.length > 0 ? (
            <div className="space-y-4">
              {/* Project Selector */}
              <div className="flex gap-2">
                {projects.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => { setActiveProject(idx); setActivePhoto(0); }}
                    className={`flex-1 h-1.5 rounded-full transition-colors ${
                      activeProject === idx ? 'bg-slate-900' : 'bg-slate-200'
                    }`}
                  />
                ))}
              </div>

              {/* Photo Gallery */}
              {currentProject && (
                <>
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-100">
                    <img
                      src={currentProject.photos[activePhoto]}
                      alt={`Project ${activeProject + 1}`}
                      className="w-full h-full object-cover"
                    />
                    
                    {currentProject.photos.length > 1 && (
                      <>
                        <button
                          onClick={prevPhoto}
                          disabled={activePhoto === 0}
                          className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center disabled:opacity-30"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                        <button
                          onClick={nextPhoto}
                          disabled={activePhoto === currentProject.photos.length - 1}
                          className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center disabled:opacity-30"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </>
                    )}

                    <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/60 rounded-full text-xs text-white">
                      {activePhoto + 1} / {currentProject.photos.length}
                    </div>
                  </div>

                  <p className="text-sm text-slate-600">{currentProject.description}</p>
                </>
              )}
            </div>
          ) : (
            <p className="text-slate-500 text-center py-4">No projects added</p>
          )}
        </div>

        {/* References Section */}
        <div className="mt-6 bg-white rounded-2xl p-6 border border-slate-100">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-slate-700" />
            <h3 className="text-lg font-semibold text-slate-900">References ({references.length})</h3>
          </div>

          {references.length > 0 ? (
            <div className="space-y-3">
              {references.map((ref, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-slate-50">
                  <p className="font-medium text-slate-900">{ref.name}</p>
                  <div className="flex flex-wrap gap-3 mt-2 text-sm text-slate-500">
                    <a href={`tel:${ref.phone}`} className="flex items-center gap-1 hover:text-slate-700">
                      <Phone className="w-3.5 h-3.5" />
                      {ref.phone}
                    </a>
                    <a href={`mailto:${ref.email}`} className="flex items-center gap-1 hover:text-slate-700">
                      <Mail className="w-3.5 h-3.5" />
                      {ref.email}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-500 text-center py-4">No references added</p>
          )}
        </div>
      </div>

      {/* Share Modal */}
      <Dialog open={showShare} onOpenChange={setShowShare}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl font-semibold">Invite to Rolodex</DialogTitle>
          </DialogHeader>

          <div className="mt-4">
            <p className="text-sm text-slate-500 mb-4">
              Share this link to invite someone to TradeRolodex. When they sign up, you'll both be automatically added to each other's Rolodex.
            </p>

            <div className="flex gap-2">
              <Input
                value={inviteUrl}
                readOnly
                className="flex-1 bg-slate-50"
              />
              <Button onClick={handleCopy} className="bg-slate-900 hover:bg-slate-800">
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}