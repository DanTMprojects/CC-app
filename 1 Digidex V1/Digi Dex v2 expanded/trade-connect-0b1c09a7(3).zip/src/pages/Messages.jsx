import React, {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback,
} from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import {
  useQuery,
  useMutation,
  useQueryClient,
} from '@tanstack/react-query';
import { createPageUrl } from '@/utils';
import {
  findOrCreateThread,
  dedupeThreads,
  getContactProfile,
} from '@/components/utils/threadUtils';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowLeft,
  Send,
  MapPin,
  Building2,
  Loader2,
  MessageSquare,
  Filter,
  Plus,
  Bell,
  BellOff,
} from 'lucide-react';
import ThreadItem from '@/components/messaging/ThreadItem';
import ChatBubble from '@/components/messaging/ChatBubble';
import RolodexContactSelectionModal from '@/components/messaging/RolodexContactSelectionModal';
import ThreadSelectionModal from '@/components/messaging/ThreadSelectionModal';
import NewThreadModal from '@/components/messaging/NewThreadModal';
import StructuredMessageModal from '@/components/messaging/StructuredMessageModal';
import moment from 'moment';

export default function Messages() {
  const [user, setUser] = useState(null);
  const [myProfile, setMyProfile] = useState(null);
  const [activeThreadId, setActiveThreadId] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [tradeFilter, setTradeFilter] = useState('all');
  const [showContactSelection, setShowContactSelection] = useState(false);
  const [showThreadSelection, setShowThreadSelection] = useState(false);
  const [showNewThread, setShowNewThread] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [selectedContactThreads, setSelectedContactThreads] = useState([]);
  const [threadSearch, setThreadSearch] = useState('');
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [structuredModalType, setStructuredModalType] = useState(null); // 'quote' | 'change_order' | 'invoice' | 'punch_item' | null
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [threadView, setThreadView] = useState('inbox'); // 'inbox' | 'archived'
  const [selectedProjectKey, setSelectedProjectKey] = useState(null); // GC: current project_name

  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const notificationsTrackerRef = useRef({});

  const queryClient = useQueryClient();

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);

    const profiles = await base44.entities.TradeProfile.filter({
      created_by: currentUser.email,
    });
    if (profiles.length > 0) {
      setMyProfile(profiles[0]);
    }
  };

  useEffect(() => {
    loadUser();

    const urlParams = new URLSearchParams(window.location.search);
    const threadId = urlParams.get('thread');
    if (threadId) {
      setActiveThreadId(threadId);
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }, []);

  const isGC = myProfile?.trade_category === 'GENERAL_CONTRACTOR';

  // ----- THREADS -----

  const {
    data: threads = [],
    isLoading: threadsLoading,
  } = useQuery({
    queryKey: ['myThreads', user?.email],
    queryFn: async () => {
      const currentUser = await base44.auth.me();
      const threadsAsUserA =
        await base44.entities.ProjectThread.filter({
          user_a_id: currentUser.email,
        });
      const threadsAsUserB =
        await base44.entities.ProjectThread.filter({
          user_b_id: currentUser.email,
        });
      return dedupeThreads([...threadsAsUserA, ...threadsAsUserB]);
    },
    enabled: !!user,
  });

  const { data: rolodexProfiles = [] } = useQuery({
    queryKey: ['rolodexProfiles', user?.email],
    queryFn: async () => {
      if (!user?.email) return [];
      return base44.entities.TradeProfile.list();
    },
    enabled: !!user,
  });

  const normalizedThreads = useMemo(() => {
    if (!user) return [];

    return threads.map((thread) => {
      const isUserA = thread.user_a_id === user.email;
      const myUnreadCount = isUserA
        ? thread.unread_count_a || 0
        : thread.unread_count_b || 0;
      const isPinned = isUserA
        ? !!thread.pinned_by_a
        : !!thread.pinned_by_b;
      const isArchived = isUserA
        ? !!thread.archived_by_a
        : !!thread.archived_by_b;
      const isMuted = isUserA
        ? !!thread.muted_by_a
        : !!thread.muted_by_b;

      return {
        ...thread,
        is_user_a: isUserA,
        other_user_id: isUserA ? thread.user_b_id : thread.user_a_id,
        other_user_profile_id: isUserA
          ? thread.user_b_profile_id
          : thread.user_a_profile_id,
        myUnreadCount,
        isPinned,
        isArchived,
        isMuted,
      };
    });
  }, [threads, user]);

  const activeThread = normalizedThreads.find(
    (t) => t.id === activeThreadId
  );

  const profileIds = useMemo(() => {
    const ids = new Set();
    normalizedThreads.forEach((thread) => {
      if (thread.user_a_profile_id) ids.add(thread.user_a_profile_id);
      if (thread.user_b_profile_id) ids.add(thread.user_b_profile_id);
    });
    return Array.from(ids);
  }, [normalizedThreads]);

  const { data: profiles = [] } = useQuery({
    key: ['profilesForThreads', profileIds.join(',')],
    queryKey: ['profilesForThreads', profileIds.join(',')],
    queryFn: async () => {
      if (profileIds.length === 0) return [];
      const allProfiles = await base44.entities.TradeProfile.list();
      return allProfiles.filter((p) => profileIds.includes(p.id));
    },
    enabled: profileIds.length > 0,
  });

  const profileMap = useMemo(() => {
    return profiles.reduce((acc, profile) => {
      acc[profile.id] = profile;
      return acc;
    }, {});
  }, [profiles]);

  const activeContactProfileId = activeThread
    ? activeThread.user_a_id === user?.email
      ? activeThread.user_b_profile_id
      : activeThread.user_a_profile_id
    : null;

  const activeContactProfile = activeContactProfileId
    ? profileMap[activeContactProfileId]
    : null;

  // ----- MESSAGES -----

  const {
    data: messages = [],
    isLoading: messagesLoading,
  } = useQuery({
    queryKey: ['threadMessages', activeThreadId],
    queryFn: () =>
      base44.entities.DirectMessage.filter({
        thread_id: activeThreadId,
      }),
    enabled: !!activeThreadId,
    refetchInterval: 5000,
  });

  const uniqueMessages = useMemo(
    () =>
      Object.values(
        messages.reduce((acc, msg) => {
          acc[msg.id] = msg;
          return acc;
        }, {})
      ),
    [messages]
  );

  const sortedMessages = useMemo(
    () =>
      uniqueMessages.sort(
        (a, b) => new Date(a.created_date) - new Date(b.created_date)
      ),
    [uniqueMessages]
  );

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [sortedMessages.length]);

  useEffect(() => {
    if (!activeThread || !user?.email) return;

    const isUserA = activeThread.user_a_id === user.email;
    const unreadField = isUserA ? 'unread_count_a' : 'unread_count_b';
    const currentUnread = activeThread[unreadField] || 0;

    if (currentUnread > 0) {
      base44.entities.ProjectThread.update(activeThread.id, {
        [unreadField]: 0,
      });
      queryClient.invalidateQueries(['myThreads']);

      const tracker = notificationsTrackerRef.current || {};
      delete tracker[activeThread.id];
      notificationsTrackerRef.current = tracker;
    }
  }, [activeThread, user?.email, queryClient]);

  // ----- FILTERED THREADS + PROJECT GROUPS -----

  const filteredThreads = useMemo(() => {
    const needle = threadSearch.trim().toLowerCase();

    const visible = normalizedThreads.filter((thread) => {
      if (threadView === 'inbox' && thread.isArchived) return false;
      if (threadView === 'archived' && !thread.isArchived) return false;

      const contactProfile = getContactProfile(
        thread,
        user?.email,
        profileMap
      );

      if (
        tradeFilter !== 'all' &&
        contactProfile?.trade_category !== tradeFilter
      ) {
        return false;
      }

      if (!needle) return true;

      const haystack = [
        thread.project_name,
        contactProfile?.company_name,
        contactProfile?.trade_category?.replace(/_/g, ' '),
        thread.last_message,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      return haystack.includes(needle);
    });

    return visible.sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;

      const aUnread = a.myUnreadCount > 0;
      const bUnread = b.myUnreadCount > 0;
      if (aUnread !== bUnread) return aUnread ? -1 : 1;

      const dateA = new Date(a.last_message_at || a.created_date);
      const dateB = new Date(b.last_message_at || b.created_date);
      return dateB - dateA;
    });
  }, [
    normalizedThreads,
    threadSearch,
    tradeFilter,
    threadView,
    user?.email,
    profileMap,
  ]);

  const projectGroups = useMemo(() => {
    const groups = {};

    filteredThreads.forEach((thread) => {
      const key = thread.project_name || 'Untitled project';
      if (!groups[key]) {
        groups[key] = {
          projectKey: key,
          projectName: key,
          threads: [],
          unreadCount: 0,
          latestAt: null,
        };
      }
      const grp = groups[key];
      grp.threads.push(thread);
      grp.unreadCount += thread.myUnreadCount || 0;

      const lastAt = new Date(thread.last_message_at || thread.created_date);
      if (!grp.latestAt || lastAt > grp.latestAt) {
        grp.latestAt = lastAt;
      }
    });

    return Object.values(groups).sort((a, b) => b.latestAt - a.latestAt);
  }, [filteredThreads]);

  useEffect(() => {
    if (!isGC) return;

    if (projectGroups.length === 0) {
      setSelectedProjectKey(null);
      return;
    }

    const hasCurrent = projectGroups.some(
      (p) => p.projectKey === selectedProjectKey
    );

    if (!selectedProjectKey || !hasCurrent) {
      setSelectedProjectKey(projectGroups[0].projectKey);
    }
  }, [isGC, projectGroups, selectedProjectKey]);

  const threadsForSelectedProject = useMemo(() => {
    if (!isGC || !selectedProjectKey) return [];
    return filteredThreads.filter(
      (t) => (t.project_name || 'Untitled project') === selectedProjectKey
    );
  }, [isGC, filteredThreads, selectedProjectKey]);

  const groupedMessages = useMemo(() => {
    return sortedMessages.reduce((groups, message) => {
      const date = moment(message.created_date).format('MMMM D, YYYY');
      if (!groups[date]) groups[date] = [];
      groups[date].push(message);
      return groups;
    }, {});
  }, [sortedMessages]);

  // ----- NOTIFICATIONS -----

  useEffect(() => {
    if (!notificationsEnabled) return;
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;

    const tracker = notificationsTrackerRef.current || {};

    normalizedThreads.forEach((thread) => {
      if (thread.isMuted) return;

      const myUnread = thread.myUnreadCount || 0;
      if (!myUnread) return;

      const lastAt = thread.last_message_at || thread.created_date;
      const key = thread.id;

      if (tracker[key] === lastAt) return;

      const contactProfile = getContactProfile(
        thread,
        user?.email,
        profileMap
      );
      const title = contactProfile?.company_name || 'New message';
      const body = `${thread.project_name || 'Project'} • ${
        thread.last_message || ''
      }`;

      try {
        const notif = new Notification(title, { body });
        setTimeout(() => {
          if (notif && typeof notif.close === 'function') notif.close();
        }, 8000);
      } catch (_) {}

      tracker[key] = lastAt;
    });

    notificationsTrackerRef.current = tracker;
  }, [normalizedThreads, user?.email, profileMap, notificationsEnabled]);

  // ----- MUTATIONS -----

  const deleteThread = useMutation({
    mutationFn: async (thread) => {
      const msgs = await base44.entities.DirectMessage.filter({
        thread_id: thread.id,
      });
      for (const msg of msgs) {
        await base44.entities.DirectMessage.delete(msg.id);
      }
      await base44.entities.ProjectThread.delete(thread.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['myThreads']);
      setActiveThreadId(null);
    },
    onError: (err) => {
      console.error(err);
      alert('Failed to delete conversation. Please try again.');
    },
  });

  const togglePinThread = useMutation({
    mutationFn: async (thread) => {
      if (!user?.email) return;
      const isUserA = thread.user_a_id === user.email;
      const field = isUserA ? 'pinned_by_a' : 'pinned_by_b';
      const current = !!thread[field];
      await base44.entities.ProjectThread.update(thread.id, {
        [field]: !current,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['myThreads']);
    },
    onError: (err) => console.error(err),
  });

  const archiveThread = useMutation({
    mutationFn: async (thread) => {
      if (!user?.email) return;
      const isUserA = thread.user_a_id === user.email;
      const field = isUserA ? 'archived_by_a' : 'archived_by_b';
      const current = !!thread[field];

      await base44.entities.ProjectThread.update(thread.id, {
        [field]: !current,
      });
    },
    onSuccess: (_data, thread) => {
      queryClient.invalidateQueries(['myThreads']);
      if (threadView === 'inbox' && activeThreadId === thread.id) {
        setActiveThreadId(null);
      }
    },
    onError: (err) => console.error(err),
  });

  const toggleReadUnreadThread = useMutation({
    mutationFn: async (thread) => {
      if (!user?.email) return;
      const isUserA = thread.user_a_id === user.email;
      const field = isUserA ? 'unread_count_a' : 'unread_count_b';
      const current = thread[field] || 0;
      const newValue = current > 0 ? 0 : 1;

      await base44.entities.ProjectThread.update(thread.id, {
        [field]: newValue,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['myThreads']);
    },
    onError: (err) => console.error(err),
  });

  const toggleMuteThread = useMutation({
    mutationFn: async (thread) => {
      if (!user?.email) return;
      const isUserA = thread.user_a_id === user.email;
      const field = isUserA ? 'muted_by_a' : 'muted_by_b';
      const current = !!thread[field];

      await base44.entities.ProjectThread.update(thread.id, {
        [field]: !current,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['myThreads']);
    },
    onError: (err) => console.error(err),
  });

  const sendStructuredMessage = useMutation({
    mutationFn: async (payload) => {
      if (!payload || !activeThread || !user?.email) return;

      const receiverId =
        activeThread.user_a_id === user.email
          ? activeThread.user_b_id
          : activeThread.user_a_id;

      const messageText = JSON.stringify(payload);

      await base44.entities.DirectMessage.create({
        thread_id: activeThreadId,
        sender_id: user.email,
        receiver_id: receiverId,
        message_text: messageText,
      });

      let lastMessagePreview = '[Update]';
      if (payload.type === 'quote' && payload.title) {
        lastMessagePreview = `QUOTE: ${payload.title}`;
      } else if (payload.type === 'change_order' && payload.title) {
        lastMessagePreview = `CO: ${payload.title}`;
      } else if (payload.type === 'invoice' && payload.title) {
        lastMessagePreview = `INVOICE: ${payload.title}`;
      } else if (payload.type === 'punch_item' && payload.title) {
        lastMessagePreview = `PUNCH: ${payload.title}`;
      } else if (payload.type === 'attachment' && payload.name) {
        lastMessagePreview = `ATTACHMENT: ${payload.name}`;
      }

      const isUserA = activeThread.user_a_id === user.email;
      const unreadField = isUserA ? 'unread_count_b' : 'unread_count_a';
      const currentUnread = activeThread[unreadField] || 0;

      await base44.entities.ProjectThread.update(activeThreadId, {
        last_message: lastMessagePreview,
        last_message_at: new Date().toISOString(),
        [unreadField]: currentUnread + 1,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['threadMessages', activeThreadId]);
      queryClient.invalidateQueries(['myThreads']);
    },
    onError: (err) => {
      console.error(err);
      alert('Failed to send structured message. Please try again.');
    },
  });

  const sendMessage = useMutation({
    mutationFn: async () => {
      if (!newMessage.trim() || !activeThread) return;

      const receiverId =
        activeThread.user_a_id === user.email
          ? activeThread.user_b_id
          : activeThread.user_a_id;

      await base44.entities.DirectMessage.create({
        thread_id: activeThreadId,
        sender_id: user.email,
        receiver_id: receiverId,
        message_text: newMessage.trim(),
      });

      const isUserA = activeThread.user_a_id === user.email;
      const unreadField = isUserA ? 'unread_count_b' : 'unread_count_a';
      const currentUnread = activeThread[unreadField] || 0;

      await base44.entities.ProjectThread.update(activeThreadId, {
        last_message: newMessage.trim(),
        last_message_at: new Date().toISOString(),
        [unreadField]: currentUnread + 1,
      });
    },
    onSuccess: () => {
      setNewMessage('');
      queryClient.invalidateQueries(['threadMessages', activeThreadId]);
      queryClient.invalidateQueries(['myThreads']);
    },
    onError: (err) => {
      console.error(err);
      alert('Message failed to send. Please try again.');
    },
  });

  const handleSend = (e) => {
    e?.preventDefault();
    if (sendMessage.isPending || !newMessage.trim()) return;
    sendMessage.mutate();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (!file || !activeThread || !user?.email) return;

    const url = URL.createObjectURL(file);

    const payload = {
      type: 'attachment',
      attachmentType: file.type?.startsWith('image/')
        ? 'image'
        : 'file',
      url,
      name: file.name,
      size: file.size,
    };

    sendStructuredMessage.mutate(payload);
    e.target.value = '';
  };

  const handleQuickQuote = () => {
    if (!activeThread) return;
    setStructuredModalType('quote');
  };

  const handleQuickChangeOrder = () => {
    if (!activeThread) return;
    setStructuredModalType('change_order');
  };

  const handleQuickInvoice = () => {
    if (!activeThread) return;
    setStructuredModalType('invoice');
  };

  const handleQuickPunchItem = () => {
    if (!activeThread) return;
    setStructuredModalType('punch_item');
  };

  const handleSelectContact = useCallback(
    async (contact) => {
      setShowContactSelection(false);

      const userThreadsA =
        await base44.entities.ProjectThread.filter({
          user_a_id: user.email,
          user_b_id: contact.created_by,
        });
      const userThreadsB =
        await base44.entities.ProjectThread.filter({
          user_a_id: contact.created_by,
          user_b_id: user.email,
        });
      const allThreads = [...userThreadsA, ...userThreadsB].sort(
        (a, b) =>
          new Date(b.last_message_at || b.created_date) -
          new Date(a.last_message_at || a.created_date)
      );

      if (allThreads.length > 0) {
        setSelectedContact(contact);
        setSelectedContactThreads(allThreads);
        setShowThreadSelection(true);
      } else {
        const newThread = await findOrCreateThread({
          currentUserEmail: user.email,
          contactEmail: contact.created_by,
          projectName:
            contact.default_project_name || 'New Project Chat',
        });

        setActiveThreadId(newThread.id);
        queryClient.invalidateQueries(['myThreads']);
      }
    },
    [user?.email, queryClient]
  );

  // ----- RENDER -----

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-5xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link
                to={createPageUrl('Dashboard')}
                className="inline-flex items-center gap-2 text-slate-500 hover:text-slate-900"
              >
                <span className="hidden sm:inline text-sm">
                  Back to dashboard
                </span>
              </Link>
              <h1 className="text-xl font-semibold text-slate-900">
                Messages
              </h1>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="hidden sm:inline-flex"
                onClick={() => setShowContactSelection(true)}
              >
                New Conversation
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="sm:hidden"
                onClick={() => setShowContactSelection(true)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main layout */}
      <div className="flex-1 max-w-5xl mx-auto w-full flex">
        {/* LEFT: projects (GC) or threads (non-GC) */}
        <div className="w-full md:w-72 border-r border-slate-100 bg-white flex flex-col">
          <div className="px-4 py-3 border-b border-slate-100">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <h2 className="font-medium text-slate-900">
                  {isGC ? 'Projects' : 'Conversations'}
                </h2>
                {threadsLoading && (
                  <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
                )}
              </div>
              <Select
                value={tradeFilter}
                onValueChange={setTradeFilter}
              >
                <SelectTrigger className="h-8 w-[140px] text-xs">
                  <Filter className="w-3 h-3 mr-1 text-slate-400" />
                  <SelectValue placeholder="All trades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All trades</SelectItem>
                  <SelectItem value="ELECTRICAL">
                    Electrical
                  </SelectItem>
                  <SelectItem value="PLUMBING">
                    Plumbing
                  </SelectItem>
                  <SelectItem value="HVAC">HVAC</SelectItem>
                  <SelectItem value="FRAMING">Framing</SelectItem>
                  <SelectItem value="ROOFING">Roofing</SelectItem>
                  <SelectItem value="GENERAL_CONTRACTOR">
                    GC
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="mt-2">
              <Input
                value={threadSearch}
                onChange={(e) => setThreadSearch(e.target.value)}
                placeholder={
                  isGC ? 'Search projects or trades' : 'Search messages'
                }
                className="h-9 text-xs"
              />
            </div>

            <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
              <button
                type="button"
                onClick={() =>
                  setNotificationsEnabled((prev) => !prev)
                }
                className="inline-flex items-center gap-1 px-2 py-1 rounded-full hover:bg-slate-100"
              >
                {notificationsEnabled ? (
                  <>
                    <Bell className="w-3 h-3" />
                    <span>Notifications on</span>
                  </>
                ) : (
                  <>
                    <BellOff className="w-3 h-3" />
                    <span>Notifications off</span>
                  </>
                )}
              </button>

              <div className="inline-flex items-center rounded-full bg-slate-100 p-0.5">
                <button
                  type="button"
                  onClick={() => setThreadView('inbox')}
                  className={`px-2 py-0.5 rounded-full ${
                    threadView === 'inbox'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-500'
                  }`}
                >
                  Inbox
                </button>
                <button
                  type="button"
                  onClick={() => setThreadView('archived')}
                  className={`px-2 py-0.5 rounded-full ${
                    threadView === 'archived'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-500'
                  }`}
                >
                  Archived
                </button>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {threadsLoading ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                <p className="text-slate-500 text-sm">
                  Loading your conversations...
                </p>
              </div>
            ) : isGC ? (
              projectGroups.length > 0 ? (
                <div className="divide-y divide-slate-100">
                  {projectGroups.map((project) => (
                    <button
                      key={project.projectKey}
                      type="button"
                      onClick={() => {
                        setSelectedProjectKey(project.projectKey);
                        if (
                          activeThread &&
                          activeThread.project_name !== project.projectName
                        ) {
                          setActiveThreadId(null);
                        }
                      }}
                      className={`w-full text-left px-4 py-3 flex items-center justify-between gap-2 ${
                        selectedProjectKey === project.projectKey
                          ? 'bg-slate-50'
                          : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex flex-col min-w-0">
                        <span className="text-sm font-medium text-slate-900 truncate">
                          {project.projectName}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {project.threads.length} trade
                          {project.threads.length !== 1 && 's'}
                        </span>
                      </div>
                      {project.unreadCount > 0 && (
                        <span className="min-w-[18px] h-[18px] rounded-full bg-slate-900 text-[10px] text-white flex items-center justify-center px-1">
                          {project.unreadCount > 9
                            ? '9+'
                            : project.unreadCount}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              ) : normalizedThreads.length > 0 ? (
                <div className="text-center py-12 px-4">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Filter className="w-7 h-7 text-blue-500/60" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 mb-1">
                    No matches
                  </h3>
                  <p className="text-slate-500 text-sm">
                    No projects match your current filters
                  </p>
                </div>
              ) : (
                <div className="text-center py-12 px-4">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                    <MessageSquare className="w-7 h-7 text-blue-500/60" />
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 mb-1">
                    No conversations yet
                  </h3>
                  <p className="text-slate-500 text-sm">
                    Start a conversation from Explore or your Rolodex
                  </p>
                </div>
              )
            ) : filteredThreads.length > 0 ? (
              <div className="divide-y divide-slate-100">
                {filteredThreads.map((thread) => {
                  const isActive = thread.id === activeThreadId;
                  const contactProfile = getContactProfile(
                    thread,
                    user?.email,
                    profileMap
                  );

                  return (
                    <ThreadItem
                      key={thread.id}
                      thread={thread}
                      contactProfile={contactProfile}
                      isActive={isActive}
                      unreadCount={thread.myUnreadCount}
                      isPinned={thread.isPinned}
                      isArchived={thread.isArchived}
                      isMuted={thread.isMuted}
                      onClick={() => setActiveThreadId(thread.id)}
                      onDelete={() => deleteThread.mutate(thread)}
                      onTogglePinned={() =>
                        togglePinThread.mutate(thread)
                      }
                      onToggleReadUnread={() =>
                        toggleReadUnreadThread.mutate(thread)
                      }
                      onArchive={() =>
                        archiveThread.mutate(thread)
                      }
                      onToggleMuted={() =>
                        toggleMuteThread.mutate(thread)
                      }
                    />
                  );
                })}
              </div>
            ) : normalizedThreads.length > 0 ? (
              <div className="text-center py-12 px-4">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Filter className="w-7 h-7 text-blue-500/60" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-1">
                  No matches
                </h3>
                <p className="text-slate-500 text-sm">
                  No conversations match your filter
                </p>
              </div>
            ) : (
              <div className="text-center py-12 px-4">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                  <MessageSquare className="w-7 h-7 text-blue-500/60" />
                </div>
                <h3 className="text-lg font-medium text-slate-900 mb-1">
                  No conversations yet
                </h3>
                <p className="text-slate-500 text-sm">
                  Start a conversation from Explore or your Rolodex
                </p>
              </div>
            )}
          </div>
        </div>

        {/* MIDDLE: trades at selected project (GC only) */}
        {isGC && (
          <div className="hidden md:flex w-72 border-r border-slate-100 bg-white flex-col">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-medium text-slate-900">
                Trades at project
              </p>
              <p className="text-xs text-slate-500 mt-0.5">
                {selectedProjectKey || 'Select a project'}
              </p>
            </div>

            <div className="flex-1 overflow-y-auto">
              {selectedProjectKey && threadsForSelectedProject.length > 0 ? (
                <div className="divide-y divide-slate-100">
                  {threadsForSelectedProject.map((thread) => {
                    const isActive = thread.id === activeThreadId;
                    const contactProfile = getContactProfile(
                      thread,
                      user?.email,
                      profileMap
                    );

                    return (
                      <ThreadItem
                        key={thread.id}
                        thread={thread}
                        contactProfile={contactProfile}
                        isActive={isActive}
                        unreadCount={thread.myUnreadCount}
                        isPinned={thread.isPinned}
                        isArchived={thread.isArchived}
                        isMuted={thread.isMuted}
                        onClick={() => setActiveThreadId(thread.id)}
                        onDelete={() =>
                          deleteThread.mutate(thread)
                        }
                        onTogglePinned={() =>
                          togglePinThread.mutate(thread)
                        }
                        onToggleReadUnread={() =>
                          toggleReadUnreadThread.mutate(thread)
                        }
                        onArchive={() =>
                          archiveThread.mutate(thread)
                        }
                        onToggleMuted={() =>
                          toggleMuteThread.mutate(thread)
                        }
                      />
                    );
                  })}
                </div>
              ) : selectedProjectKey ? (
                <div className="text-center py-10 px-4">
                  <p className="text-sm text-slate-500">
                    No trades are messaging on this project yet.
                  </p>
                </div>
              ) : (
                <div className="text-center py-10 px-4">
                  <p className="text-sm text-slate-500">
                    Select a project on the left to see its trades.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* RIGHT: chat */}
        <div className="flex-1 hidden md:flex flex-col">
          {activeThread ? (
            <>
              <div className="bg-white border-b border-slate-100 px-4 py-3">
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setActiveThreadId(null)}
                    className="md:hidden p-2.5 -ml-2 mr-1 hover:bg-slate-100 rounded-xl active:bg-slate-200 transition-colors"
                    aria-label="Back to conversations"
                  >
                    <ArrowLeft className="w-5 h-5 text-slate-600" />
                  </button>
                  <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
                    {activeContactProfile?.profile_photo_url ? (
                      <img
                        src={activeContactProfile.profile_photo_url}
                        alt=""
                        className="w-full h-full object-cover rounded-xl"
                      />
                    ) : (
                      <Building2 className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {activeThread.project_name}
                    </p>
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-slate-500">
                        {activeContactProfile?.company_name}
                      </p>
                      {activeContactProfile?.trade_category && (
                        <Badge variant="secondary" className="text-xs">
                          {activeContactProfile.trade_category.replace(/_/g, ' ')}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto px-4 py-4">
                {messagesLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                  </div>
                ) : sortedMessages.length > 0 ? (
                  <div className="space-y-4">
                    {Object.entries(groupedMessages).map(
                      ([date, dateMessages]) => (
                        <div key={date}>
                          <div className="flex items-center justify-center mb-4">
                            <span className="text-xs text-slate-400 bg-white px-3 py-1 rounded-full">
                              {date}
                            </span>
                          </div>
                          <div className="space-y-2">
                            {dateMessages.map((message) => (
                              <ChatBubble
                                key={message.id}
                                message={message}
                                isSender={message.sender_id === user?.email}
                              />
                            ))}
                          </div>
                        </div>
                      )
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-slate-500">
                      No messages yet. Start the conversation!
                    </p>
                  </div>
                )}
              </div>

              <div className="bg-white border-t border-slate-100 p-4 pb-[calc(1rem+env(safe-area-inset-bottom,0px))]">
                <form
                  onSubmit={handleSend}
                  className="flex items-center gap-2"
                >
                  <div className="flex items-center gap-2 flex-1">
                    <div className="relative">
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        className="h-11 w-11 border-slate-200"
                        onClick={() =>
                          setShowQuickActions((prev) => !prev)
                        }
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                      {showQuickActions && (
                        <div className="absolute bottom-12 left-0 z-20 w-56 bg-white border border-slate-200 rounded-xl shadow-lg py-2">
                          <button
                            type="button"
                            className="w-full text-left px-3 py-1.5 text-sm hover:bg-slate-50"
                            onClick={() => {
                              setShowQuickActions(false);
                              if (fileInputRef.current) {
                                fileInputRef.current.click();
                              }
                            }}
                          >
                            Attach photo / file
                          </button>
                          <div className="border-t border-slate-100 my-1" />
                          <button
                            type="button"
                            className="w-full text-left px-3 py-1.5 text-sm hover:bg-slate-50"
                            onClick={() => {
                              setShowQuickActions(false);
                              handleQuickQuote();
                            }}
                          >
                            Send Quote
                          </button>
                          <button
                            type="button"
                            className="w-full text-left px-3 py-1.5 text-sm hover:bg-slate-50"
                            onClick={() => {
                              setShowQuickActions(false);
                              handleQuickChangeOrder();
                            }}
                          >
                            Send Change Order
                          </button>
                          <button
                            type="button"
                            className="w-full text-left px-3 py-1.5 text-sm hover:bg-slate-50"
                            onClick={() => {
                              setShowQuickActions(false);
                              handleQuickInvoice();
                            }}
                          >
                            Send Invoice
                          </button>
                          <button
                            type="button"
                            className="w-full text-left px-3 py-1.5 text-sm hover:bg-slate-50"
                            onClick={() => {
                              setShowQuickActions(false);
                              handleQuickPunchItem();
                            }}
                          >
                            Create Punch Item
                          </button>
                        </div>
                      )}
                    </div>

                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyDown={handleKeyDown}
                      placeholder="Type a message..."
                      className="flex-1 h-11 bg-slate-50 border-slate-200"
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={!newMessage.trim() || sendMessage.isPending}
                    className="h-11 px-4 bg-slate-900 hover:bg-slate-800 disabled:opacity-50"
                  >
                    {sendMessage.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>

                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    onChange={handleFileChange}
                  />
                </form>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center px-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <MessageSquare className="w-7 h-7 text-slate-400" />
                </div>
                <p className="text-slate-500 text-sm">
                  {isGC
                    ? 'Select a project and trade to start messaging'
                    : 'Select a conversation to start messaging'}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      <RolodexContactSelectionModal
        isOpen={showContactSelection}
        onClose={() => setShowContactSelection(false)}
        contacts={rolodexProfiles}
        onSelectContact={handleSelectContact}
      />

      <ThreadSelectionModal
        isOpen={showThreadSelection}
        onClose={() => setShowThreadSelection(false)}
        contact={selectedContact}
        threads={selectedContactThreads}
        onSelectThread={(threadId) => {
          setActiveThreadId(threadId);
          setShowThreadSelection(false);
        }}
        onCreateNew={async (projectName) => {
          const newThread = await findOrCreateThread({
            currentUserEmail: user.email,
            contactEmail: selectedContact.created_by,
            projectName,
          });
          setActiveThreadId(newThread.id);
          setShowThreadSelection(false);
          queryClient.invalidateQueries(['myThreads']);
        }}
      />

      <NewThreadModal
        isOpen={showNewThread}
        onClose={() => setShowNewThread(false)}
        onThreadCreated={(threadId) => {
          setActiveThreadId(threadId);
          setShowNewThread(false);
          queryClient.invalidateQueries(['myThreads']);
        }}
      />

      <StructuredMessageModal
        type={structuredModalType}
        isOpen={!!structuredModalType}
        contactName={activeContactProfile?.company_name}
        onClose={() => setStructuredModalType(null)}
        onSubmit={(payload) => {
          sendStructuredMessage.mutate(payload);
          setStructuredModalType(null);
        }}
      />
    </div>
  );
}