// Route configuration for the unified application.
//
// This file defines a simple array of route descriptors used by
// `Layout` and `Pages` to build navigation and route definitions. Each
// entry has a `name` (used internally to resolve components), a
// `path` (the URL path to the page), a human‑friendly `label` for
// display in navigation and an optional `inNav` flag indicating
// whether the route should appear in the primary navigation bar.

export const APP_ROUTES = [
  // Core product pages from the trade‑connect application
  { name: 'Onboarding',   path: '/Onboarding',   label: 'Onboarding',   inNav: true },
  { name: 'Dashboard',    path: '/Dashboard',    label: 'Dashboard',    inNav: true },
  { name: 'Explore',      path: '/Explore',      label: 'Explore',      inNav: true },
  { name: 'Rolodex',      path: '/Rolodex',      label: 'Rolodex',      inNav: true },
  { name: 'Messages',     path: '/Messages',     label: 'Messages',     inNav: true },
  { name: 'MyCard',       path: '/MyCard',       label: 'My card',      inNav: true },

  // Project management pages from the project‑connect application
  { name: 'Projects',       path: '/Projects',       label: 'Projects',   inNav: true },
  { name: 'Directory',      path: '/Directory',      label: 'Directory',  inNav: true },
  { name: 'Profile',        path: '/Profile',        label: 'Profile',    inNav: true },
  { name: 'ProjectDetail',  path: '/ProjectDetail' },
  { name: 'DemoProject',    path: '/DemoProject' }
];

// Helper for creating canonical URLs from route names. This is kept for
// backwards compatibility with existing code that calls
// `createPageUrl(pageName)`. It maps a route name to its configured
// path, falling back to a simple slug if the route is not defined.
export function createPageUrl(pageName) {
  const route = APP_ROUTES.find((r) => r.name === pageName);
  if (route) return route.path;
  return '/' + pageName.toLowerCase().replace(/ /g, '-');
}