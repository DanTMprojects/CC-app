import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Building2, Search } from 'lucide-react';

export default function RolodexContactSelectionModal({ 
  isOpen, 
  onClose, 
  contacts,
  onSelectContact 
}) {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredContacts = contacts.filter(contact => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      contact.company_name?.toLowerCase().includes(query) ||
      contact.owner_name?.toLowerCase().includes(query)
    );
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">
            Choose a contact
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search contacts..."
              className="pl-10 h-11 bg-slate-50 border-slate-200"
            />
          </div>

          {/* Contact List */}
          <div className="max-h-96 overflow-y-auto space-y-2">
            {filteredContacts.length > 0 ? (
              filteredContacts.map((contact) => (
                <button
                  key={contact.id}
                  onClick={() => onSelectContact(contact)}
                  className="w-full p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all text-left"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
                      {contact.profile_photo_url ? (
                        <img 
                          src={contact.profile_photo_url} 
                          alt={contact.company_name}
                          className="w-full h-full object-cover rounded-xl"
                        />
                      ) : (
                        <Building2 className="w-5 h-5 text-slate-400" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-slate-900">
                        {contact.company_name}
                      </p>
                      <p className="text-sm text-slate-500">
                        {contact.owner_name}
                      </p>
                    </div>
                  </div>
                </button>
              ))
            ) : (
              <p className="text-sm text-slate-500 text-center py-8">
                No contacts found
              </p>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}