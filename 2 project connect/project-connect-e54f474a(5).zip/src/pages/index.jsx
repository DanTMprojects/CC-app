import Layout from "./Layout.jsx";

import Projects from "./Projects";
import ProjectDetail from "./ProjectDetail";
import Profile from "./Profile";
import Directory from "./Directory";
import BidBoard from "./BidBoard";
import DemoProject from "./DemoProject";

import {
  BrowserRouter as Router,
  Route,
  Routes,
  useLocation,
  Navigate,
} from "react-router-dom";

import { APP_ROUTES } from "@/components/config/routes";

// Figure out which "page name" we are on (for nav highlighting)
function getCurrentPageName(pathname) {
  const match = APP_ROUTES.find((route) =>
    pathname.startsWith(route.path)
  );
  return match?.name || "Projects";
}

function PagesContent() {
  const location = useLocation();
  const currentPageName = getCurrentPageName(location.pathname);

  return (
    <Layout currentPageName={currentPageName}>
      <Routes>
        <Route path="/Projects" element={<Projects />} />
        <Route path="/ProjectDetail" element={<ProjectDetail />} />
        <Route path="/Directory" element={<Directory />} />
        <Route path="/BidBoard" element={<BidBoard />} />
        <Route path="/DemoProject" element={<DemoProject />} />
        <Route path="/Profile" element={<Profile />} />
        <Route path="*" element={<Navigate to="/Projects" replace />} />
      </Routes>
    </Layout>
  );
}

export default function Pages() {
  return (
    <Router>
      <PagesContent />
    </Router>
  );
}