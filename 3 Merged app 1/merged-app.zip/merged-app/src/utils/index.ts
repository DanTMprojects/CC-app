


// @ts-nocheck
import { APP_ROUTES } from '@/components/config/routes';

/**
 * Convert a page name into a concrete URL path.
 *
 * The original implementation simply lower‑cased the page name and
 * replaced spaces with hyphens. With the merger of two distinct
 * applications the canonical path for a page may no longer follow
 * that convention (for example `/Dashboard` instead of `/dashboard`).
 * This helper now consults the global route configuration to find
 * the correct path. If the supplied `pageName` contains a query
 * string (e.g. "ProjectDetail?id=123") the name and query parts
 * will be split and recombined once the base path has been
 * resolved. If no route is found the function falls back to the
 * original slugifying behaviour.
 */
export function createPageUrl(pageName: string): string {
    if (!pageName) return '/';
    // Split any query string from the page name
    const [namePart, queryString] = pageName.split('?');
    // Look up the route by name
    const route = APP_ROUTES.find((r) => r.name === namePart);
    let basePath: string;
    if (route) {
        basePath = route.path;
    } else {
        basePath = '/' + namePart.toLowerCase().replace(/ /g, '-');
    }
    return queryString ? `${basePath}?${queryString}` : basePath;
}