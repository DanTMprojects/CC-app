import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Compass, BookOpen, MessageSquare, UserCircle, Plus, Search, Filter } from 'lucide-react';

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    checkOnboarding();
  }, []);

  const checkOnboarding = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);

    // Check if user has completed onboarding
    const profiles = await base44.entities.TradeProfile.filter({
      created_by: currentUser.email
    });

    if (profiles.length === 0 || !profiles[0].onboarding_complete) {
      navigate(createPageUrl('Onboarding'));
    }
  };

  const { data: profile } = useQuery({
    queryKey: ['myProfile'],
    queryFn: async () => {
      const profiles = await base44.entities.TradeProfile.filter({
        created_by: user?.email
      });
      return profiles[0] || null;
    },
    enabled: !!user
  });

  const { data: unreadCount = 0 } = useQuery({
    queryKey: ['unreadMessages'],
    queryFn: async () => {
      const messages = await base44.entities.DirectMessage.filter({
        receiver_id: user?.email,
        read: false
      });
      return messages.length;
    },
    enabled: !!user
  });

  const menuItems = [
    {
      title: 'Explore Trades',
      description: 'Discover contractors and trades nearby',
      icon: Compass,
      href: 'Explore',
      color: 'bg-blue-500'
    },
    {
      title: 'My Rolodex',
      description: 'Your saved connections',
      icon: BookOpen,
      href: 'Rolodex',
      color: 'bg-emerald-500'
    },
    {
      title: 'Messages',
      description: 'Project conversations',
      icon: MessageSquare,
      href: 'Messages',
      color: 'bg-purple-500',
      badge: unreadCount > 0 ? unreadCount : null
    },
    {
      title: 'My Card',
      description: 'View and edit your profile',
      icon: UserCircle,
      href: 'MyCard',
      color: 'bg-amber-500'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-2xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">TradeRolodex</h1>
              {profile && (
                <p className="text-slate-500 mt-0.5">Welcome back, {profile.owner_name}</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 gap-4">
          {menuItems.map((item) => (
            <Link
              key={item.title}
              to={createPageUrl(item.href)}
              className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-lg hover:shadow-slate-100 transition-all duration-300 group"
            >
              <div className="flex items-center gap-4">
                <div className={`w-14 h-14 rounded-xl ${item.color} flex items-center justify-center flex-shrink-0`}>
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-semibold text-slate-900">{item.title}</h3>
                    {item.badge && (
                      <span className="w-5 h-5 bg-red-500 text-white text-xs font-medium rounded-full flex items-center justify-center">
                        {item.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-slate-500 text-sm mt-0.5">{item.description}</p>
                </div>
                <div className="text-slate-300 group-hover:text-slate-400 transition-colors">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <h2 className="text-sm font-medium text-slate-500 mb-3 px-1">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            <Link
              to={createPageUrl('Explore')}
              className="bg-white rounded-xl p-4 border border-slate-100 hover:shadow-md transition-all text-center"
            >
              <Search className="w-5 h-5 text-slate-400 mx-auto" />
              <span className="text-sm font-medium text-slate-700 mt-2 block">Find Trades</span>
            </Link>
            <Link
              to={createPageUrl('MyCard') + '?share=true'}
              className="bg-white rounded-xl p-4 border border-slate-100 hover:shadow-md transition-all text-center"
            >
              <Plus className="w-5 h-5 text-slate-400 mx-auto" />
              <span className="text-sm font-medium text-slate-700 mt-2 block">Invite Contact</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}