import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ArrowRight, ArrowLeft, Upload, X, Image, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ProjectsForm({ data, onChange, onNext, onBack }) {
  const [uploading, setUploading] = useState(null);
  const projects = data.projects || [
    { photos: [], description: '' },
    { photos: [], description: '' },
    { photos: [], description: '' }
  ];

  const updateProject = (index, field, value) => {
    const updated = [...projects];
    updated[index] = { ...updated[index], [field]: value };
    onChange({ ...data, projects: updated });
  };

  const handlePhotoUpload = async (projectIndex, e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    const currentPhotos = projects[projectIndex].photos || [];
    const remainingSlots = 5 - currentPhotos.length;
    const filesToUpload = files.slice(0, remainingSlots);

    setUploading(projectIndex);
    
    const uploadedUrls = [];
    for (const file of filesToUpload) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      uploadedUrls.push(file_url);
    }
    
    updateProject(projectIndex, 'photos', [...currentPhotos, ...uploadedUrls]);
    setUploading(null);
  };

  const removePhoto = (projectIndex, photoIndex) => {
    const updated = [...projects[projectIndex].photos];
    updated.splice(photoIndex, 1);
    updateProject(projectIndex, 'photos', updated);
  };

  const isValid = projects.every(p => p.photos.length === 5 && p.description.trim().length > 0);

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-slate-900">Showcase your work</h2>
        <p className="text-slate-500 mt-2">Add 3 projects with 5 photos each to build your portfolio</p>
      </div>

      <div className="space-y-8">
        {projects.map((project, projectIndex) => (
          <div key={projectIndex} className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Project {projectIndex + 1}</h3>
            
            <div className="space-y-4">
              <div>
                <Label className="text-slate-700 mb-2 block">
                  Photos ({project.photos.length}/5 required)
                </Label>
                <div className="grid grid-cols-5 gap-2">
                  {[0, 1, 2, 3, 4].map((photoIndex) => (
                    <div
                      key={photoIndex}
                      className="aspect-square rounded-xl bg-white border-2 border-dashed border-slate-200 flex items-center justify-center relative overflow-hidden"
                    >
                      {project.photos[photoIndex] ? (
                        <>
                          <img
                            src={project.photos[photoIndex]}
                            alt={`Project ${projectIndex + 1} photo ${photoIndex + 1}`}
                            className="w-full h-full object-cover"
                          />
                          <button
                            onClick={() => removePhoto(projectIndex, photoIndex)}
                            className="absolute top-1 right-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </>
                      ) : (
                        <div className="text-slate-300">
                          <Image className="w-6 h-6" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                
                {project.photos.length < 5 && (
                  <div className="mt-3">
                    <label className="cursor-pointer">
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={(e) => handlePhotoUpload(projectIndex, e)}
                        className="hidden"
                      />
                      <div className="flex items-center justify-center gap-2 py-2.5 px-4 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
                        {uploading === projectIndex ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            Uploading...
                          </>
                        ) : (
                          <>
                            <Upload className="w-4 h-4" />
                            Upload Photos
                          </>
                        )}
                      </div>
                    </label>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label className="text-slate-700">
                  Description ({(project.description || '').length}/280)
                </Label>
                <Textarea
                  value={project.description || ''}
                  onChange={(e) => {
                    if (e.target.value.length <= 280) {
                      updateProject(projectIndex, 'description', e.target.value);
                    }
                  }}
                  placeholder="Describe this project..."
                  className="min-h-[80px] bg-white border-slate-200 resize-none"
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-3 pt-4">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex-1 h-12 border-slate-200"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button
          onClick={onNext}
          disabled={!isValid}
          className="flex-1 h-12 bg-slate-900 hover:bg-slate-800 text-white font-medium"
        >
          Continue
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}