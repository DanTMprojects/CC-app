import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createPageUrl } from '@/utils';
import { findOrCreateThread, dedupeThreads, getContactProfile } from '@/components/utils/threadUtils';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Send, MapPin, Building2, Loader2, MessageSquare, Filter, Plus } from 'lucide-react';
import ThreadItem from '@/components/messaging/ThreadItem';
import ChatBubble from '@/components/messaging/ChatBubble';
import RolodexContactSelectionModal from '@/components/messaging/RolodexContactSelectionModal';
import ThreadSelectionModal from '@/components/messaging/ThreadSelectionModal';
import NewThreadModal from '@/components/messaging/NewThreadModal';
import moment from 'moment';

export default function Messages() {
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [myProfile, setMyProfile] = useState(null);
  const [activeThreadId, setActiveThreadId] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [tradeFilter, setTradeFilter] = useState('all');
  const [showContactSelection, setShowContactSelection] = useState(false);
  const [showThreadSelection, setShowThreadSelection] = useState(false);
  const [showNewThread, setShowNewThread] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [selectedContactThreads, setSelectedContactThreads] = useState([]);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadUser();
    
    // Check for thread param in URL
    const urlParams = new URLSearchParams(window.location.search);
    const threadId = urlParams.get('thread');
    if (threadId) {
      setActiveThreadId(threadId);
    }
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    
    const profiles = await base44.entities.TradeProfile.filter({
      created_by: currentUser.email
    });
    if (profiles.length > 0) {
      setMyProfile(profiles[0]);
    }
  };

  const { data: threads = [], isLoading: threadsLoading } = useQuery({
    queryKey: ['myThreads', user?.email],
    queryFn: async () => {
      const userThreadsA = await base44.entities.ProjectThread.filter({ user_a_id: user?.email });
      const userThreadsB = await base44.entities.ProjectThread.filter({ user_b_id: user?.email });
      const allThreads = [...userThreadsA, ...userThreadsB];
      return allThreads.sort((a, b) => 
        new Date(b.last_message_at || b.created_date) - new Date(a.last_message_at || a.created_date)
      );
    },
    enabled: !!user
  });

  // De-duplicate threads by user pair + project name
  const normalizedThreads = dedupeThreads(threads);

  const uniqueProfileIds = React.useMemo(() => {
    const profileIds = normalizedThreads.flatMap(t => [t.user_a_profile_id, t.user_b_profile_id]).filter(Boolean);
    return [...new Set(profileIds)].sort();
  }, [normalizedThreads]);

  const { data: profiles = [] } = useQuery({
    queryKey: ['threadProfiles', uniqueProfileIds],
    queryFn: async () => {
      if (uniqueProfileIds.length === 0) return [];
      
      // TODO: Optimize once Base44 supports multi-ID filter: base44.entities.TradeProfile.filter({ id: uniqueProfileIds })
      const allProfiles = await base44.entities.TradeProfile.list();
      return allProfiles.filter(p => uniqueProfileIds.includes(p.id));
    },
    enabled: uniqueProfileIds.length > 0
  });

  const profileMap = profiles.reduce((acc, p) => {
    acc[p.id] = p;
    return acc;
  }, {});

  const { data: rolodexConnections = [] } = useQuery({
    queryKey: ['myConnections', user?.id],
    queryFn: () => base44.entities.RolodexConnection.filter({ owner_user_id: user?.id }),
    enabled: !!user
  });

  const { data: rolodexProfiles = [] } = useQuery({
    queryKey: ['rolodexProfiles', rolodexConnections],
    queryFn: async () => {
      const profileIds = rolodexConnections.map(c => c.contact_profile_id);
      if (profileIds.length === 0) return [];
      
      const allProfiles = await base44.entities.TradeProfile.list();
      return allProfiles.filter(p => profileIds.includes(p.id));
    },
    enabled: rolodexConnections.length > 0
  });

  // Filter threads by trade category
  const filteredThreads = useMemo(() => {
    return normalizedThreads.filter((thread) => {
      if (tradeFilter === 'all') return true;

      const contactProfile = getContactProfile(thread, user?.email, profileMap);
      return contactProfile?.trade_category === tradeFilter;
    });
  }, [normalizedThreads, tradeFilter, user?.email, profileMap]);

  const activeThread = normalizedThreads.find(t => t.id === activeThreadId);
  const activeContactProfileId = activeThread
    ? (activeThread.user_a_id === user?.email ? activeThread.user_b_profile_id : activeThread.user_a_profile_id)
    : null;
  const activeContactProfile = activeContactProfileId ? profileMap[activeContactProfileId] : null;

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['threadMessages', activeThreadId],
    queryFn: () => base44.entities.DirectMessage.filter({ thread_id: activeThreadId }),
    enabled: !!activeThreadId,
    refetchInterval: 5000
  });

  // Deduplicate messages by id before sorting
  const uniqueMessages = Object.values(
    messages.reduce((acc, msg) => {
      acc[msg.id] = msg;
      return acc;
    }, {})
  );

  const sortedMessages = uniqueMessages.sort((a, b) => 
    new Date(a.created_date) - new Date(b.created_date)
  );

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [sortedMessages]);

  // Mark thread as read when opened
  useEffect(() => {
    if (!activeThread || !user?.email) return;

    const isUserA = activeThread.user_a_id === user.email;
    const unreadField = isUserA ? 'unread_count_a' : 'unread_count_b';
    const currentUnread = activeThread[unreadField] || 0;

    if (currentUnread > 0) {
      base44.entities.ProjectThread.update(activeThreadId, {
        [unreadField]: 0
      }).then(() => {
        queryClient.invalidateQueries(['myThreads']);
      });
    }
  }, [activeThreadId, activeThread, user?.email, queryClient]);

  // Handle active thread when filter changes
  useEffect(() => {
    const validIds = new Set(filteredThreads.map(t => t.id));
    if (activeThreadId && !validIds.has(activeThreadId)) {
      setActiveThreadId(filteredThreads[0]?.id || null);
    }
  }, [tradeFilter, filteredThreads, activeThreadId]);

  const deleteThread = useMutation({
    mutationFn: async (thread) => {
      // Delete all messages in thread
      const messages = await base44.entities.DirectMessage.filter({ thread_id: thread.id });
      for (const msg of messages) {
        await base44.entities.DirectMessage.delete(msg.id);
      }
      // Delete thread
      await base44.entities.ProjectThread.delete(thread.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['myThreads']);
      setActiveThreadId(null);
    },
    onError: (err) => {
      console.error(err);
      alert('Failed to delete conversation. Please try again.');
    }
  });

  const sendMessage = useMutation({
    mutationFn: async () => {
      if (!newMessage.trim() || !activeThread) return;

      const receiverId = activeThread.user_a_id === user.email 
        ? activeThread.user_b_id 
        : activeThread.user_a_id;

      await base44.entities.DirectMessage.create({
        thread_id: activeThreadId,
        sender_id: user.email,
        receiver_id: receiverId,
        message_text: newMessage.trim()
      });

      // Increment unread count for receiver
      const isUserA = activeThread.user_a_id === user.email;
      const unreadField = isUserA ? 'unread_count_b' : 'unread_count_a';
      const currentUnread = activeThread[unreadField] || 0;

      await base44.entities.ProjectThread.update(activeThreadId, {
        last_message: newMessage.trim(),
        last_message_at: new Date().toISOString(),
        [unreadField]: currentUnread + 1
      });
    },
    onSuccess: () => {
      setNewMessage('');
      queryClient.invalidateQueries(['threadMessages', activeThreadId]);
      queryClient.invalidateQueries(['myThreads']);
    },
    onError: (err) => {
      console.error(err);
      alert('Message failed to send. Please try again.');
    }
  });

  const handleSend = (e) => {
    e?.preventDefault();
    if (sendMessage.isPending || !newMessage.trim()) return;
    sendMessage.mutate();
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSelectContact = useCallback(async (contact) => {
    setShowContactSelection(false);
    
    // Find all threads with this contact
    const userThreadsA = await base44.entities.ProjectThread.filter({ 
      user_a_id: user.email,
      user_b_id: contact.created_by
    });
    const userThreadsB = await base44.entities.ProjectThread.filter({ 
      user_a_id: contact.created_by,
      user_b_id: user.email
    });
    const allThreads = [...userThreadsA, ...userThreadsB].sort((a, b) => 
      new Date(b.last_message_at || b.created_date) - new Date(a.last_message_at || a.created_date)
    );
    
    setSelectedContact(contact);
    setSelectedContactThreads(allThreads);
    setShowThreadSelection(true);
  }, [user?.email]);

  const handleSelectThread = useCallback((thread) => {
    setShowThreadSelection(false);
    setActiveThreadId(thread.id);
  }, []);

  const handleNewThreadFromSelection = useCallback(() => {
    setShowThreadSelection(false);
    setShowNewThread(true);
  }, []);

  const handleCreateThread = useCallback(async (projectName) => {
    const thread = await findOrCreateThread({
      projectName,
      currentUserEmail: user.email,
      contactUserEmail: selectedContact.created_by,
      currentProfileId: myProfile.id,
      contactProfileId: selectedContact.id,
    });

    setShowNewThread(false);
    queryClient.invalidateQueries(['myThreads']);
    setActiveThreadId(thread.id);
  }, [user?.email, selectedContact, myProfile, queryClient]);

  // Group messages by date
  const groupedMessages = sortedMessages.reduce((groups, message) => {
    const date = moment(message.created_date).format('MMMM D, YYYY');
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(message);
    return groups;
  }, {});

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-slate-100">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link to={createPageUrl('Dashboard')} className="p-2 -ml-2 hover:bg-slate-100 rounded-xl transition-colors">
                <ArrowLeft className="w-5 h-5 text-slate-600" />
              </Link>
              <h1 className="text-xl font-bold text-slate-900">Messages</h1>
            </div>
            <Button 
              onClick={() => setShowContactSelection(true)}
              className="h-10 px-4 bg-slate-900 hover:bg-slate-800"
            >
              <Plus className="w-4 h-4 mr-2" />
              New
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 max-w-4xl mx-auto w-full flex">
        {/* Thread List */}
        <div className={`w-full md:w-80 bg-white border-r border-slate-100 flex-shrink-0 ${activeThreadId ? 'hidden md:block' : ''}`}>
          {/* Filter */}
          <div className="p-3 border-b border-slate-100">
            <Select value={tradeFilter} onValueChange={setTradeFilter}>
              <SelectTrigger className="h-10 bg-slate-50 border-slate-200">
                <Filter className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Filter by trade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Trades</SelectItem>
                <SelectItem value="general_contractor">General Contractor</SelectItem>
                <SelectItem value="electrician">Electrician</SelectItem>
                <SelectItem value="plumber">Plumber</SelectItem>
                <SelectItem value="hvac">HVAC</SelectItem>
                <SelectItem value="carpenter">Carpenter</SelectItem>
                <SelectItem value="roofer">Roofer</SelectItem>
                <SelectItem value="excavator">Excavator</SelectItem>
                <SelectItem value="painter">Painter</SelectItem>
                <SelectItem value="mason">Mason</SelectItem>
                <SelectItem value="landscaper">Landscaper</SelectItem>
                <SelectItem value="flooring">Flooring</SelectItem>
                <SelectItem value="drywall">Drywall</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {threadsLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
            </div>
          ) : filteredThreads.length > 0 ? (
            <div className="divide-y divide-slate-100">
              {filteredThreads.map((thread) => {
                const contactProfileId = thread.user_a_id === user?.email
                  ? thread.user_b_profile_id
                  : thread.user_a_profile_id;
                const contactProfile = profileMap[contactProfileId];
                const isUserA = thread.user_a_id === user?.email;
                const unreadCount = isUserA ? (thread.unread_count_a || 0) : (thread.unread_count_b || 0);
                return (
                  <ThreadItem
                    key={thread.id}
                    thread={thread}
                    contactProfile={contactProfile}
                    onClick={() => setActiveThreadId(thread.id)}
                    isActive={thread.id === activeThreadId}
                    onDelete={(t) => deleteThread.mutate(t)}
                    unreadCount={unreadCount}
                  />
                );
              })}
            </div>
          ) : normalizedThreads.length > 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Filter className="w-7 h-7 text-blue-500/60" />
              </div>
              <h3 className="text-lg font-medium text-slate-900 mb-1">No matches</h3>
              <p className="text-slate-500 text-sm">No conversations match your filter</p>
            </div>
          ) : (
            <div className="text-center py-12 px-4">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
                <MessageSquare className="w-7 h-7 text-blue-500/60" />
              </div>
              <h3 className="text-lg font-medium text-slate-900 mb-1">No conversations yet</h3>
              <p className="text-slate-500 text-sm">Start a conversation from Explore or your Rolodex</p>
            </div>
          )}
        </div>

        {/* Chat Area */}
        <div className={`flex-1 flex flex-col bg-slate-50 ${!activeThreadId ? 'hidden md:flex' : 'flex'}`}>
          {activeThread ? (
            <>
              {/* Chat Header */}
              <div className="bg-white border-b border-slate-100 px-4 py-3">
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setActiveThreadId(null)}
                    className="md:hidden p-2.5 -ml-2 mr-1 hover:bg-slate-100 rounded-xl active:bg-slate-200 transition-colors"
                    aria-label="Back to conversations"
                  >
                    <ArrowLeft className="w-5 h-5 text-slate-600" />
                  </button>
                  <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
                    {activeContactProfile?.profile_photo_url ? (
                      <img 
                        src={activeContactProfile.profile_photo_url} 
                        alt=""
                        className="w-full h-full object-cover rounded-xl"
                      />
                    ) : (
                      <Building2 className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      {activeThread.project_name}
                    </p>
                    <div className="flex items-center gap-2">
                      <p className="text-sm text-slate-500">
                        {activeContactProfile?.company_name}
                      </p>
                      {activeContactProfile?.trade_category && (
                        <Badge variant="secondary" className="text-xs">
                          {activeContactProfile.trade_category.replace(/_/g, ' ')}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto px-4 py-4">
                {messagesLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
                  </div>
                ) : sortedMessages.length > 0 ? (
                  <div className="space-y-4">
                    {Object.entries(groupedMessages).map(([date, dateMessages]) => (
                      <div key={date}>
                        <div className="flex items-center justify-center mb-4">
                          <span className="text-xs text-slate-400 bg-white px-3 py-1 rounded-full">
                            {date}
                          </span>
                        </div>
                        <div className="space-y-2">
                          {dateMessages.map((message) => (
                            <ChatBubble
                              key={message.id}
                              message={message}
                              isSender={message.sender_id === user?.email}
                            />
                          ))}
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p className="text-slate-500">No messages yet. Start the conversation!</p>
                  </div>
                )}
              </div>

              {/* Message Input */}
              <div className="bg-white border-t border-slate-100 p-4 pb-[calc(1rem+env(safe-area-inset-bottom,0px))]">
                <form onSubmit={handleSend} className="flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Type a message..."
                    className="flex-1 h-11 bg-slate-50 border-slate-200"
                  />
                  <Button 
                    type="submit" 
                    disabled={!newMessage.trim() || sendMessage.isPending}
                    className="h-11 px-4 bg-slate-900 hover:bg-slate-800 disabled:opacity-50"
                  >
                    {sendMessage.isPending ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center px-4">
              <div className="text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <MessageSquare className="w-7 h-7 text-slate-400" />
                </div>
                <p className="text-slate-500 text-sm">Select a conversation to start messaging</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <RolodexContactSelectionModal
        isOpen={showContactSelection}
        onClose={() => setShowContactSelection(false)}
        contacts={rolodexProfiles}
        onSelectContact={handleSelectContact}
      />

      <ThreadSelectionModal
        isOpen={showThreadSelection}
        onClose={() => setShowThreadSelection(false)}
        contactProfile={selectedContact}
        threads={selectedContactThreads}
        onSelectThread={handleSelectThread}
        onNewThread={handleNewThreadFromSelection}
      />

      <NewThreadModal
        isOpen={showNewThread}
        onClose={() => setShowNewThread(false)}
        contactProfile={selectedContact}
        onCreateThread={handleCreateThread}
      />
    </div>
  );
}