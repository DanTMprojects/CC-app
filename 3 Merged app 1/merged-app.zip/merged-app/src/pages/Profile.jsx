import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, LogOut, Star } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const trades = [
  { value: "general_contractor", label: "General Contractor" },
  { value: "electrician", label: "Electrician" },
  { value: "plumber", label: "Plumber" },
  { value: "carpenter", label: "Carpenter" },
  { value: "hvac", label: "HVAC" },
  { value: "painter", label: "Painter" },
  { value: "roofer", label: "Roofer" },
  { value: "mason", label: "Mason" },
  { value: "landscaper", label: "Landscaper" },
  { value: "flooring", label: "Flooring" },
  { value: "drywall", label: "Drywall" },
  { value: "other", label: "Other" }
];

export default function Profile() {
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    trade: "",
    company: "",
    phone: "",
    location: "",
    bio: ""
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      setFormData({
        trade: u.trade || "",
        company: u.company || "",
        phone: u.phone || "",
        location: u.location || "",
        bio: u.bio || ""
      });
    }).catch(() => {});
  }, []);

  const { data: myReviews = [] } = useQuery({
    queryKey: ["my-reviews", user?.email],
    queryFn: () => base44.entities.Review.filter({ reviewee_email: user?.email }, "-created_date"),
    enabled: !!user?.email
  });

  const reviewCount = myReviews.length;
  const avgRating = reviewCount > 0 
    ? myReviews.reduce((sum, r) => sum + (r.rating || 0), 0) / reviewCount 
    : null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await base44.auth.updateMe(formData);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleLogout = () => {
    base44.auth.logout(createPageUrl('Projects'));
  };

  return (
    <div className="min-h-screen bg-slate-400 text-slate-950">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link to={createPageUrl('Projects')}>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8 rounded-full border border-slate-800 text-slate-950 hover:text-slate-950 hover:bg-slate-300"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-lg font-semibold text-slate-950">Your profile</h1>
            <p className="text-xs text-slate-700">
              This is what GCs and trades will see when they add you to projects.
            </p>
          </div>
        </div>

        <div className="bg-white text-slate-900 rounded-2xl p-6 shadow-sm">
          {/* User Info Header */}
          <div className="flex items-center gap-4 mb-6 pb-6 border-b border-slate-100">
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center">
              <span className="text-lg font-semibold text-slate-600">
                {user?.full_name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '??'}
              </span>
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-900">{user?.full_name || 'Loading...'}</h2>
              <p className="text-xs text-slate-500">{user?.email}</p>
              {avgRating && (
                <div className="mt-2 inline-flex items-center rounded-full bg-yellow-50 text-yellow-800 px-2 py-0.5 text-[11px] border border-yellow-200">
                  <Star className="w-3 h-3 mr-1 text-yellow-500 fill-yellow-500" />
                  {avgRating.toFixed(1)} · {reviewCount} review{reviewCount === 1 ? "" : "s"}
                </div>
              )}
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="text-xs font-medium text-slate-700">Company name</label>
                <Input
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  placeholder="ABC Construction"
                  className="mt-1 h-10 text-sm"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700">What you do</label>
                <Select
                  value={formData.trade}
                  onValueChange={(value) => setFormData({ ...formData, trade: value })}
                >
                  <SelectTrigger className="mt-1 h-10 text-sm">
                    <SelectValue placeholder="Select your role" />
                  </SelectTrigger>
                  <SelectContent>
                    {trades.map((trade) => (
                      <SelectItem key={trade.value} value={trade.value}>
                        {trade.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="text-xs font-medium text-slate-700">Phone</label>
                <Input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="(555) 123-4567"
                  className="mt-1 h-10 text-sm"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-slate-700">Service area</label>
                <Input
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="e.g., Austin, TX"
                  className="mt-1 h-10 text-sm"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-medium text-slate-700">About you</label>
              <textarea
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                placeholder="Brief description of your experience and specialties..."
                rows={3}
                className="mt-1 block w-full rounded-md border border-slate-200 px-3 py-2 text-sm shadow-sm focus:outline-none focus:ring-1 focus:ring-sky-500 focus:border-sky-500"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleLogout}
                className="text-xs text-red-600 border-red-200 hover:bg-red-50"
              >
                <LogOut className="w-3 h-3 mr-1.5" />
                Log out
              </Button>

              <Button 
                type="submit" 
                disabled={saving}
                className="bg-sky-500 hover:bg-sky-600 text-xs px-4 h-9"
              >
                {saving ? "Saving..." : saved ? "Saved!" : "Save changes"}
              </Button>
            </div>
          </form>

          {/* Coming Soon Sections */}
          <div className="mt-6 border-t border-slate-100 pt-4 space-y-4">
            <div>
              <h2 className="text-sm font-semibold text-slate-900 mb-1">
                Portfolio (coming soon)
              </h2>
              <p className="text-xs text-slate-500">
                Trades will be able to showcase at least 3 projects with photos so GCs can quickly see the quality of work.
              </p>
            </div>

            <div>
              <h2 className="text-sm font-semibold text-slate-900 mb-1">
                References (coming soon)
              </h2>
              <p className="text-xs text-slate-500">
                Before bidding on jobs, trades will be asked to add at least 3 references that GCs can contact.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}