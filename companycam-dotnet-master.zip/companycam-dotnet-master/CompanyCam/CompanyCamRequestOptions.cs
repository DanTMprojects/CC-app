﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CompanyCam
{
    public class CompanyCamRequestOptions
    {
        public string ApiKey { get; set; }
        public string SecretKey { get; set; }
        public string UserEmailAddress { get; set; }
    }
}
