import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Users } from "lucide-react";
import TradeCard from "@/components/trades/TradeCard";
import ProjectPickerModal from "@/components/messages/ProjectPickerModal";
import { findOrCreateThread, ensureProjectTradeLink } from "@/components/messages/threadUtils";

export default function Trades() {
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [selectedContact, setSelectedContact] = useState(null);
  const [projectPickerOpen, setProjectPickerOpen] = useState(false);
  const navigate = useNavigate();

  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => base44.entities.Contact.list("-created_date"),
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  const filteredContacts = contacts.filter((contact) => {
    const matchesSearch =
      contact.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.company?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.email?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole = roleFilter === "all" || contact.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleStartChat = (contact) => {
    setSelectedContact(contact);
    setProjectPickerOpen(true);
  };

  const handleSelectProject = async (project) => {
    if (!selectedContact || !currentUser) return;

    try {
      // Ensure project-trade link exists
      await ensureProjectTradeLink(project.id, selectedContact.id, currentUser.email);

      // Find or create thread
      const thread = await findOrCreateThread(project.id, selectedContact.id);

      // Navigate to messages with thread ID
      const urlParams = new URLSearchParams();
      urlParams.set("thread", thread.id);
      urlParams.set("project", project.id);
      navigate(`${createPageUrl("Messages")}?${urlParams.toString()}`);
    } catch (error) {
      console.error("Error creating chat:", error);
    }
  };

  const handleCreateNewProject = () => {
    // Navigate to Projects page to create new project
    navigate(createPageUrl("Projects"));
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="h-64 rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-slate-900">Trades Directory</h1>
        <p className="text-slate-500 mt-1">Browse and connect with your trades</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            placeholder="Search trades..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Roles</SelectItem>
            <SelectItem value="subcontractor">Subcontractor</SelectItem>
            <SelectItem value="supplier">Supplier</SelectItem>
            <SelectItem value="architect">Architect</SelectItem>
            <SelectItem value="engineer">Engineer</SelectItem>
            <SelectItem value="client">Client</SelectItem>
            <SelectItem value="inspector">Inspector</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Trades Grid */}
      {filteredContacts.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="w-12 h-12 text-slate-300 mb-4" />
            <h3 className="text-lg font-medium text-slate-900 mb-1">No trades found</h3>
            <p className="text-slate-500 text-center">
              {searchQuery || roleFilter !== "all"
                ? "Try adjusting your filters"
                : "Add contacts in the Contacts page to see them here"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContacts.map((contact) => (
            <TradeCard key={contact.id} contact={contact} onStartChat={handleStartChat} />
          ))}
        </div>
      )}

      {/* Project Picker Modal */}
      <ProjectPickerModal
        open={projectPickerOpen}
        onOpenChange={setProjectPickerOpen}
        onSelectProject={handleSelectProject}
        onCreateNew={handleCreateNewProject}
      />
    </div>
  );
}