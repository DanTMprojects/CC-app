import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Plus, Trash2 } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths } from "date-fns";
import { motion } from "framer-motion";

const tradeColors = {
  electrician: "bg-yellow-100 border-yellow-300 text-yellow-800",
  plumber: "bg-blue-100 border-blue-300 text-blue-800",
  drywall: "bg-purple-100 border-purple-300 text-purple-800",
  carpenter: "bg-orange-100 border-orange-300 text-orange-800",
  hvac: "bg-green-100 border-green-300 text-green-800",
  painter: "bg-pink-100 border-pink-300 text-pink-800",
  default: "bg-slate-100 border-slate-300 text-slate-800"
};

export default function CalendarView({ schedules, onAddSchedule, onDeleteSchedule, user, isGC }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState(null);
  const [formData, setFormData] = useState({
    date: "",
    time: "9:00 AM",
    notes: ""
  });

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const handleAddSchedule = () => {
    if (formData.date && formData.time) {
      onAddSchedule({
        date: formData.date,
        time: formData.time,
        notes: formData.notes,
        trade_email: user?.email,
        trade_name: `${user?.full_name} - ${user?.company || user?.trade}`
      });
      setShowAddDialog(false);
      setFormData({ date: "", time: "9:00 AM", notes: "" });
    }
  };

  const getSchedulesForDay = (day) => {
    return schedules.filter(s => isSameDay(new Date(s.date), day));
  };

  const openAddDialog = (date) => {
    setSelectedDate(date);
    setFormData({ ...formData, date: format(date, 'yyyy-MM-dd') });
    setShowAddDialog(true);
  };

  return (
    <div className="space-y-4">
      {/* Month Navigation */}
      <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm">
        <Button variant="outline" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
          Previous
        </Button>
        <h2 className="font-semibold text-lg">{format(currentMonth, 'MMMM yyyy')}</h2>
        <Button variant="outline" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
          Next
        </Button>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {/* Weekday Headers */}
        <div className="grid grid-cols-7 bg-slate-50 border-b">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <div key={day} className="p-2 text-center text-sm font-medium text-slate-600">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7">
          {daysInMonth.map((day, index) => {
            const daySchedules = getSchedulesForDay(day);
            const isToday = isSameDay(day, new Date());
            
            return (
              <div
                key={index}
                className={`min-h-24 p-2 border-r border-b ${
                  isToday ? 'bg-blue-50' : 'bg-white'
                } hover:bg-slate-50 transition-colors`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-sm font-medium ${isToday ? 'text-blue-600' : 'text-slate-900'}`}>
                    {format(day, 'd')}
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-5 w-5 opacity-0 hover:opacity-100"
                    onClick={() => openAddDialog(day)}
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
                <div className="space-y-1">
                  {daySchedules.map((schedule) => (
                    <motion.div
                      key={schedule.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className={`text-xs p-1.5 rounded border ${
                        tradeColors[user?.trade] || tradeColors.default
                      } group relative`}
                    >
                      <div className="flex items-start justify-between gap-1">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate">{schedule.time}</p>
                          <p className="truncate opacity-75">{schedule.trade_name?.split('-')[0]?.trim()}</p>
                        </div>
                        {(schedule.trade_email === user?.email || isGC) && (
                          <button
                            onClick={() => onDeleteSchedule(schedule.id)}
                            className="opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Add Schedule Button (Mobile) */}
      <Button
        onClick={() => {
          setSelectedDate(new Date());
          setFormData({ ...formData, date: format(new Date(), 'yyyy-MM-dd') });
          setShowAddDialog(true);
        }}
        className="w-full sm:hidden bg-slate-900 hover:bg-slate-800"
      >
        <Plus className="w-4 h-4 mr-2" />
        Add Schedule
      </Button>

      {/* Add Schedule Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Schedule a Visit</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label>Date</Label>
              <Input
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label>Time</Label>
              <Input
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label>Notes</Label>
              <Textarea
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="What will you be working on?"
                className="h-20"
              />
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setShowAddDialog(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleAddSchedule} className="flex-1 bg-slate-900 hover:bg-slate-800">
                Add Schedule
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}