import { base44 } from '@/api/base44Client';

// TODO: Implement pull-to-refresh on thread list (mobile)
// This would plug into the Messages.jsx thread list container
// Use a library like react-pull-to-refresh or implement with touch events
// On refresh, invalidate the ['myThreads'] query to fetch fresh data

// TODO: Implement swipe-to-delete on mobile thread list
// This would wrap ThreadItem.jsx with a swipeable container
// Use @hello-pangea/dnd or a touch gesture library
// On swipe left, reveal delete button or trigger deleteThread mutation

// TODO: Implement typing indicators ("User is typing...")
// Data model: Add a 'typing_status' field or use a separate real-time channel
// When user types in message input, debounce and send typing status to backend
// In ChatBubble or chat header, show "Contact is typing..." when their status is active
// Clear typing indicator after 3-5 seconds of inactivity

// TODO: Implement thread pinning (pinned threads float to top)
// Already added pinned_by_a and pinned_by_b fields to ProjectThread entity
// In Messages.jsx, before sorting by last_message_at, sort by pinned status first:
// const sortedThreads = threads.sort((a, b) => {
//   const aPinned = a.user_a_id === user.email ? a.pinned_by_a : a.pinned_by_b;
//   const bPinned = b.user_a_id === user.email ? b.pinned_by_a : b.pinned_by_b;
//   if (aPinned && !bPinned) return -1;
//   if (!aPinned && bPinned) return 1;
//   return sortByDate(a, b);
// });
// Add pin/unpin button in ThreadItem or chat header

// TODO: Implement search within a conversation (message text search)
// Add search input in chat header when thread is active
// Filter sortedMessages by search query matching message_text
// Highlight matching text in ChatBubble components
// Consider backend search for large conversations

export function isThreadBetweenProfiles(thread, profileIdA, profileIdB) {
  const ids = [thread.user_a_profile_id, thread.user_b_profile_id];
  return ids.includes(profileIdA) && ids.includes(profileIdB);
}

export function dedupeThreads(threads) {
  return Object.values(
    threads.reduce((acc, t) => {
      const usersKey = [t.user_a_id, t.user_b_id].sort().join('|');
      const projectKey = t.project_name || '';
      const key = `${usersKey}|${projectKey}`;

      const existing = acc[key];

      if (
        !existing ||
        new Date(t.last_message_at || t.created_date) >
          new Date(existing.last_message_at || existing.created_date)
      ) {
        acc[key] = t;
      }

      return acc;
    }, {})
  );
}

export function getContactProfile(thread, currentUserEmail, profileMap) {
  const id =
    thread.user_a_id === currentUserEmail
      ? thread.user_b_profile_id
      : thread.user_a_profile_id;

  return profileMap[id];
}

export async function findOrCreateThread({
  projectName,
  currentUserEmail,
  contactUserEmail,
  currentProfileId,
  contactProfileId,
}) {
  // Check both directions
  const userThreadsA = await base44.entities.ProjectThread.filter({
    user_a_id: currentUserEmail,
    user_b_id: contactUserEmail,
    project_name: projectName,
  });

  const userThreadsB = await base44.entities.ProjectThread.filter({
    user_a_id: contactUserEmail,
    user_b_id: currentUserEmail,
    project_name: projectName,
  });

  const all = [...userThreadsA, ...userThreadsB];

  // If existing, return the newest one
  if (all.length > 0) {
    return all.sort(
      (a, b) =>
        new Date(b.last_message_at || b.created_date) -
        new Date(a.last_message_at || a.created_date)
    )[0];
  }

  // Otherwise create
  return base44.entities.ProjectThread.create({
    user_a_id: currentUserEmail,
    user_b_id: contactUserEmail,
    user_a_profile_id: currentProfileId,
    user_b_profile_id: contactProfileId,
    project_name: projectName,
  });
}