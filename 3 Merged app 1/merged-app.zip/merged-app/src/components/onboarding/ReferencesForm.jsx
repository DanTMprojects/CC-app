import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowRight, ArrowLeft, User, Phone, Mail } from 'lucide-react';

export default function ReferencesForm({ data, onChange, onNext, onBack }) {
  const references = data.references || [
    { name: '', phone: '', email: '' },
    { name: '', phone: '', email: '' },
    { name: '', phone: '', email: '' }
  ];

  const updateReference = (index, field, value) => {
    const updated = [...references];
    updated[index] = { ...updated[index], [field]: value };
    onChange({ ...data, references: updated });
  };

  const isValid = references.every(r => r.name && r.phone && r.email);

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-slate-900">Add your references</h2>
        <p className="text-slate-500 mt-2">Provide 3 trade references to verify your work quality</p>
      </div>

      <div className="space-y-6">
        {references.map((ref, index) => (
          <div key={index} className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
            <h3 className="text-lg font-semibold text-slate-900 mb-4">Reference {index + 1}</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-slate-700">
                  <User className="w-4 h-4" /> Name *
                </Label>
                <Input
                  value={ref.name}
                  onChange={(e) => updateReference(index, 'name', e.target.value)}
                  placeholder="Contact name"
                  className="h-11 bg-white border-slate-200"
                />
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-slate-700">
                  <Phone className="w-4 h-4" /> Phone *
                </Label>
                <Input
                  value={ref.phone}
                  onChange={(e) => updateReference(index, 'phone', e.target.value)}
                  placeholder="(555) 123-4567"
                  className="h-11 bg-white border-slate-200"
                />
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2 text-slate-700">
                  <Mail className="w-4 h-4" /> Email *
                </Label>
                <Input
                  type="email"
                  value={ref.email}
                  onChange={(e) => updateReference(index, 'email', e.target.value)}
                  placeholder="email@example.com"
                  className="h-11 bg-white border-slate-200"
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-3 pt-4">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex-1 h-12 border-slate-200"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button
          onClick={onNext}
          disabled={!isValid}
          className="flex-1 h-12 bg-slate-900 hover:bg-slate-800 text-white font-medium"
        >
          Review Profile
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}