import React from 'react';
import { Link } from 'react-router-dom';
import { User } from 'lucide-react';
import { APP_ROUTES } from '@/components/config/routes';
import { cn } from '@/lib/utils';

/*
 * Application layout
 *
 * This component wraps all page content with a consistent header and
 * navigation bar. It uses the route configuration defined in
 * `src/components/config/routes.jsx` to generate the navigation
 * automatically. Pages marked with `inNav: true` appear in the
 * primary navigation. The colour palette and spacing have been
 * neutralised to allow each page to provide its own styling while
 * still presenting a consistent header.
 */
export default function Layout({ children, currentPageName }) {
  // Filter down to only routes that should appear in the nav bar
  const navItems = APP_ROUTES.filter((r) => r.inNav);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* App header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-2xl bg-gradient-to-tr from-sky-500 via-blue-500 to-emerald-400 shadow-lg" />
            <div className="flex flex-col">
              <span className="text-sm font-semibold tracking-tight">
                Trade Connect
              </span>
              <span className="text-[11px] text-slate-500">
                Unified messaging & projects
              </span>
            </div>
          </div>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-1 text-xs sm:flex">
            {navItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={cn(
                  'rounded-full border px-3 py-1.5 transition-colors',
                  currentPageName === item.name
                    ? 'border-sky-500 bg-sky-50 text-sky-700'
                    : 'border-transparent text-slate-600 hover:border-slate-300 hover:text-slate-900'
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Profile stub */}
          <button className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-700 shadow-sm hover:border-slate-300 hover:bg-slate-50">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-100">
              <User className="h-3.5 w-3.5" />
            </span>
            <span className="hidden sm:inline">My account</span>
          </button>
        </div>
      </header>

      {/* Page content */}
      <main className="py-4">
        {children}
      </main>
    </div>
  );
}