import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { createPageUrl } from '@/utils';
import { findOrCreateThread } from '@/components/utils/threadUtils';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { ArrowLeft, Search, Filter, Loader2 } from 'lucide-react';
import TradeCard from '@/components/cards/TradeCard';
import ProfileCardModal from '@/components/cards/ProfileCardModal';
import NewThreadModal from '@/components/messaging/NewThreadModal';

const TRADE_CATEGORIES = [
  { value: 'all', label: 'All Trades' },
  { value: 'general_contractor', label: 'General Contractor' },
  { value: 'electrician', label: 'Electrician' },
  { value: 'plumber', label: 'Plumber' },
  { value: 'hvac', label: 'HVAC' },
  { value: 'carpenter', label: 'Carpenter' },
  { value: 'roofer', label: 'Roofer' },
  { value: 'excavator', label: 'Excavator' },
  { value: 'painter', label: 'Painter' },
  { value: 'mason', label: 'Mason' },
  { value: 'landscaper', label: 'Landscaper' },
  { value: 'flooring', label: 'Flooring' },
  { value: 'drywall', label: 'Drywall' },
  { value: 'other', label: 'Other' }
];

// Haversine formula to calculate distance between two points
function getDistance(lat1, lon1, lat2, lon2) {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export default function Explore() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [myProfile, setMyProfile] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [tradeFilter, setTradeFilter] = useState('all');
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [showNewThread, setShowNewThread] = useState(false);
  const [messageTarget, setMessageTarget] = useState(null);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    const currentUser = await base44.auth.me();
    setUser(currentUser);
    
    const profiles = await base44.entities.TradeProfile.filter({
      created_by: currentUser.email
    });
    if (profiles.length > 0) {
      setMyProfile(profiles[0]);
    }
  };

  const { data: allProfiles = [], isLoading } = useQuery({
    queryKey: ['exploreProfiles'],
    queryFn: () => base44.entities.TradeProfile.filter({ onboarding_complete: true }),
    enabled: !!user
  });

  const { data: myConnections = [] } = useQuery({
    queryKey: ['myConnections', user?.id],
    queryFn: () => base44.entities.RolodexConnection.filter({ owner_user_id: user?.id }),
    enabled: !!user
  });

  const connectionIds = useMemo(() => 
    new Set(myConnections.map(c => c.contact_profile_id)),
    [myConnections]
  );

  // Filter profiles within 100 miles and apply search/trade filters
  const filteredProfiles = useMemo(() => {
    return allProfiles
      .filter(profile => profile.id !== myProfile?.id) // Exclude self
      .map(profile => {
        let distance = 0;
        if (myProfile?.latitude && profile.latitude) {
          distance = getDistance(
            myProfile.latitude, myProfile.longitude,
            profile.latitude, profile.longitude
          );
        }
        return { ...profile, distance };
      })
      .filter(profile => profile.distance <= 100 || !myProfile?.latitude)
      .filter(profile => {
        if (tradeFilter !== 'all' && profile.trade_category !== tradeFilter) return false;
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          return (
            profile.company_name?.toLowerCase().includes(query) ||
            profile.owner_name?.toLowerCase().includes(query)
          );
        }
        return true;
      })
      .sort((a, b) => a.distance - b.distance);
  }, [allProfiles, myProfile, tradeFilter, searchQuery]);

  const addToRolodex = useMutation({
    mutationFn: async (profile) => {
      await base44.entities.RolodexConnection.create({
        owner_user_id: user.id,
        contact_user_id: profile.created_by,
        contact_profile_id: profile.id,
        connection_type: 'manual'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['myConnections']);
    },
    onError: (err) => {
      console.error(err);
      alert('Failed to add to Rolodex. Please try again.');
    }
  });

  const removeFromRolodex = useMutation({
    mutationFn: async (profile) => {
      const connections = await base44.entities.RolodexConnection.filter({
        owner_user_id: user.id,
        contact_profile_id: profile.id
      });
      if (connections.length > 0) {
        await base44.entities.RolodexConnection.delete(connections[0].id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['myConnections']);
    },
    onError: (err) => {
      console.error(err);
      alert('Failed to remove from Rolodex. Please try again.');
    }
  });

  const handleMessage = useCallback((profile) => {
    setMessageTarget(profile);
    setShowNewThread(true);
    setSelectedProfile(null);
  }, []);

  const handleCreateThread = useCallback(async (projectName) => {
    const thread = await findOrCreateThread({
      projectName,
      currentUserEmail: user.email,
      contactUserEmail: messageTarget.created_by,
      currentProfileId: myProfile.id,
      contactProfileId: messageTarget.id,
    });

    // Add to rolodex if not already connected
    if (!connectionIds.has(messageTarget.id)) {
      await base44.entities.RolodexConnection.create({
        owner_user_id: user.id,
        contact_user_id: messageTarget.created_by,
        contact_profile_id: messageTarget.id,
        connection_type: 'messaged'
      });
    }

    setShowNewThread(false);
    navigate(createPageUrl('Messages') + `?thread=${thread.id}`);
  }, [user?.email, user?.id, messageTarget, myProfile, connectionIds, navigate]);

  const handleShare = useCallback((profile) => {
    const inviteUrl = `${window.location.origin}${createPageUrl('Onboarding')}?invite=${profile.invite_code}`;
    navigator.clipboard.writeText(inviteUrl);
    alert('Invite link copied to clipboard!');
  }, []);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-100 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3 mb-4">
            <Link to={createPageUrl('Dashboard')} className="p-2 -ml-2 hover:bg-slate-100 rounded-xl transition-colors">
              <ArrowLeft className="w-5 h-5 text-slate-600" />
            </Link>
            <h1 className="text-xl font-bold text-slate-900">Explore Trades</h1>
          </div>

          {/* Search & Filters */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name..."
                className="pl-10 h-11 bg-slate-50 border-slate-200"
              />
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" className="h-11 px-4 border-slate-200">
                  <Filter className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>Filter by Trade</SheetTitle>
                </SheetHeader>
                <div className="mt-6 space-y-2">
                  {TRADE_CATEGORIES.map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => setTradeFilter(cat.value)}
                      className={`w-full text-left px-4 py-3 rounded-xl transition-colors ${
                        tradeFilter === cat.value
                          ? 'bg-slate-900 text-white'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-slate-400" />
          </div>
        ) : filteredProfiles.length > 0 ? (
          <div className="grid grid-cols-1 gap-4">
            {filteredProfiles.map((profile) => (
              <TradeCard
                key={profile.id}
                profile={profile}
                distance={profile.distance}
                onView={setSelectedProfile}
                onAdd={(p) => addToRolodex.mutate(p)}
                onRemove={(p) => removeFromRolodex.mutate(p)}
                onViewMessages={(p) => handleMessage(p)}
                isInRolodex={connectionIds.has(profile.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-slate-500">No trades found matching your criteria</p>
          </div>
        )}
      </div>

      <ProfileCardModal
        profile={selectedProfile}
        isOpen={!!selectedProfile}
        onClose={() => setSelectedProfile(null)}
        onMessage={handleMessage}
        onAdd={(p) => { addToRolodex.mutate(p); setSelectedProfile(null); }}
        onRemove={(p) => { removeFromRolodex.mutate(p); setSelectedProfile(null); }}
        onShare={handleShare}
        isInRolodex={selectedProfile ? connectionIds.has(selectedProfile.id) : false}
      />

      <NewThreadModal
        isOpen={showNewThread}
        onClose={() => setShowNewThread(false)}
        contactProfile={messageTarget}
        onCreateThread={handleCreateThread}
      />
    </div>
  );
}