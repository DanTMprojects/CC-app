import React from 'react';
import { Check, CheckCheck } from 'lucide-react';
import moment from 'moment';

export default function ChatBubble({ message, isSender, sendStatus }) {
  // sendStatus can be: 'sending', 'sent', 'failed'
  // For now, we show 'sent' for all existing messages
  const status = sendStatus || 'sent';
  
  return (
    <div className={`flex ${isSender ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
          isSender
            ? 'bg-slate-900 text-white rounded-br-md'
            : 'bg-slate-100 text-slate-900 rounded-bl-md'
        }`}
      >
        <p className="text-sm leading-relaxed">{message.message_text}</p>
        <div className={`flex items-center gap-1.5 mt-1 ${isSender ? 'text-white/60' : 'text-slate-400'}`}>
          <p className="text-xs">
            {moment(message.created_date).format('h:mm A')}
          </p>
          {isSender && (
            <>
              {status === 'sending' && (
                <span className="text-xs">Sending...</span>
              )}
              {status === 'sent' && (
                <CheckCheck className="w-3.5 h-3.5" />
              )}
              {status === 'failed' && (
                <span className="text-xs text-red-400">Failed</span>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}