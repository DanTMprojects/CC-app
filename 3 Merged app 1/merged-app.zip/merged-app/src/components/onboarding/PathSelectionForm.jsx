import React from 'react';
import { Button } from '@/components/ui/button';
import { HardHat, Building2 } from 'lucide-react';

export default function PathSelectionForm({ onSelect }) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-semibold text-slate-900 mb-2">
          Welcome to TradeRolodex
        </h2>
        <p className="text-slate-500 text-lg">
          Let's get started by selecting your role
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto mt-12">
        <button
          onClick={() => onSelect('general_contractor')}
          className="group relative p-8 rounded-2xl border-2 border-slate-200 hover:border-slate-900 hover:bg-slate-50 transition-all"
        >
          <div className="flex flex-col items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-slate-100 group-hover:bg-slate-900 flex items-center justify-center transition-colors">
              <Building2 className="w-10 h-10 text-slate-600 group-hover:text-white transition-colors" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                General Contractor
              </h3>
              <p className="text-sm text-slate-500">
                I manage construction projects and coordinate trades
              </p>
            </div>
          </div>
        </button>

        <button
          onClick={() => onSelect('trade')}
          className="group relative p-8 rounded-2xl border-2 border-slate-200 hover:border-slate-900 hover:bg-slate-50 transition-all"
        >
          <div className="flex flex-col items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-slate-100 group-hover:bg-slate-900 flex items-center justify-center transition-colors">
              <HardHat className="w-10 h-10 text-slate-600 group-hover:text-white transition-colors" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-slate-900 mb-2">
                Trade Contractor
              </h3>
              <p className="text-sm text-slate-500">
                I specialize in a specific trade or craft
              </p>
            </div>
          </div>
        </button>
      </div>
    </div>
  );
}