import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "6934c7a5057ac3180b1c09a7", 
  requiresAuth: true // Ensure authentication is required for all operations
});
