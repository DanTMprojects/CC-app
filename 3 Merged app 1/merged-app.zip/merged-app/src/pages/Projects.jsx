import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Plus, Search, User } from "lucide-react";
import { motion } from "framer-motion";
import ProjectCard from "@/components/projects/ProjectCard";
import ProjectForm from "@/components/projects/ProjectForm";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Projects() {
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const isGC = user?.trade === 'general_contractor';

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list('-updated_date')
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list()
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Project.create({
      ...data,
      gc_email: user?.email
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      setShowForm(false);
    }
  });

  // Filter projects: GC sees all their projects, trades see projects they're on
  const visibleProjects = projects.filter((p) => {
    if (isGC) {
      return p.gc_email === user?.email;
    } else {
      return p.team_emails?.includes(user?.email);
    }
  });

  const filteredProjects = visibleProjects.filter((p) =>
  p.name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getTeamMembers = (project) => {
    return allUsers.filter((u) => project.team_emails?.includes(u.email));
  };

  return (
    <div className="bg-slate-400 text-slate-950 min-h-screen">
      {/* Header */}
      <header className="bg-slate-400 border-b border-slate-800 backdrop-blur sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-slate-950 text-lg font-semibold">Contractor Chat</h1>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setSearchQuery(searchQuery ? "" : " ")}>
                <Search className="w-5 h-5" />
              </Button>
              {isGC &&
              <Button variant="ghost" size="icon" onClick={() => setShowForm(true)}>
                  <Plus className="w-5 h-5" />
                </Button>
              }
              <Link to={createPageUrl('Profile')}>
                <Button variant="ghost" size="icon">
                  <User className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
          
          {searchQuery !== "" &&
          <div className="mt-3">
              <Input
              value={searchQuery.trim()}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search projects..."
              className="h-10 bg-slate-50"
              autoFocus />

            </div>
          }
        </div>
      </header>

      {/* Projects Grid */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        {isLoading ?
        <div className="grid sm:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map((i) =>
          <div key={i} className="h-40 rounded-2xl bg-white animate-pulse" />
          )}
          </div> :
        filteredProjects.length === 0 ?
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-20 text-center">

            <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center mb-4 shadow-sm">
              <span className="text-2xl">🏗️</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No projects yet</h3>
            <p className="text-slate-500 mb-6 text-sm">
              {isGC ? "Create your first project to get started" : "You haven't been added to any projects yet"}
            </p>
            <div className="flex flex-col gap-2">
              {isGC &&
            <Button onClick={() => setShowForm(true)} className="bg-slate-900 hover:bg-slate-800">
                  <Plus className="w-4 h-4 mr-2" />
                  New Project
                </Button>
            }
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(createPageUrl("DemoProject"))}
                className="border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                View a demo job
              </Button>
            </div>
          </motion.div> :

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="grid sm:grid-cols-2 gap-4">

            {filteredProjects.map((project, index) =>
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}>

                <ProjectCard
              project={project}
              teamMembers={getTeamMembers(project)} />

              </motion.div>
          )}
          </motion.div>
        }

        {/* Demo button for Dennis */}
        {user?.email === 'Dennis.antipkin@gmail.com' && (
          <div className="mt-6 flex justify-center">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl("DemoProject"))}
              className="border-slate-300 text-slate-700 hover:bg-slate-50"
            >
              View Demo Job
            </Button>
          </div>
        )}
      </div>

      {/* New Project Sheet */}
      <Sheet open={showForm} onOpenChange={setShowForm}>
        <SheetContent className="sm:max-w-md overflow-y-auto">
          <ProjectForm
            onSubmit={(data) => createMutation.mutate(data)}
            onCancel={() => setShowForm(false)}
            isLoading={createMutation.isPending} />

        </SheetContent>
      </Sheet>
    </div>);

}