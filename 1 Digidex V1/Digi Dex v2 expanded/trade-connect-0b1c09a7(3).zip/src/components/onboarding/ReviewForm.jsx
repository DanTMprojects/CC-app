import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Check, Building2, User, Phone, Mail, MapPin, Globe, Briefcase, Image, Users } from 'lucide-react';

const TRADE_LABELS = {
  general_contractor: 'General Contractor',
  electrician: 'Electrician',
  plumber: 'Plumber',
  hvac: 'HVAC',
  carpenter: 'Carpenter',
  roofer: 'Roofer',
  excavator: 'Excavator',
  painter: 'Painter',
  mason: 'Mason',
  landscaper: 'Landscaper',
  flooring: 'Flooring',
  drywall: 'Drywall',
  insulation: 'Insulation',
  siding: 'Siding',
  windows_doors: 'Windows & Doors',
  concrete: 'Concrete',
  framing: 'Framing',
  demolition: 'Demolition',
  tile: 'Tile',
  cabinetry: 'Cabinetry',
  other: 'Other'
};

export default function ReviewForm({ data, onBack, onSubmit, isSubmitting }) {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-slate-900">Review your profile</h2>
        <p className="text-slate-500 mt-2">Make sure everything looks good before publishing</p>
      </div>

      {/* Business Info Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold">{data.company_name}</h3>
            <p className="text-slate-300">{data.owner_name}</p>
          </div>
          <Badge className="bg-white/10 text-white border-0">
            {TRADE_LABELS[data.trade_category]}
          </Badge>
        </div>
        
        {data.profile_bio && (
          <p className="text-slate-300 text-sm mb-4">{data.profile_bio}</p>
        )}

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-2 text-slate-300">
            <Mail className="w-4 h-4" />
            {data.email}
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Phone className="w-4 h-4" />
            {data.phone}
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <MapPin className="w-4 h-4" />
            {data.zip_code}
          </div>
          {data.website_url && (
            <div className="flex items-center gap-2 text-slate-300">
              <Globe className="w-4 h-4" />
              {data.website_url}
            </div>
          )}
        </div>
      </div>

      {/* Projects Preview */}
      <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
        <div className="flex items-center gap-2 mb-4">
          <Briefcase className="w-5 h-5 text-slate-700" />
          <h3 className="text-lg font-semibold text-slate-900">Projects ({data.projects?.length || 0})</h3>
        </div>
        
        <div className="grid grid-cols-3 gap-3">
          {data.projects?.map((project, idx) => (
            <div key={idx} className="space-y-2">
              <div className="aspect-video rounded-xl overflow-hidden bg-slate-200">
                {project.photos[0] && (
                  <img 
                    src={project.photos[0]} 
                    alt={`Project ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <Image className="w-3 h-3" />
                {project.photos.length} photos
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* References Preview */}
      <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-slate-700" />
          <h3 className="text-lg font-semibold text-slate-900">References ({data.references?.length || 0})</h3>
        </div>
        
        <div className="space-y-3">
          {data.references?.map((ref, idx) => (
            <div key={idx} className="flex items-center justify-between py-2 border-b border-slate-200 last:border-0">
              <span className="font-medium text-slate-900">{ref.name}</span>
              <span className="text-sm text-slate-500">{ref.email}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button
          onClick={onBack}
          variant="outline"
          className="flex-1 h-12 border-slate-200"
          disabled={isSubmitting}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <Button
          onClick={onSubmit}
          disabled={isSubmitting}
          className="flex-1 h-12 bg-emerald-600 hover:bg-emerald-700 text-white font-medium"
        >
          {isSubmitting ? (
            'Creating Profile...'
          ) : (
            <>
              <Check className="w-4 h-4 mr-2" />
              Complete Setup
            </>
          )}
        </Button>
      </div>
    </div>
  );
}