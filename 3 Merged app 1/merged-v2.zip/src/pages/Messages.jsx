import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, FolderKanban, MessageSquare } from "lucide-react";
import ThreadList from "@/components/messages/ThreadList";
import ChatView from "@/components/messages/ChatView";
import { toggleThreadPinned, toggleThreadArchived } from "@/components/messages/threadUtils";

export default function Messages() {
  const [selectedProjectId, setSelectedProjectId] = useState(null);
  const [selectedThread, setSelectedThread] = useState(null);
  const [projectSearchQuery, setProjectSearchQuery] = useState("");
  const [filterTab, setFilterTab] = useState("all");
  const queryClient = useQueryClient();

  // Get URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const threadId = urlParams.get("thread");
    const projectId = urlParams.get("project");

    if (projectId) {
      setSelectedProjectId(projectId);
    }

    if (threadId) {
      // Load the specific thread
      base44.entities.ProjectThread.list().then((threads) => {
        const thread = threads.find((t) => t.id === threadId);
        if (thread) {
          setSelectedThread(thread);
          setSelectedProjectId(thread.project_id);
        }
      });
    }
  }, []);

  const { data: projects = [], isLoading: projectsLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: () => base44.entities.Project.list("-created_date"),
  });

  const { data: allThreads = [], isLoading: threadsLoading } = useQuery({
    queryKey: ["threads"],
    queryFn: () => base44.entities.ProjectThread.list("-last_message_at"),
  });

  const { data: contacts = [] } = useQuery({
    queryKey: ["contacts"],
    queryFn: () => base44.entities.Contact.list(),
  });

  const { data: currentUser } = useQuery({
    queryKey: ["currentUser"],
    queryFn: () => base44.auth.me(),
  });

  // Filter projects
  const filteredProjects = projects.filter((project) =>
    project.name?.toLowerCase().includes(projectSearchQuery.toLowerCase()) ||
    project.client?.toLowerCase().includes(projectSearchQuery.toLowerCase())
  );

  // Get threads for selected project
  const projectThreads = selectedProjectId
    ? allThreads.filter((thread) => {
        if (thread.project_id !== selectedProjectId) return false;

        // Apply filters
        if (filterTab === "pinned" && !thread.pinned) return false;
        if (filterTab === "unread" && thread.unread_count_gc === 0) return false;
        if (filterTab === "archived" && !thread.archived) return false;
        if (filterTab === "all" && thread.archived) return false;

        return true;
      })
    : [];

  // Count unread messages per project
  const getProjectUnreadCount = (projectId) => {
    return allThreads
      .filter((t) => t.project_id === projectId && !t.archived)
      .reduce((sum, t) => sum + (t.unread_count_gc || 0), 0);
  };

  const handleSelectProject = (project) => {
    setSelectedProjectId(project.id);
    setSelectedThread(null);
  };

  const handleSelectThread = (thread) => {
    setSelectedThread(thread);
  };

  const handleTogglePin = async (thread) => {
    await toggleThreadPinned(thread.id, thread.pinned);
    queryClient.invalidateQueries({ queryKey: ["threads"] });
  };

  const handleToggleArchive = async (thread) => {
    await toggleThreadArchived(thread.id, thread.archived);
    queryClient.invalidateQueries({ queryKey: ["threads"] });
    if (selectedThread?.id === thread.id) {
      setSelectedThread(null);
    }
  };

  const getProjectName = (projectId) => {
    const project = projects.find((p) => p.id === projectId);
    return project?.name || "Unknown Project";
  };

  const getContact = (contactId) => {
    return contacts.find((c) => c.id === contactId);
  };

  if (projectsLoading || threadsLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-12 gap-6" style={{ height: "calc(100vh - 200px)" }}>
          <Skeleton className="col-span-3 h-full rounded-xl" />
          <Skeleton className="col-span-4 h-full rounded-xl" />
          <Skeleton className="col-span-5 h-full rounded-xl" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-slate-900">Messages</h1>
        <p className="text-slate-500 mt-1">Communicate with trades on your projects</p>
      </div>

      {/* Three Column Layout */}
      <div className="grid grid-cols-12 gap-6" style={{ height: "calc(100vh - 200px)" }}>
        {/* Left Column - Projects */}
        <Card className="col-span-12 lg:col-span-3 border-0 shadow-sm flex flex-col">
          <CardContent className="p-4 flex flex-col h-full">
            <div className="mb-4">
              <h2 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <FolderKanban className="w-5 h-5" />
                Projects
              </h2>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Search projects..."
                  value={projectSearchQuery}
                  onChange={(e) => setProjectSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto space-y-2 pr-2">
              {filteredProjects.map((project) => {
                const unreadCount = getProjectUnreadCount(project.id);
                const isSelected = selectedProjectId === project.id;

                return (
                  <button
                    key={project.id}
                    onClick={() => handleSelectProject(project)}
                    className={`w-full p-3 rounded-lg text-left transition-colors ${
                      isSelected
                        ? "bg-indigo-50 border-2 border-indigo-200"
                        : "border border-slate-200 hover:bg-slate-50"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-900 truncate">{project.name}</p>
                        <p className="text-xs text-slate-500 truncate">{project.client}</p>
                      </div>
                      {unreadCount > 0 && (
                        <Badge className="bg-indigo-600 text-white ml-2">{unreadCount}</Badge>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Middle Column - Threads */}
        <Card className="col-span-12 lg:col-span-4 border-0 shadow-sm flex flex-col">
          <CardContent className="p-4 flex flex-col h-full">
            <div className="mb-4">
              <h2 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                {selectedProjectId ? getProjectName(selectedProjectId) : "Select a project"}
              </h2>
              {selectedProjectId && (
                <Tabs value={filterTab} onValueChange={setFilterTab}>
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="all">All</TabsTrigger>
                    <TabsTrigger value="unread">Unread</TabsTrigger>
                    <TabsTrigger value="pinned">Pinned</TabsTrigger>
                    <TabsTrigger value="archived">Archived</TabsTrigger>
                  </TabsList>
                </Tabs>
              )}
            </div>
            <div className="flex-1 overflow-y-auto pr-2">
              {!selectedProjectId ? (
                <div className="text-center py-8 text-slate-500">
                  <p>Select a project to view message threads</p>
                </div>
              ) : (
                <ThreadList
                  threads={projectThreads}
                  contacts={contacts}
                  selectedThreadId={selectedThread?.id}
                  onSelectThread={handleSelectThread}
                  onTogglePin={handleTogglePin}
                  onToggleArchive={handleToggleArchive}
                />
              )}
            </div>
          </CardContent>
        </Card>

        {/* Right Column - Chat */}
        <Card className="col-span-12 lg:col-span-5 border-0 shadow-sm">
          <ChatView
            thread={selectedThread}
            contact={selectedThread ? getContact(selectedThread.contact_id) : null}
            currentUser={currentUser}
          />
        </Card>
      </div>
    </div>
  );
}