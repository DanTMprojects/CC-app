import React from 'react';
import { Check, CheckCheck, FileText, Paperclip } from 'lucide-react';
import moment from 'moment';

function parseStructuredMessage(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  if (!trimmed.startsWith('{') && !trimmed.startsWith('[')) return null;

  try {
    const obj = JSON.parse(trimmed);
    if (obj && typeof obj === 'object' && obj.type) {
      return obj;
    }
  } catch (e) {
    // Not JSON, treat as normal text
  }
  return null;
}

function QuoteCard({ data }) {
  const { title, amount, description } = data;
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold uppercase tracking-wide text-amber-500 bg-amber-50 px-2 py-0.5 rounded-full">
          Quote
        </span>
        {typeof amount === 'number' && (
          <span className="text-sm font-semibold">
            ${amount.toLocaleString()}
          </span>
        )}
      </div>
      {title && <p className="text-sm font-medium">{title}</p>}
      {description && (
        <p className="text-xs text-slate-500 whitespace-pre-line">
          {description}
        </p>
      )}
    </div>
  );
}

function ChangeOrderCard({ data }) {
  const { title, deltaAmount, description } = data;
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold uppercase tracking-wide text-blue-500 bg-blue-50 px-2 py-0.5 rounded-full">
          Change Order
        </span>
        {typeof deltaAmount === 'number' && (
          <span className="text-sm font-semibold">
            {deltaAmount >= 0 ? '+' : '-'}${Math.abs(deltaAmount).toLocaleString()}
          </span>
        )}
      </div>
      {title && <p className="text-sm font-medium">{title}</p>}
      {description && (
        <p className="text-xs text-slate-500 whitespace-pre-line">
          {description}
        </p>
      )}
    </div>
  );
}

function InvoiceCard({ data }) {
  const { title, amount, dueDate, description, status } = data;
  const statusLabel = (status || 'unpaid').toUpperCase();
  const statusColor =
    status === 'paid'
      ? 'text-emerald-600 bg-emerald-50'
      : status === 'overdue'
      ? 'text-red-600 bg-red-50'
      : 'text-amber-600 bg-amber-50';

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between gap-2">
        <span
          className={`text-xs font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full ${statusColor}`}
        >
          Invoice • {statusLabel}
        </span>
        {typeof amount === 'number' && (
          <span className="text-sm font-semibold">
            ${amount.toLocaleString()}
          </span>
        )}
      </div>
      {title && <p className="text-sm font-medium">{title}</p>}
      {dueDate && (
        <p className="text-xs text-slate-500">Due: {dueDate}</p>
      )}
      {description && (
        <p className="text-xs text-slate-500 whitespace-pre-line">
          {description}
        </p>
      )}
    </div>
  );
}

function PunchItemCard({ data }) {
  const { title, location, assigneeName, dueDate, status, description } = data;
  const badgeColor =
    status === 'complete'
      ? 'text-emerald-600 bg-emerald-50'
      : 'text-sky-600 bg-sky-50';

  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between gap-2">
        <span
          className={`text-xs font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full ${badgeColor}`}
        >
          Punch Item • {(status || 'open').toUpperCase()}
        </span>
        {dueDate && (
          <span className="text-xs text-slate-500">Due: {dueDate}</span>
        )}
      </div>
      {title && <p className="text-sm font-medium">{title}</p>}
      {(location || assigneeName) && (
        <p className="text-xs text-slate-500">
          {location && <span>Location: {location}</span>}
          {location && assigneeName && <span> • </span>}
          {assigneeName && <span>Assigned to: {assigneeName}</span>}
        </p>
      )}
      {description && (
        <p className="text-xs text-slate-500 whitespace-pre-line">
          {description}
        </p>
      )}
    </div>
  );
}

function AttachmentCard({ data }) {
  const { attachmentType, url, name, size } = data;
  const isImage = attachmentType === 'image';

  if (isImage && url) {
    return (
      <div className="space-y-2">
        <div className="rounded-xl overflow-hidden border border-slate-200 bg-black/5">
          <a href={url} target="_blank" rel="noreferrer">
            {/* eslint-disable-next-line jsx-a11y/alt-text */}
            <img src={url} className="max-h-64 w-full object-cover" />
          </a>
        </div>
        <p className="text-xs flex items-center gap-1 text-slate-500">
          <Paperclip className="w-3 h-3" />
          <span className="truncate max-w-[180px]">{name || 'Image'}</span>
          {typeof size === 'number' && (
            <span>• {(size / 1024).toFixed(1)} KB</span>
          )}
        </p>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <div className="w-8 h-8 rounded-lg bg-slate-900/10 flex items-center justify-center">
        <FileText className="w-4 h-4" />
      </div>
      <div className="min-w-0">
        <p className="text-xs font-medium truncate max-w-[200px]">
          {name || 'Attachment'}
        </p>
        {typeof size === 'number' && (
          <p className="text-[11px] text-slate-500">
            {(size / 1024).toFixed(1)} KB
          </p>
        )}
        {url && (
          <a
            href={url}
            target="_blank"
            rel="noreferrer"
            className="text-[11px] text-slate-600 underline mt-0.5 inline-block"
          >
            Open
          </a>
        )}
      </div>
    </div>
  );
}

export default function ChatBubble({ message, isSender, sendStatus }) {
  // sendStatus can be: 'sending', 'sent', 'failed'
  // For now, we show 'sent' for all existing messages
  const status = sendStatus || 'sent';
  const structured = parseStructuredMessage(message.message_text);

  let contentNode = null;

  if (structured?.type === 'quote') {
    contentNode = <QuoteCard data={structured} />;
  } else if (structured?.type === 'change_order') {
    contentNode = <ChangeOrderCard data={structured} />;
  } else if (structured?.type === 'invoice') {
    contentNode = <InvoiceCard data={structured} />;
  } else if (structured?.type === 'punch_item') {
    contentNode = <PunchItemCard data={structured} />;
  } else if (structured?.type === 'attachment') {
    contentNode = <AttachmentCard data={structured} />;
  } else {
    // Fallback: plain text message
    contentNode = (
      <p className="text-sm leading-relaxed whitespace-pre-line">
        {message.message_text}
      </p>
    );
  }

  return (
    <div className={`flex ${isSender ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
          isSender
            ? 'bg-slate-900 text-white rounded-br-md'
            : 'bg-slate-100 text-slate-900 rounded-bl-md'
        }`}
      >
        {contentNode}
        <div
          className={`flex items-center gap-1.5 mt-1 ${
            isSender ? 'text-white/60' : 'text-slate-400'
          }`}
        >
          <p className="text-xs">
            {moment(message.created_date).format('h:mm A')}
          </p>
          {isSender && (
            <>
              {status === 'sending' && (
                <span className="text-xs">Sending...</span>
              )}
              {status === 'sent' && (
                <CheckCheck className="w-3.5 h-3.5" />
              )}
              {status === 'failed' && (
                <span className="text-xs text-red-400">Failed</span>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}