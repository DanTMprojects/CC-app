import React, { useMemo, useState } from "react";
import { Search, MapPin, Star } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

const ROLE_TABS = [
  { id: "all", label: "All" },
  { id: "GC", label: "GCs" },
  { id: "Trade", label: "Trades" },
];

const tradeLabels = {
  electrician: "Electrical",
  plumber: "Plumbing",
  carpenter: "Carpentry",
  hvac: "HVAC",
  painter: "Painting",
  roofer: "Roofing",
  mason: "Masonry",
  general_contractor: "GC",
  landscaper: "Landscaping",
  flooring: "Flooring",
  drywall: "Drywall",
  other: "Other"
};

function tradeColor(tradeType) {
  if (!tradeType) return "bg-slate-200 text-slate-950 border-slate-300";
  const t = tradeType.toLowerCase();
  if (t.includes("electric")) return "bg-yellow-100 text-yellow-800 border-yellow-300";
  if (t.includes("plumb")) return "bg-blue-100 text-blue-800 border-blue-300";
  if (t.includes("hvac") || t.includes("climate")) return "bg-cyan-100 text-cyan-800 border-cyan-300";
  if (t.includes("concrete")) return "bg-orange-100 text-orange-800 border-orange-300";
  if (t.includes("carp")) return "bg-amber-100 text-amber-800 border-amber-300";
  if (t.includes("paint")) return "bg-purple-100 text-purple-800 border-purple-300";
  return "bg-emerald-100 text-emerald-800 border-emerald-300";
}

export default function Directory() {
  const [roleFilter, setRoleFilter] = useState("all");
  const [search, setSearch] = useState("");

  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ["directory-profiles"],
    queryFn: () => base44.entities.User.list()
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews-directory"],
    queryFn: () => base44.entities.Review.list("-created_date")
  });

  const ratingByEmail = useMemo(() => {
    const map = new Map();
    for (const r of reviews) {
      if (!r.reviewee_email || typeof r.rating !== "number") continue;
      const prev = map.get(r.reviewee_email) || { sum: 0, count: 0 };
      map.set(r.reviewee_email, { sum: prev.sum + r.rating, count: prev.count + 1 });
    }
    return map;
  }, [reviews]);

  const directoryItems = useMemo(() => {
    return (profiles || []).map((p) => {
      const ratingInfo = ratingByEmail.get(p.email);
      const rating = ratingInfo && ratingInfo.count > 0 
        ? ratingInfo.sum / ratingInfo.count 
        : null;
      
      return {
        id: p.id,
        name: p.full_name || p.email || "Unnamed",
        company: p.company || "",
        role: p.trade === "general_contractor" ? "GC" : "Trade",
        location: p.location || "",
        tradeType: p.trade === "general_contractor" ? null : (tradeLabels[p.trade] || p.trade || ""),
        rating,
      };
    });
  }, [profiles, ratingByEmail]);

  const results = useMemo(() => {
    return directoryItems.filter((entry) => {
      if (roleFilter !== "all" && entry.role !== roleFilter) return false;
      if (!search.trim()) return true;
      const q = search.toLowerCase();
      return (
        entry.name.toLowerCase().includes(q) ||
        entry.company.toLowerCase().includes(q) ||
        (entry.location || "").toLowerCase().includes(q) ||
        (entry.tradeType || "").toLowerCase().includes(q)
      );
    });
  }, [directoryItems, roleFilter, search]);

  return (
    <div className="min-h-screen bg-slate-400 text-slate-950">
      <header className="bg-slate-400 border-b border-slate-800 backdrop-blur sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-slate-950 text-lg font-semibold">Directory</h1>
            <div className="flex items-center gap-2">
              {ROLE_TABS.map((tab) => (
                <Button
                  key={tab.id}
                  size="sm"
                  variant={roleFilter === tab.id ? "default" : "ghost"}
                  className={cn(
                    "h-8 rounded-full text-xs",
                    roleFilter === tab.id
                      ? "bg-slate-900 hover:bg-slate-800 text-white"
                      : "text-slate-950 hover:bg-slate-300"
                  )}
                  onClick={() => setRoleFilter(tab.id)}
                >
                  {tab.label}
                </Button>
              ))}
            </div>
          </div>

          <p className="text-xs text-slate-700 mb-3">
            Your digital rolodex of GCs and trades in the network.
          </p>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-600 absolute left-3 top-1/2 -translate-y-1/2" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, company, trade, or city…"
              className="h-10 pl-9 bg-white border-slate-300 text-slate-950 placeholder:text-slate-500"
            />
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-6">
        {isLoading ? (
          <div className="grid gap-4 sm:grid-cols-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 rounded-2xl bg-white border border-slate-300 animate-pulse" />
            ))}
          </div>
        ) : results.length === 0 ? (
          <div className="py-16 text-center text-sm text-slate-700">
            {directoryItems.length === 0 
              ? "Once GCs and trades complete their profiles, they will appear in your directory."
              : "No matches yet. Try a different search or role filter."}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {results.map((entry) => (
              <article
                key={entry.id}
                className="rounded-2xl border border-slate-300 bg-white p-4 text-sm shadow-sm hover:shadow-md transition-shadow"
              >
                <header className="flex items-start justify-between gap-2">
                  <div>
                    <h2 className="font-semibold text-slate-950">{entry.name}</h2>
                    <p className="text-xs text-slate-600">{entry.company}</p>
                  </div>
                  <span
                    className={cn(
                      "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] uppercase tracking-wide font-medium",
                      entry.role === "GC"
                        ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-800"
                        : "border-sky-500/50 bg-sky-500/10 text-sky-800"
                    )}
                  >
                    {entry.role}
                  </span>
                </header>

                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-slate-700">
                  {entry.location && (
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-500" />
                      {entry.location}
                    </span>
                  )}

                  {entry.tradeType && (
                    <span
                      className={cn(
                        "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium",
                        tradeColor(entry.tradeType)
                      )}
                    >
                      {entry.tradeType}
                    </span>
                  )}

                  {typeof entry.rating === "number" && (
                    <span className="inline-flex items-center gap-1 ml-auto">
                      <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                      <span className="font-medium text-slate-950">{entry.rating.toFixed(1)}</span>
                    </span>
                  )}
                </div>

                <div className="mt-4 flex justify-end">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 rounded-full border-slate-300 text-xs text-slate-950 hover:bg-slate-50"
                  >
                    View profile
                  </Button>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}