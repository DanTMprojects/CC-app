export const MOCK_TEAM_MEMBERS = [
  {
    email: "mike.electric@tradetalk.com",
    full_name: "Mike Johnson",
    trade: "electrician",
    company: "Bright Spark Electric",
    phone: "(555) 234-5678",
    location: "Austin, TX"
  },
  {
    email: "sarah.plumbing@tradetalk.com",
    full_name: "Sarah Martinez",
    trade: "plumber",
    company: "Martinez Plumbing Co",
    phone: "(555) 345-6789",
    location: "Austin, TX"
  },
  {
    email: "tom.carpenter@tradetalk.com",
    full_name: "Tom Anderson",
    trade: "carpenter",
    company: "Anderson Carpentry",
    phone: "(555) 456-7890",
    location: "Round Rock, TX"
  },
  {
    email: "lisa.hvac@tradetalk.com",
    full_name: "Lisa Chen",
    trade: "hvac",
    company: "Cool Air Systems",
    phone: "(555) 567-8901",
    location: "Austin, TX"
  },
  {
    email: "david.paint@tradetalk.com",
    full_name: "David Rodriguez",
    trade: "painter",
    company: "Precision Painting",
    phone: "(555) 678-9012",
    location: "Cedar Park, TX"
  },
  {
    email: "jen.drywall@tradetalk.com",
    full_name: "Jennifer Brown",
    trade: "drywall",
    company: "Brown Drywall & Texture",
    phone: "(555) 789-0123",
    location: "Austin, TX"
  }
];