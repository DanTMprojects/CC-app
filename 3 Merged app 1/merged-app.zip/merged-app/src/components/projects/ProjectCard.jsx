import React from 'react';
import { Badge } from "@/components/ui/badge";
import { ChevronRight } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

const statusColors = {
  active: "bg-blue-100 text-blue-700",
  pending: "bg-amber-100 text-amber-700",
  completed: "bg-green-100 text-green-700"
};

const tradeLabels = {
  electrician: "Electrical",
  plumber: "Plumbing",
  carpenter: "Carpentry",
  hvac: "HVAC",
  painter: "Paint",
  roofer: "Roofing",
  mason: "Masonry",
  general_contractor: "GC",
  landscaper: "Landscaping",
  flooring: "Flooring",
  drywall: "Drywall",
  other: "Other"
};

export default function ProjectCard({ project, teamMembers = [] }) {
  const tradesList = project.trades?.slice(0, 3).map((t) => tradeLabels[t] || t).join(', ') || '';

  return (
    <Link to={createPageUrl(`ProjectDetail?id=${project.id}`)}>
      <div className="bg-slate-50 text-slate-950 p-5 rounded-2xl shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer group">
        <h3 className="text-lg font-semibold text-slate-900 mb-2">{project.name}</h3>
        
        <Badge className={`${statusColors[project.status]} font-medium capitalize mb-3`}>
          {project.status}
        </Badge>
        
        <p className="text-sm text-slate-500 mb-2">
          Updated {formatDistanceToNow(new Date(project.updated_date), { addSuffix: true })}
        </p>
        
        {tradesList &&
        <p className="text-sm text-slate-600 mb-4">{tradesList}</p>
        }
        
        <div className="flex items-center justify-between">
          <div className="flex -space-x-2">
            {teamMembers.slice(0, 3).map((member, idx) =>
            <div
              key={idx}
              className="w-8 h-8 rounded-full bg-gradient-to-br from-slate-200 to-slate-300 border-2 border-white flex items-center justify-center">

                <span className="text-xs font-medium text-slate-600">
                  {member.full_name?.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2) || '??'}
                </span>
              </div>
            )}
            {teamMembers.length > 3 &&
            <div className="w-8 h-8 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center">
                <span className="text-xs font-medium text-slate-500">+{teamMembers.length - 3}</span>
              </div>
            }
          </div>
          <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-slate-600 transition-colors" />
        </div>
      </div>
    </Link>);

}