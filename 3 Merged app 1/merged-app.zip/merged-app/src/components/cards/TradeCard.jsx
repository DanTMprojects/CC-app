import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Plus, Eye, Building2, MessageSquare, X } from 'lucide-react';

const TRADE_LABELS = {
  general_contractor: 'General Contractor',
  electrician: 'Electrician',
  plumber: 'Plumber',
  hvac: 'HVAC',
  carpenter: 'Carpenter',
  roofer: 'Roofer',
  excavator: 'Excavator',
  painter: 'Painter',
  mason: 'Mason',
  landscaper: 'Landscaper',
  flooring: 'Flooring',
  drywall: 'Drywall',
  insulation: 'Insulation',
  siding: 'Siding',
  windows_doors: 'Windows & Doors',
  concrete: 'Concrete',
  framing: 'Framing',
  demolition: 'Demolition',
  tile: 'Tile',
  cabinetry: 'Cabinetry',
  other: 'Other'
};

export default function TradeCard({ profile, distance, onView, onAdd, onRemove, onViewMessages, isInRolodex }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-100 p-5 hover:shadow-lg hover:shadow-slate-100 transition-all duration-300">
      <div className="flex items-start gap-4">
        {/* Avatar */}
        <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center flex-shrink-0">
          {profile.profile_photo_url ? (
            <img 
              src={profile.profile_photo_url} 
              alt={profile.company_name}
              className="w-full h-full object-cover rounded-xl"
            />
          ) : (
            <Building2 className="w-6 h-6 text-slate-400" />
          )}
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-slate-900 truncate">{profile.company_name}</h3>
          <Badge variant="secondary" className="mt-1 bg-slate-100 text-slate-600 font-normal">
            {TRADE_LABELS[profile.trade_category] || profile.trade_category}
          </Badge>
          
          <div className="flex items-center gap-3 mt-2 text-sm text-slate-500">
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              {profile.zip_code}
            </span>
            {distance !== undefined && (
              <span className="text-slate-400">
                {distance.toFixed(0)} mi away
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2 mt-4">
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1 h-10 border-slate-200"
          onClick={() => onView(profile)}
        >
          <Eye className="w-4 h-4 mr-1.5" />
          View Card
        </Button>
        {isInRolodex ? (
          <>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 h-10 border-slate-200"
              onClick={() => onViewMessages(profile)}
            >
              <MessageSquare className="w-4 h-4 mr-1.5" />
              Messages
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="h-10 px-3 border-red-200 text-red-600 hover:bg-red-50"
              onClick={() => onRemove(profile)}
            >
              <X className="w-4 h-4" />
            </Button>
          </>
        ) : (
          <Button 
            size="sm" 
            className="flex-1 h-10 bg-slate-900 hover:bg-slate-800"
            onClick={() => onAdd(profile)}
          >
            <Plus className="w-4 h-4 mr-1.5" />
            Add
          </Button>
        )}
      </div>
    </div>
  );
}