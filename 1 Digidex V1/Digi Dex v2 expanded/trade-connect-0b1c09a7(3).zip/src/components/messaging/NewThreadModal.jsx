import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { MapPin, MessageSquare } from 'lucide-react';

export default function NewThreadModal({ isOpen, onClose, contactProfile, onCreateThread }) {
  const [projectName, setProjectName] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  const handleCreate = async () => {
    if (!projectName.trim() || isCreating) return;
    setIsCreating(true);
    await onCreateThread(projectName.trim());
    setIsCreating(false);
    setProjectName('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Start Project Chat</DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          <p className="text-sm text-slate-500 mb-4">
            Start a new conversation with <span className="font-medium text-slate-900">{contactProfile?.company_name}</span> about a specific project.
          </p>

          <div className="space-y-2">
            <Label htmlFor="project_name" className="flex items-center gap-2 text-slate-700">
              <MapPin className="w-4 h-4" />
              Project Name / Address
            </Label>
            <Input
              id="project_name"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              placeholder="e.g., 115 Saluda Street"
              className="h-12"
            />
          </div>

          <Button
            onClick={handleCreate}
            disabled={!projectName.trim() || isCreating}
            className="w-full mt-6 h-12 bg-slate-900 hover:bg-slate-800"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            {isCreating ? 'Creating...' : 'Start Chat'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}