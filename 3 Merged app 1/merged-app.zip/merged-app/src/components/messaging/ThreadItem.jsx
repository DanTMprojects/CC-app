import React, { useState, useRef } from 'react';
import {
  MapPin,
  Building2,
  Trash2,
  Pin,
  PinOff,
  Archive,
  Circle,
  Bell,
  BellOff,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import moment from 'moment';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function ThreadItem({
  thread,
  contactProfile,
  onClick,
  isActive,
  onDelete,
  unreadCount = 0,
  isPinned = false,
  isArchived = false,
  isMuted = false,
  onTogglePinned,
  onToggleReadUnread,
  onArchive,
  onToggleMuted,
}) {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const touchStartXRef = useRef(null);
  const touchDeltaXRef = useRef(0);

  const handleTouchStart = (e) => {
    if (!e.touches || !e.touches.length) return;
    touchStartXRef.current = e.touches[0].clientX;
    touchDeltaXRef.current = 0;
  };

  const handleTouchMove = (e) => {
    if (touchStartXRef.current == null || !e.touches || !e.touches.length) return;
    const currentX = e.touches[0].clientX;
    touchDeltaXRef.current = currentX - touchStartXRef.current;
  };

  const handleTouchEnd = () => {
    const deltaX = touchDeltaXRef.current || 0;
    const SWIPE_THRESHOLD = 60;

    if (deltaX <= -SWIPE_THRESHOLD && onToggleReadUnread) {
      // swipe left → toggle read/unread
      onToggleReadUnread();
    } else if (deltaX >= SWIPE_THRESHOLD && onArchive) {
      // swipe right → archive / unarchive
      onArchive();
    }

    touchStartXRef.current = null;
    touchDeltaXRef.current = 0;
  };

  const confirmDelete = (e) => {
    e?.stopPropagation();
    setShowDeleteConfirm(false);
    onDelete?.(thread);
  };

  const lastMessageTime = thread.last_message_at || thread.created_date;
  const lastMessageLabel = lastMessageTime
    ? moment(lastMessageTime).fromNow()
    : '';

  const lastMessagePreview = thread.last_message || 'No messages yet';

  const tradeLabel = contactProfile?.trade_category
    ? contactProfile.trade_category.replace(/_/g, ' ')
    : null;

  return (
    <>
      <div
        className={`relative px-4 py-3 cursor-pointer select-none ${
          isActive ? 'bg-slate-50' : 'hover:bg-slate-50'
        }`}
        onClick={onClick}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        <div className="flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
            {contactProfile?.profile_photo_url ? (
              <img
                src={contactProfile.profile_photo_url}
                alt=""
                className="w-full h-full object-cover rounded-xl"
              />
            ) : (
              <Building2 className="w-4 h-4 text-slate-400" />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between gap-2">
              <p className="text-sm font-medium text-slate-900 truncate flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                <span className="truncate">{thread.project_name}</span>
              </p>
              <div className="flex items-center gap-1 flex-shrink-0">
                {lastMessageLabel && (
                  <span className="text-[11px] text-slate-400">
                    {lastMessageLabel}
                  </span>
                )}
                {unreadCount > 0 && (
                  <span className="ml-1 min-w-[18px] h-[18px] rounded-full bg-slate-900 text-[10px] text-white flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
                {isMuted && (
                  <BellOff className="w-3 h-3 text-slate-400" />
                )}
                {isPinned && (
                  <Pin className="w-3 h-3 text-amber-500" />
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 mt-0.5">
              <p className="text-xs text-slate-500 truncate">
                {contactProfile?.company_name || 'Unknown company'}
              </p>
              {tradeLabel && (
                <Badge variant="secondary" className="text-[10px] py-0 px-1.5">
                  {tradeLabel}
                </Badge>
              )}
            </div>

            <p className="mt-1 text-[11px] text-slate-500 truncate">
              {lastMessagePreview}
            </p>

            {/* Desktop actions */}
            <div className="hidden md:flex items-center gap-2 mt-2 text-[11px] text-slate-400">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleReadUnread?.();
                }}
                className="inline-flex items-center gap-1 hover:text-slate-700"
              >
                <Circle className="w-3 h-3" />
                <span>{unreadCount > 0 ? 'Mark as read' : 'Mark as unread'}</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onTogglePinned?.();
                }}
                className="inline-flex items-center gap-1 hover:text-slate-700"
              >
                {isPinned ? (
                  <>
                    <PinOff className="w-3 h-3" />
                    <span>Unpin</span>
                  </>
                ) : (
                  <>
                    <Pin className="w-3 h-3" />
                    <span>Pin</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleMuted?.();
                }}
                className="inline-flex items-center gap-1 hover:text-slate-700"
              >
                {isMuted ? (
                  <>
                    <BellOff className="w-3 h-3" />
                    <span>Unmute</span>
                  </>
                ) : (
                  <>
                    <Bell className="w-3 h-3" />
                    <span>Mute</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onArchive?.();
                }}
                className="inline-flex items-center gap-1 hover:text-slate-700"
              >
                <Archive className="w-3 h-3" />
                <span>{isArchived ? 'Unarchive' : 'Archive'}</span>
              </button>
            </div>

            {/* Mobile swipe hint */}
            <div className="md:hidden flex items-center justify-between mt-1 text-[10px] text-slate-400">
              <span>Swipe right to archive</span>
              <span>Swipe left to read/unread</span>
            </div>
          </div>

          {/* Delete icon (all devices) */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowDeleteConfirm(true);
            }}
            className="p-1 rounded-full hover:bg-red-50 text-slate-300 hover:text-red-600 flex-shrink-0"
            aria-label="Delete conversation"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete conversation?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this conversation and all its messages. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={(e) => e.stopPropagation()}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}