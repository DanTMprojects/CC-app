
import React from "react";
import { Link } from "react-router-dom";
import { User } from "lucide-react";
import { createPageUrl } from "@/utils";
import { cn } from "@/lib/utils";
import { APP_ROUTES } from "@/components/config/routes";

const NAV_ITEMS = APP_ROUTES.filter((r) => r.inNav);

export default function Layout({ children, currentPageName }) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      {/* App header */}
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-3">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-2xl bg-gradient-to-tr from-sky-500 via-blue-500 to-emerald-400 shadow-lg" />
            <div className="flex flex-col">
              <span className="text-sm font-semibold tracking-tight">
                Trade Talk
              </span>
              <span className="text-[11px] text-slate-400">
                Project-based chat for GCs & trades
              </span>
            </div>
          </div>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-1 text-xs sm:flex">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.name}
                to={createPageUrl(item.name)}
                className={cn(
                  "rounded-full border px-3 py-1.5 transition-colors",
                  currentPageName === item.name
                    ? "border-sky-500/70 bg-sky-500/10 text-sky-100"
                    : "border-transparent text-slate-300 hover:border-slate-600/70 hover:text-slate-50"
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          {/* Profile stub */}
          <button className="inline-flex items-center gap-2 rounded-full border border-slate-700/80 bg-slate-900/70 px-3 py-1.5 text-xs text-slate-200 shadow-sm hover:border-slate-500 hover:bg-slate-900">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-800">
              <User className="h-3.5 w-3.5" />
            </span>
            <span className="hidden sm:inline">My account</span>
          </button>
        </div>
      </header>

      {/* Page content */}
      <main className="py-4">
        {children}
      </main>
    </div>
  );
}
