import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ArrowLeft, Settings, Megaphone, MessageSquare, Send, Image as ImageIcon, Calendar, FileText, Paperclip, Star } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import { motion } from "framer-motion";
import ProjectForm from "@/components/projects/ProjectForm";
import { Textarea } from "@/components/ui/textarea";
import CalendarView from "@/components/calendar/CalendarView";
import { cn } from "@/lib/utils";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const statusColors = {
  active: "bg-blue-100 text-blue-700",
  pending: "bg-amber-100 text-amber-700",
  completed: "bg-green-100 text-green-700"
};

const tradeLabels = {
  electrician: "Electrical",
  plumber: "Plumbing",
  carpenter: "Carpentry",
  hvac: "HVAC",
  painter: "Paint",
  roofer: "Roofing",
  mason: "Masonry",
  general_contractor: "GC",
  landscaper: "Landscaping",
  flooring: "Flooring",
  drywall: "Drywall",
  other: "Other"
};

export default function ProjectDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const projectId = urlParams.get('id');
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const messagesEndRef = useRef(null);
  
  const [showEditForm, setShowEditForm] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("messages");
  const [selectedTradeEmail, setSelectedTradeEmail] = useState(null);
  const [messageInput, setMessageInput] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [rating, setRating] = useState(0);
  const [reviewComment, setReviewComment] = useState("");

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const isGC = user?.trade === 'general_contractor';

  const { data: project, isLoading: projectLoading } = useQuery({
    queryKey: ['project', projectId],
    queryFn: async () => {
      const projects = await base44.entities.Project.filter({ id: projectId });
      return projects[0];
    },
    enabled: !!projectId
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['messages', projectId],
    queryFn: () => base44.entities.Message.filter({ project_id: projectId }, 'created_date'),
    enabled: !!projectId,
    refetchInterval: 3000
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ['schedules', projectId],
    queryFn: () => base44.entities.Schedule.filter({ project_id: projectId }, 'date'),
    enabled: !!projectId
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ['reviews', projectId],
    queryFn: () => base44.entities.Review.filter({ project_id: projectId }, '-created_date'),
    enabled: !!projectId
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list()
  });

  const teamMembers = allUsers.filter(u => project?.team_emails?.includes(u.email));

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Project.update(projectId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['project', projectId] });
      setShowEditForm(false);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: () => base44.entities.Project.delete(projectId),
    onSuccess: () => {
      navigate(createPageUrl('Projects'));
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: (data) => base44.entities.Message.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages', projectId] });
      setMessageInput("");
    }
  });

  const addScheduleMutation = useMutation({
    mutationFn: (data) => base44.entities.Schedule.create({ ...data, project_id: projectId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['schedules', projectId] });
    }
  });

  const deleteScheduleMutation = useMutation({
    mutationFn: (id) => base44.entities.Schedule.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['schedules', projectId] });
    }
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) => base44.entities.Review.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reviews', projectId] });
      setRating(0);
      setReviewComment("");
    }
  });

  const handleSendMessage = async () => {
    if (!messageInput.trim() && !imageFile) return;
    
    setUploading(true);
    let imageUrl = null;
    
    if (imageFile) {
      try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: imageFile });
        imageUrl = file_url;
      } catch (error) {
        console.error('Failed to upload image:', error);
      }
    }
    
    const messageData = {
      project_id: projectId,
      content: messageInput || '📷 Photo',
      author_name: user?.full_name || 'Unknown',
      author_email: user?.email,
      message_type: activeTab === 'announcements' ? 'announcement' : 'private',
      trade_email: activeTab === 'announcements' ? null : (isGC ? selectedTradeEmail : user?.email),
      image_url: imageUrl
    };
    
    sendMessageMutation.mutate(messageData);
    setImageFile(null);
    setUploading(false);
  };

  const handleImageSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
    }
  };



  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  // For trades, auto-select their own email for private chats
  // For GC, auto-select first team member
  useEffect(() => {
    if (!isGC && user?.email) {
      setSelectedTradeEmail(user.email);
    } else if (isGC && teamMembers.length > 0 && !selectedTradeEmail) {
      setSelectedTradeEmail(teamMembers[0].email);
    }
  }, [isGC, user?.email, teamMembers.length]);

  if (projectLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="animate-pulse text-slate-400">Loading...</div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center">
        <p className="text-slate-400 mb-4">Project not found</p>
        <Button variant="outline" onClick={() => navigate(createPageUrl('Projects'))}>
          Back to Projects
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-400 text-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-400 backdrop-blur sticky top-0 z-20">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full border border-slate-800 text-slate-950 hover:text-slate-950 hover:bg-slate-300"
              onClick={() => navigate(createPageUrl("Projects"))}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-sm font-semibold text-slate-950">
                {project?.name || "Project"}
              </h1>
              <p className="text-[11px] text-slate-700">
                {project?.scope_of_work?.slice(0, 40) || "Job details"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {project?.status && (
              <span className="inline-flex items-center rounded-full border border-sky-500/60 bg-sky-500/10 px-2 py-0.5 text-[11px] text-slate-950 capitalize">
                {project.status}
              </span>
            )}
            {isGC && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setShowEditForm(true)}
                className="h-8 w-8 rounded-full border border-slate-800 text-slate-950 hover:text-slate-950 hover:bg-slate-300"
              >
                <Settings className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-5xl mx-auto px-4 py-6 space-y-4">
        
        {/* Overview Card */}
        <div className="bg-white border border-slate-800 rounded-2xl p-4 text-sm">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <p className="text-xs uppercase tracking-wide text-slate-500 mb-1">
                General contractor
              </p>
              <p className="text-slate-950">
                {project?.gc_email || "N/A"}
              </p>
            </div>

            {project?.trades && project.trades.length > 0 && (
              <div>
                <p className="text-xs uppercase tracking-wide text-slate-500 mb-1">
                  Trades
                </p>
                <p className="text-slate-950">
                  {project.trades.slice(0, 3).map(t => tradeLabels[t]).join(', ')}
                  {project.trades.length > 3 && ` +${project.trades.length - 3}`}
                </p>
              </div>
            )}

            {teamMembers.length > 0 && (
              <div>
                <p className="text-xs uppercase tracking-wide text-slate-500 mb-1">
                  Team size
                </p>
                <p className="text-slate-950">
                  {teamMembers.length} {teamMembers.length === 1 ? 'member' : 'members'}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white border border-slate-800 rounded-2xl overflow-hidden">
          <div className="flex gap-1 text-xs border-b border-slate-200 p-1">
            {["announcements", "messages", "schedule"].map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 px-3 py-2 rounded-lg transition-colors ${
                  activeTab === tab
                    ? "bg-sky-500/20 text-slate-950 border border-sky-500/40"
                    : "text-slate-700 hover:text-slate-950 hover:bg-slate-100"
                }`}
              >
                {tab === "announcements" && "Announcements"}
                {tab === "messages" && "Messages"}
                {tab === "schedule" && "Schedule"}
              </button>
            ))}
          </div>

          <div className="p-4">
            {/* Announcements Tab */}
            {activeTab === "announcements" && (
              <div className="space-y-3">
                {messages.filter(m => m.message_type === 'announcement').length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                      <Megaphone className="w-5 h-5 text-slate-500" />
                    </div>
                    <p className="text-slate-700 text-sm">
                      {isGC 
                        ? "Post announcements visible to everyone on this job."
                        : "No announcements yet from the GC."}
                    </p>
                  </div>
                ) : (
                  messages.filter(m => m.message_type === 'announcement').map((message, index) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.03 }}
                      className="p-3 rounded-xl bg-slate-100 border border-slate-200"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-medium text-slate-950">
                          {message.author_name}
                        </span>
                        <span className="text-xs text-slate-600">
                          {format(new Date(message.created_date), "MMM d, h:mm a")}
                        </span>
                      </div>
                      {message.image_url && (
                        <img 
                          src={message.image_url}
                          alt="Attachment"
                          className="rounded-lg max-w-xs mb-2 cursor-pointer"
                          onClick={() => window.open(message.image_url, '_blank')}
                        />
                      )}
                      <p className="text-sm text-slate-950">{message.content}</p>
                    </motion.div>
                  ))
                )}
                
                {/* Composer for Announcements */}
                {isGC && (
                  <div className="mt-4 pt-4 border-t border-slate-200">
                    {imageFile && (
                      <div className="mb-2 p-2 bg-slate-100 rounded-lg flex items-center gap-2">
                        <ImageIcon className="w-4 h-4 text-slate-700" />
                        <span className="text-sm text-slate-950">{imageFile.name}</span>
                        <button onClick={() => setImageFile(null)} className="ml-auto text-slate-700 hover:text-slate-950">
                          ×
                        </button>
                      </div>
                    )}
                    <div className="flex gap-2 items-end">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageSelect}
                        className="hidden"
                        id="image-upload-announcements"
                      />
                      <label htmlFor="image-upload-announcements">
                        <Button 
                          type="button" 
                          variant="outline" 
                          className="h-10 w-10 flex-shrink-0 border-slate-300 bg-white hover:bg-slate-50"
                          asChild
                        >
                          <span>
                            <Paperclip className="w-4 h-4 text-slate-950" />
                          </span>
                        </Button>
                      </label>
                      <Textarea
                        value={messageInput}
                        onChange={(e) => setMessageInput(e.target.value)}
                        placeholder="Write an announcement for all team members..."
                        className="min-h-[40px] max-h-[120px] resize-none bg-white border-slate-300 text-slate-950 placeholder:text-slate-500"
                        rows={1}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                      />
                      <Button 
                        onClick={handleSendMessage}
                        disabled={(!messageInput.trim() && !imageFile) || uploading || sendMessageMutation.isPending}
                        className="h-10 w-10 bg-sky-500 hover:bg-sky-600 flex-shrink-0"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Messages Tab */}
            {activeTab === "messages" && (
              <div className="space-y-3">
                {/* Trade Selector for GC */}
                {isGC && (
                  <div className="pb-3 mb-3 border-b border-slate-200">
                    <p className="text-xs text-slate-700 mb-2">Select team member:</p>
                    <div className="flex gap-2 overflow-x-auto pb-1">
                      {teamMembers.map((member) => (
                        <button
                          key={member.email}
                          onClick={() => setSelectedTradeEmail(member.email)}
                          className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all ${
                            selectedTradeEmail === member.email
                              ? 'bg-sky-500/20 text-slate-950 border border-sky-500/40'
                              : 'bg-slate-100 text-slate-950 hover:bg-slate-200 border border-slate-300'
                          }`}
                        >
                          <div className="w-5 h-5 rounded-full bg-slate-300 flex items-center justify-center text-[10px] font-medium">
                            {member.full_name?.split(' ').map(n => n[0]).join('').slice(0, 2)}
                          </div>
                          {member.full_name || member.email}
                        </button>
                      ))}
                      {teamMembers.length === 0 && (
                        <p className="text-xs text-slate-600">No team members added yet</p>
                      )}
                    </div>
                  </div>
                )}

                {/* Messages List */}
                {messages.filter(m => {
                  if (isGC) {
                    return m.message_type === 'private' && m.trade_email === selectedTradeEmail;
                  } else {
                    return m.message_type === 'private' && m.trade_email === user?.email;
                  }
                }).length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3">
                      <MessageSquare className="w-5 h-5 text-slate-500" />
                    </div>
                    <p className="text-slate-700 text-sm">
                      {isGC 
                        ? (selectedTradeEmail ? "Start a conversation" : "Select a team member above")
                        : "No messages yet"}
                    </p>
                  </div>
                ) : (
                  <>
                    {messages.filter(m => {
                      if (isGC) {
                        return m.message_type === 'private' && m.trade_email === selectedTradeEmail;
                      } else {
                        return m.message_type === 'private' && m.trade_email === user?.email;
                      }
                    }).map((message, index) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.03 }}
                        className={`p-3 rounded-xl ${
                          message.author_email === user?.email
                            ? 'bg-sky-500/20 border border-sky-500/40 ml-8'
                            : 'bg-slate-100 border border-slate-200 mr-8'
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-xs font-medium ${
                            message.author_email === user?.email ? 'text-slate-950' : 'text-slate-950'
                          }`}>
                            {message.author_name}
                          </span>
                          <span className="text-xs text-slate-600">
                            {format(new Date(message.created_date), "MMM d, h:mm a")}
                          </span>
                        </div>
                        {message.image_url && (
                          <img 
                            src={message.image_url}
                            alt="Attachment"
                            className="rounded-lg max-w-xs mb-2 cursor-pointer"
                            onClick={() => window.open(message.image_url, '_blank')}
                          />
                        )}
                        <p className={`text-sm ${
                          message.author_email === user?.email ? 'text-slate-950' : 'text-slate-950'
                        }`}>
                          {message.content}
                        </p>
                      </motion.div>
                    ))}
                    <div ref={messagesEndRef} />
                  </>
                )}

                {/* Composer for Messages */}
                {((isGC && selectedTradeEmail) || !isGC) && (
                  <div className="mt-4 pt-4 border-t border-slate-200">
                    {imageFile && (
                      <div className="mb-2 p-2 bg-slate-100 rounded-lg flex items-center gap-2">
                        <ImageIcon className="w-4 h-4 text-slate-700" />
                        <span className="text-sm text-slate-950">{imageFile.name}</span>
                        <button onClick={() => setImageFile(null)} className="ml-auto text-slate-700 hover:text-slate-950">
                          ×
                        </button>
                      </div>
                    )}
                    <div className="flex gap-2 items-end">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageSelect}
                        className="hidden"
                        id="image-upload-messages"
                      />
                      <label htmlFor="image-upload-messages">
                        <Button 
                          type="button" 
                          variant="outline" 
                          className="h-10 w-10 flex-shrink-0 border-slate-300 bg-white hover:bg-slate-50"
                          asChild
                        >
                          <span>
                            <Paperclip className="w-4 h-4 text-slate-950" />
                          </span>
                        </Button>
                      </label>
                      <Textarea
                        value={messageInput}
                        onChange={(e) => setMessageInput(e.target.value)}
                        placeholder="Type a message..."
                        className="min-h-[40px] max-h-[120px] resize-none bg-white border-slate-300 text-slate-950 placeholder:text-slate-500"
                        rows={1}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage();
                          }
                        }}
                      />
                      <Button 
                        onClick={handleSendMessage}
                        disabled={(!messageInput.trim() && !imageFile) || uploading || sendMessageMutation.isPending}
                        className="h-10 w-10 bg-sky-500 hover:bg-sky-600 flex-shrink-0"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Schedule Tab */}
            {activeTab === "schedule" && (
              <div className="max-h-[600px] overflow-y-auto -mx-4 px-4">
                <CalendarView
                  schedules={schedules}
                  onAddSchedule={(data) => addScheduleMutation.mutate(data)}
                  onDeleteSchedule={(id) => deleteScheduleMutation.mutate(id)}
                  user={user}
                  isGC={isGC}
                />
              </div>
            )}
          </div>
        </div>

        {/* Gallery & Details - Keep as separate cards below */}
        <div className="grid sm:grid-cols-2 gap-4">
          {/* Gallery */}
          <div className="bg-white border border-slate-800 rounded-2xl p-4">
            <h3 className="text-sm font-semibold text-slate-950 mb-3 flex items-center gap-2">
              <ImageIcon className="w-4 h-4" />
              Photos
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {messages.filter(m => m.image_url).slice(0, 4).length === 0 ? (
                <div className="col-span-2 flex flex-col items-center justify-center py-8 text-center">
                  <p className="text-slate-600 text-xs">No photos yet</p>
                </div>
              ) : (
                messages.filter(m => m.image_url).slice(0, 4).map((message, index) => (
                  <div
                    key={message.id}
                    className="aspect-square rounded-lg overflow-hidden bg-slate-100 border border-slate-200"
                  >
                    <img 
                      src={message.image_url} 
                      alt={message.content}
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-300 cursor-pointer"
                      onClick={() => window.open(message.image_url, '_blank')}
                    />
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Team */}
          <div className="bg-white border border-slate-800 rounded-2xl p-4">
            <h3 className="text-sm font-semibold text-slate-950 mb-3">Team Members</h3>
            <div className="space-y-2">
              {teamMembers.slice(0, 3).map((member) => (
                <div key={member.email} className="flex items-center gap-2 p-2 border border-slate-200 rounded-lg bg-slate-50">
                  <div className="w-8 h-8 rounded-full bg-slate-300 flex items-center justify-center">
                    <span className="text-xs font-medium text-slate-950">
                      {member.full_name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-slate-950 truncate">{member.full_name}</p>
                    <p className="text-[11px] text-slate-600 truncate">{tradeLabels[member.trade]}</p>
                  </div>
                </div>
              ))}
              {teamMembers.length === 0 && (
                <p className="text-xs text-slate-600 text-center py-4">No team members yet</p>
              )}
              {teamMembers.length > 3 && (
                <p className="text-xs text-slate-700 text-center pt-1">+{teamMembers.length - 3} more</p>
              )}
            </div>
          </div>
        </div>

        {/* Project Details */}
        {project?.scope_of_work && (
          <div className="bg-white border border-slate-800 rounded-2xl p-4">
            <h3 className="text-sm font-semibold text-slate-950 mb-2">Scope of Work</h3>
            <p className="text-xs text-slate-950 leading-relaxed">
              {project.scope_of_work}
            </p>
            {project?.house_plan_url && (
              <a 
                href={project.house_plan_url}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 flex items-center gap-2 p-2 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors text-xs"
              >
                <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center">
                  <FileText className="w-4 h-4 text-slate-700" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-slate-950">House Plans</p>
                  <p className="text-[11px] text-slate-600">Click to view</p>
                </div>
              </a>
            )}
          </div>
        )}

        {/* Rate this project - only available when project is completed */}
        {project?.status === 'completed' && (
          <div className="bg-white border border-slate-800 rounded-2xl p-4">
            <h3 className="text-sm font-semibold text-slate-950 mb-2">Rate this project</h3>
          <p className="text-xs text-slate-700 mb-3">
            Your feedback helps others understand who is good to work with.
          </p>

          <div className="flex items-center gap-1 mb-3">
            {[1, 2, 3, 4, 5].map((value) => (
              <button
                key={value}
                type="button"
                onClick={() => setRating(value)}
                className="p-1"
              >
                <Star
                  className={cn(
                    "w-5 h-5 transition-colors",
                    value <= rating ? "text-yellow-500 fill-yellow-500" : "text-slate-300"
                  )}
                />
              </button>
            ))}
          </div>

          <Textarea
            value={reviewComment}
            onChange={(e) => setReviewComment(e.target.value)}
            placeholder="Short comment (optional)…"
            className="mb-3 text-xs min-h-[60px] bg-white border-slate-300 text-slate-950"
            rows={3}
          />

          <Button
            size="sm"
            disabled={!rating || createReviewMutation.isPending}
            onClick={() =>
              createReviewMutation.mutate({
                project_id: projectId,
                reviewer_email: user?.email,
                reviewee_email: isGC ? selectedTradeEmail : project?.gc_email,
                reviewee_role: isGC ? "Trade" : "GC",
                rating,
                comment: reviewComment,
              })
            }
            className="h-8 rounded-full bg-sky-500 hover:bg-sky-600 text-xs"
          >
            {createReviewMutation.isPending ? "Submitting..." : "Submit rating"}
          </Button>

          {/* Show existing reviews */}
          {reviews.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-200">
              <div className="flex items-center gap-2 mb-3">
                <h4 className="text-xs font-semibold text-slate-950">Reviews</h4>
                <span className="inline-flex items-center gap-1 text-xs text-slate-700">
                  <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                  {(reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)}
                  <span className="text-slate-500">({reviews.length})</span>
                </span>
              </div>
              <div className="space-y-2">
                {reviews.slice(0, 5).map((review) => (
                  <div key={review.id} className="p-2 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={cn(
                              "w-3 h-3",
                              star <= review.rating
                                ? "text-yellow-500 fill-yellow-500"
                                : "text-slate-300"
                            )}
                          />
                        ))}
                      </div>
                      <span className="text-[10px] text-slate-500">
                        {format(new Date(review.created_date), "MMM d, yyyy")}
                      </span>
                    </div>
                    {review.comment && (
                      <p className="text-xs text-slate-700 leading-relaxed">{review.comment}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
            )}
          </div>
        )}
      </div>

      {/* Edit Sheet */}
      <Sheet open={showEditForm} onOpenChange={setShowEditForm}>
        <SheetContent className="sm:max-w-md overflow-y-auto bg-white border-slate-800">
          <ProjectForm
            project={project}
            onSubmit={(data) => updateMutation.mutate(data)}
            onCancel={() => setShowEditForm(false)}
            isLoading={updateMutation.isPending}
          />
          <div className="mt-6 pt-6 border-t border-slate-200">
            <Button 
              variant="destructive" 
              className="w-full"
              onClick={() => setShowDeleteDialog(true)}
            >
              Delete Project
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Delete Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-white border-slate-200">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-slate-950">Delete Project?</AlertDialogTitle>
            <AlertDialogDescription className="text-slate-700">
              This will permanently delete this project and all messages.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="bg-slate-100 text-slate-950 hover:bg-slate-200 border-slate-300">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => deleteMutation.mutate()}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}