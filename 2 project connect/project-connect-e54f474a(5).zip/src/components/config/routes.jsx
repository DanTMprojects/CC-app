export const APP_ROUTES = [
  { name: "Projects", path: "/Projects", label: "Projects", inNav: true },
  { name: "Directory", path: "/Directory", label: "Directory", inNav: true },
  { name: "BidBoard", path: "/BidBoard", label: "Bid board", inNav: true },
  { name: "Profile", path: "/Profile", label: "Profile", inNav: true },
  { name: "ProjectDetail", path: "/ProjectDetail" },
  { name: "DemoProject", path: "/DemoProject" },
];