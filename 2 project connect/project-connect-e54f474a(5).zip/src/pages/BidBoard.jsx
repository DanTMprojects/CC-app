import React, { useState, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { MapPin, DollarSign, User, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import BidBoardJobForm from "@/components/bidboard/BidBoardJobForm";
import BidSubmissionDialog from "@/components/bidboard/BidSubmissionDialog";
import BidManagementDialog from "@/components/bidboard/BidManagementDialog";

const TABS = [
  { id: "open", label: "Open jobs" },
  { id: "mine", label: "My posted jobs" },
];

const tradeLabels = {
  electrician: "Electrical",
  plumber: "Plumbing",
  carpenter: "Carpentry",
  hvac: "HVAC",
  painter: "Painting",
  roofer: "Roofing",
  mason: "Masonry",
  landscaper: "Landscaping",
  flooring: "Flooring",
  drywall: "Drywall",
  other: "Other"
};

function tradeColor(trade) {
  const t = trade.toLowerCase();
  if (t.includes("electric")) return "bg-yellow-100 text-yellow-800 border-yellow-300";
  if (t.includes("plumb")) return "bg-blue-100 text-blue-800 border-blue-300";
  if (t.includes("hvac") || t.includes("climate")) return "bg-cyan-100 text-cyan-800 border-cyan-300";
  if (t.includes("concrete")) return "bg-orange-100 text-orange-800 border-orange-300";
  if (t.includes("fram")) return "bg-amber-100 text-amber-800 border-amber-300";
  if (t.includes("paint")) return "bg-purple-100 text-purple-800 border-purple-300";
  if (t.includes("drywall")) return "bg-slate-100 text-slate-800 border-slate-300";
  return "bg-emerald-100 text-emerald-800 border-emerald-300";
}

export default function BidBoard() {
  const [activeTab, setActiveTab] = useState("open");
  const [user, setUser] = useState(null);
  const [showJobForm, setShowJobForm] = useState(false);
  const [showBidDialog, setShowBidDialog] = useState(false);
  const [showBidManagement, setShowBidManagement] = useState(false);
  const [selectedJob, setSelectedJob] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const isGC = user?.trade === 'general_contractor';

  const { data: projects = [], isLoading } = useQuery({
    queryKey: ['projects-bid-board'],
    queryFn: () => base44.entities.Project.list('-updated_date')
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list()
  });

  const { data: bids = [] } = useQuery({
    queryKey: ['bids'],
    queryFn: () => base44.entities.Bid.list('-created_date')
  });

  const createJobMutation = useMutation({
    mutationFn: (data) => base44.entities.Project.create({
      ...data,
      gc_email: user?.email
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects-bid-board'] });
      setShowJobForm(false);
      toast.success('Job posted to bid board');
    }
  });

  const createBidMutation = useMutation({
    mutationFn: (data) => base44.entities.Bid.create({
      ...data,
      bidder_email: user?.email,
      bidder_name: user?.full_name || user?.email
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bids'] });
      setShowBidDialog(false);
      setSelectedJob(null);
      toast.success('Bid submitted successfully');
    }
  });

  const updateBidMutation = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Bid.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bids'] });
      toast.success('Bid updated');
    }
  });

  const updateProjectMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Project.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['projects-bid-board'] });
      toast.success('Project updated');
    }
  });

  const requestToBidMutation = useMutation({
    mutationFn: (jobData) => base44.entities.Message.create({
      project_id: jobData.id,
      content: `${user?.full_name || user?.email} requested to bid on this job.`,
      author_name: user?.full_name || 'Trade',
      author_email: user?.email,
      message_type: 'private',
      trade_email: user?.email
    }),
    onSuccess: () => {
      toast.success('Request sent to GC');
    }
  });

  const jobItems = useMemo(() => {
    return (projects || [])
      .filter(p => p.is_bid_board_posting)
      .map((p) => {
        const gcUser = allUsers.find(u => u.email === p.gc_email);
        const projectBids = bids.filter(b => b.project_id === p.id);
        const userBid = projectBids.find(b => b.bidder_email === user?.email);
        
        return {
          id: p.id,
          title: p.name || "Untitled job",
          location: p.zip_code || "N/A",
          gcName: gcUser?.company || gcUser?.full_name || p.gc_email || "",
          tradesNeeded: (p.trades || []).map(t => tradeLabels[t] || t),
          scope: p.scope_of_work || "",
          bids_open: p.bids_open !== false,
          bid_count: projectBids.length,
          user_has_bid: !!userBid,
          isMine: p.gc_email === user?.email,
        };
      });
  }, [projects, user?.email, allUsers, bids]);

  const jobs = useMemo(() => {
    if (activeTab === "open") {
      return jobItems.filter((job) => job.bids_open && !job.isMine);
    }
    return jobItems.filter((job) => job.isMine);
  }, [activeTab, jobItems]);

  return (
    <div className="min-h-screen bg-slate-400 text-slate-950">
      <header className="bg-slate-400 border-b border-slate-800 backdrop-blur sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-slate-950 text-lg font-semibold">Bid board</h1>
            <div className="flex items-center gap-2">
              {isGC && (
                <Button 
                  onClick={() => setShowJobForm(true)}
                  size="sm"
                  className="bg-slate-900 hover:bg-slate-800 h-8 rounded-full text-xs"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Post Job
                </Button>
              )}
              {TABS.map((tab) => (
                <Button
                  key={tab.id}
                  size="sm"
                  variant={activeTab === tab.id ? "default" : "ghost"}
                  className={cn(
                    "h-8 rounded-full text-xs",
                    activeTab === tab.id
                      ? "bg-slate-900 hover:bg-slate-800 text-white"
                      : "text-slate-950 hover:bg-slate-300"
                  )}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.label}
                </Button>
              ))}
            </div>
          </div>

          <p className="text-xs text-slate-700">
            {activeTab === "open" 
              ? "Open jobs GCs are posting for trades to bid on."
              : "Jobs you've posted to the bid board."}
          </p>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-6">
        {isLoading ? (
          <div className="grid gap-4 sm:grid-cols-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-48 rounded-2xl bg-white border border-slate-300 animate-pulse" />
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <div className="py-16 text-center text-sm text-slate-700">
            {activeTab === "open" 
              ? "No open jobs at the moment. Check back soon!"
              : "You haven't posted any jobs yet."}
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2">
            {jobs.map((job) => (
              <article
                key={job.id}
                className="rounded-2xl border border-slate-300 bg-white p-4 text-sm shadow-sm hover:shadow-md transition-shadow"
              >
                <header className="mb-3">
                  <h2 className="font-semibold text-slate-950 mb-1">{job.title}</h2>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                    <span className="inline-flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-500" />
                      Zip: {job.location}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <User className="w-3 h-3 text-slate-500" />
                      {job.gcName}
                    </span>
                  </div>
                </header>

                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-slate-600 mb-1.5">Trades needed:</p>
                    <div className="flex flex-wrap gap-1.5">
                      {job.tradesNeeded.map((trade) => (
                        <Badge
                          key={trade}
                          className={cn(
                            "text-[11px] font-medium border",
                            tradeColor(trade)
                          )}
                        >
                          {trade}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {job.scope && (
                    <div className="text-xs text-slate-600 line-clamp-2">
                      {job.scope}
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200">
                  {job.bid_count > 0 && (
                    <p className="text-xs text-slate-600 mb-2">
                      {job.bid_count} {job.bid_count === 1 ? 'bid' : 'bids'} received
                    </p>
                  )}
                  
                  <div className="flex justify-end gap-2">
                    {job.isMine ? (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 rounded-full text-xs"
                          onClick={() => {
                            setSelectedJob(job);
                            setShowBidManagement(true);
                          }}
                        >
                          View bids
                        </Button>
                        <Button
                          size="sm"
                          variant={job.bids_open ? "outline" : "default"}
                          className="h-8 rounded-full text-xs"
                          onClick={() =>
                            updateProjectMutation.mutate({
                              id: job.id,
                              data: { bids_open: !job.bids_open },
                            })
                          }
                          disabled={updateProjectMutation.isPending}
                        >
                          {job.bids_open ? "Close bids" : "Open for bids"}
                        </Button>
                      </>
                    ) : (
                      <Button
                        size="sm"
                        className="h-8 rounded-full text-xs bg-sky-500 hover:bg-sky-600"
                        onClick={() => {
                          setSelectedJob(job);
                          setShowBidDialog(true);
                        }}
                        disabled={!job.bids_open || job.user_has_bid}
                      >
                        {!job.bids_open ? 'Bids closed' : job.user_has_bid ? 'Bid submitted' : 'Submit bid'}
                      </Button>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>

      {/* Post Job Sheet */}
      <Sheet open={showJobForm} onOpenChange={setShowJobForm}>
        <SheetContent className="sm:max-w-md overflow-y-auto">
          <BidBoardJobForm
            onSubmit={(data) => createJobMutation.mutate(data)}
            onCancel={() => setShowJobForm(false)}
            isLoading={createJobMutation.isPending}
          />
        </SheetContent>
      </Sheet>

      {/* Submit Bid Dialog */}
      <BidSubmissionDialog
        open={showBidDialog}
        onOpenChange={setShowBidDialog}
        onSubmit={(data) => createBidMutation.mutate({
          project_id: selectedJob?.id,
          ...data,
          amount: parseFloat(data.amount)
        })}
        isLoading={createBidMutation.isPending}
        jobTitle={selectedJob?.title}
      />

      {/* Bid Management Dialog */}
      <BidManagementDialog
        open={showBidManagement}
        onOpenChange={setShowBidManagement}
        job={selectedJob}
        bids={bids.filter(b => b.project_id === selectedJob?.id)}
        onUpdateBid={(bidId, status) => updateBidMutation.mutate({ id: bidId, status })}
        isLoading={updateBidMutation.isPending}
      />
    </div>
  );
}