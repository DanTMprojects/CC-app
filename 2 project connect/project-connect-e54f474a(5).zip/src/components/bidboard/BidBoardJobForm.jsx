import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const trades = [
  { value: "electrician", label: "Electrical" },
  { value: "plumber", label: "Plumbing" },
  { value: "carpenter", label: "Carpentry" },
  { value: "hvac", label: "HVAC" },
  { value: "painter", label: "Paint" },
  { value: "roofer", label: "Roofing" },
  { value: "mason", label: "Masonry" },
  { value: "landscaper", label: "Landscaping" },
  { value: "flooring", label: "Flooring" },
  { value: "drywall", label: "Drywall" },
  { value: "other", label: "Other" }
];

export default function BidBoardJobForm({ onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState({
    name: "",
    zip_code: "",
    scope_of_work: "",
    trades: [],
    is_bid_board_posting: true,
    bids_open: true
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addTrade = (trade) => {
    if (!formData.trades.includes(trade)) {
      setFormData({ ...formData, trades: [...formData.trades, trade] });
    }
  };

  const removeTrade = (trade) => {
    setFormData({ ...formData, trades: formData.trades.filter(t => t !== trade) });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-slate-900">Post Job to Bid Board</h2>
        <Button type="button" variant="ghost" size="icon" onClick={onCancel}>
          <X className="w-5 h-5" />
        </Button>
      </div>

      <div className="space-y-2">
        <Label htmlFor="name">Project Title *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          placeholder="e.g., Kitchen Remodel"
          required
          className="h-11"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="zip">Zip Code *</Label>
        <Input
          id="zip"
          value={formData.zip_code}
          onChange={(e) => setFormData({ ...formData, zip_code: e.target.value })}
          placeholder="e.g., 90210"
          required
          maxLength={10}
          className="h-11"
        />
        <p className="text-xs text-slate-500">Only zip code will be visible to bidders</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="scope">Scope of Work *</Label>
        <Textarea
          id="scope"
          value={formData.scope_of_work}
          onChange={(e) => setFormData({ ...formData, scope_of_work: e.target.value })}
          placeholder="Describe the work needed..."
          required
          className="min-h-[100px]"
        />
      </div>

      <div className="space-y-2">
        <Label>Trades Needed *</Label>
        <Select onValueChange={addTrade}>
          <SelectTrigger className="h-11">
            <SelectValue placeholder="Add a trade" />
          </SelectTrigger>
          <SelectContent>
            {trades.filter(t => !formData.trades.includes(t.value)).map((trade) => (
              <SelectItem key={trade.value} value={trade.value}>
                {trade.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {formData.trades.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.trades.map((trade) => (
              <Badge key={trade} variant="secondary" className="py-1 px-3">
                {trades.find(t => t.value === trade)?.label || trade}
                <button type="button" onClick={() => removeTrade(trade)} className="ml-2">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1 h-11">
          Cancel
        </Button>
        <Button 
          type="submit" 
          disabled={isLoading || formData.trades.length === 0} 
          className="flex-1 h-11 bg-slate-900 hover:bg-slate-800"
        >
          {isLoading ? "Posting..." : "Post Job"}
        </Button>
      </div>
    </form>
  );
}