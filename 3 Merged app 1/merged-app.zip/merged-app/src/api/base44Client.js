import { createClient } from '@base44/sdk';

/*
 * Base44 client
 *
 * Both of the original applications defined a hard‑coded `appId` when
 * instantiating the Base44 SDK. In a combined application the
 * identifier for your Base44 backend should not be compiled into the
 * source code. Instead, read it from an environment variable so it
 * can be configured per environment (development, staging, production).
 *
 * At build time Vite will replace `import.meta.env.VITE_BASE44_APP_ID` with
 * the value defined in your `.env` file. See `.env.example` in the root
 * of this repository for an example configuration.
 */

const appId = import.meta.env.VITE_BASE44_APP_ID;

// Create a client with authentication required. If you need to
// customise the Base44 client further (e.g. custom API URL) you can
// extend this configuration object.
export const base44 = createClient({
  appId,
  requiresAuth: true
});
