import React, { useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building2, User, Phone, Mail, MapPin, Globe, MessageSquare, Plus, Share2, ChevronLeft, ChevronRight, Briefcase, Users, X } from 'lucide-react';

const TRADE_LABELS = {
  general_contractor: 'General Contractor',
  electrician: 'Electrician',
  plumber: 'Plumber',
  hvac: 'HVAC',
  carpenter: 'Carpenter',
  roofer: 'Roofer',
  excavator: 'Excavator',
  painter: 'Painter',
  mason: 'Mason',
  landscaper: 'Landscaper',
  flooring: 'Flooring',
  drywall: 'Drywall',
  insulation: 'Insulation',
  siding: 'Siding',
  windows_doors: 'Windows & Doors',
  concrete: 'Concrete',
  framing: 'Framing',
  demolition: 'Demolition',
  tile: 'Tile',
  cabinetry: 'Cabinetry',
  other: 'Other'
};

export default function ProfileCardModal({ 
  profile, 
  isOpen, 
  onClose, 
  onMessage, 
  onAdd, 
  onRemove,
  onShare,
  isInRolodex 
}) {
  const [activeProject, setActiveProject] = useState(0);
  const [activePhoto, setActivePhoto] = useState(0);

  if (!profile) return null;

  const projects = profile.projects || [];
  const references = profile.references || [];
  const currentProject = projects[activeProject];

  const nextPhoto = () => {
    if (currentProject && activePhoto < currentProject.photos.length - 1) {
      setActivePhoto(activePhoto + 1);
    }
  };

  const prevPhoto = () => {
    if (activePhoto > 0) {
      setActivePhoto(activePhoto - 1);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg p-0 overflow-hidden rounded-2xl">
        {/* Header */}
        <div className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0">
              {profile.profile_photo_url ? (
                <img 
                  src={profile.profile_photo_url} 
                  alt={profile.company_name}
                  className="w-full h-full object-cover rounded-xl"
                />
              ) : (
                <Building2 className="w-7 h-7 text-white/60" />
              )}
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold">{profile.company_name}</h2>
              <p className="text-white/70 flex items-center gap-1.5 mt-0.5">
                <User className="w-3.5 h-3.5" />
                {profile.owner_name}
              </p>
              <Badge className="mt-2 bg-white/10 text-white border-0">
                {TRADE_LABELS[profile.trade_category]}
              </Badge>
            </div>
          </div>

          {profile.profile_bio && (
            <p className="mt-4 text-white/80 text-sm leading-relaxed">{profile.profile_bio}</p>
          )}

          <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
            <a href={`mailto:${profile.email}`} className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
              <Mail className="w-4 h-4" />
              {profile.email}
            </a>
            <a href={`tel:${profile.phone}`} className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
              <Phone className="w-4 h-4" />
              {profile.phone}
            </a>
            <div className="flex items-center gap-2 text-white/70">
              <MapPin className="w-4 h-4" />
              {profile.zip_code}
            </div>
            {profile.website_url && (
              <a href={profile.website_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-white/70 hover:text-white transition-colors">
                <Globe className="w-4 h-4" />
                Website
              </a>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <Tabs defaultValue="projects">
            <TabsList className="w-full bg-slate-100">
              <TabsTrigger value="projects" className="flex-1">
                <Briefcase className="w-4 h-4 mr-1.5" />
                Projects
              </TabsTrigger>
              <TabsTrigger value="references" className="flex-1">
                <Users className="w-4 h-4 mr-1.5" />
                References
              </TabsTrigger>
            </TabsList>

            <TabsContent value="projects" className="mt-4">
              {projects.length > 0 ? (
                <div className="space-y-4">
                  {/* Project Selector */}
                  <div className="flex gap-2">
                    {projects.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => { setActiveProject(idx); setActivePhoto(0); }}
                        className={`flex-1 h-1.5 rounded-full transition-colors ${
                          activeProject === idx ? 'bg-slate-900' : 'bg-slate-200'
                        }`}
                      />
                    ))}
                  </div>

                  {/* Photo Gallery */}
                  {currentProject && (
                    <>
                      <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-100">
                        <img
                          src={currentProject.photos[activePhoto]}
                          alt={`Project ${activeProject + 1} photo ${activePhoto + 1}`}
                          className="w-full h-full object-cover"
                        />
                        
                        {currentProject.photos.length > 1 && (
                          <>
                            <button
                              onClick={prevPhoto}
                              disabled={activePhoto === 0}
                              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center disabled:opacity-30"
                            >
                              <ChevronLeft className="w-4 h-4" />
                            </button>
                            <button
                              onClick={nextPhoto}
                              disabled={activePhoto === currentProject.photos.length - 1}
                              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center disabled:opacity-30"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </button>
                          </>
                        )}

                        <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/60 rounded-full text-xs text-white">
                          {activePhoto + 1} / {currentProject.photos.length}
                        </div>
                      </div>

                      <p className="text-sm text-slate-600">{currentProject.description}</p>
                    </>
                  )}
                </div>
              ) : (
                <p className="text-center text-slate-500 py-8">No projects added yet</p>
              )}
            </TabsContent>

            <TabsContent value="references" className="mt-4">
              {references.length > 0 ? (
                <div className="space-y-3">
                  {references.map((ref, idx) => (
                    <div key={idx} className="p-4 rounded-xl bg-slate-50">
                      <p className="font-medium text-slate-900">{ref.name}</p>
                      <div className="flex flex-wrap gap-3 mt-2 text-sm text-slate-500">
                        <a href={`tel:${ref.phone}`} className="flex items-center gap-1 hover:text-slate-700">
                          <Phone className="w-3.5 h-3.5" />
                          {ref.phone}
                        </a>
                        <a href={`mailto:${ref.email}`} className="flex items-center gap-1 hover:text-slate-700">
                          <Mail className="w-3.5 h-3.5" />
                          {ref.email}
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-slate-500 py-8">No references added yet</p>
              )}
            </TabsContent>
          </Tabs>
        </div>

        {/* Actions */}
        <div className="p-4 border-t border-slate-100 flex gap-2">
          <Button 
            onClick={() => onMessage(profile)}
            className="flex-1 h-11 bg-slate-900 hover:bg-slate-800"
          >
            <MessageSquare className="w-4 h-4 mr-2" />
            Message
          </Button>
          {isInRolodex ? (
            <Button 
              onClick={() => onRemove(profile)}
              variant="outline"
              className="h-11 border-red-200 text-red-600 hover:bg-red-50"
            >
              <X className="w-4 h-4 mr-2" />
              Remove
            </Button>
          ) : (
            <Button 
              onClick={() => onAdd(profile)}
              variant="outline"
              className="h-11 border-slate-200"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add
            </Button>
          )}
          <Button 
            onClick={() => onShare(profile)}
            variant="outline"
            className="h-11 border-slate-200"
          >
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}