﻿namespace CompanyCam.Models
{
    public enum Status
    {
        Active,
        Deleted
    }
}
