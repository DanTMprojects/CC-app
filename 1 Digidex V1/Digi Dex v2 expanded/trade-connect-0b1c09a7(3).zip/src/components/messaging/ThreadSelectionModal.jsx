import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { MapPin, MessageSquare, Plus } from 'lucide-react';
import moment from 'moment';

export default function ThreadSelectionModal({ 
  isOpen, 
  onClose, 
  contactProfile, 
  threads, 
  onSelectThread,
  onNewThread 
}) {
  if (!contactProfile) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">
            Messages with {contactProfile.company_name}
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          {threads.length > 0 ? (
            <div className="space-y-2 mb-4">
              <p className="text-sm text-slate-500 mb-3">Select a project conversation:</p>
              {threads.map((thread) => (
                <button
                  key={thread.id}
                  onClick={() => onSelectThread(thread)}
                  className="w-full p-4 rounded-xl border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition-all text-left"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-slate-900 flex items-center gap-1.5 mb-1">
                        <MapPin className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        <span className="truncate">{thread.project_name}</span>
                      </p>
                      {thread.last_message && (
                        <p className="text-sm text-slate-500 truncate">
                          {thread.last_message}
                        </p>
                      )}
                    </div>
                    {thread.last_message_at && (
                      <span className="text-xs text-slate-400 flex-shrink-0 mt-0.5">
                        {moment(thread.last_message_at).fromNow()}
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <p className="text-sm text-slate-500 mb-4">No existing conversations with this contact.</p>
          )}

          <Button
            onClick={onNewThread}
            className="w-full h-12 bg-slate-900 hover:bg-slate-800"
          >
            <Plus className="w-4 h-4 mr-2" />
            Start New Project Chat
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}