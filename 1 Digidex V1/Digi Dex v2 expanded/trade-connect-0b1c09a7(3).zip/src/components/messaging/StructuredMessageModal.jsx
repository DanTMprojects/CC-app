import React, { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const TYPE_CONFIG = {
  quote: {
    title: 'Send Quote',
    badge: 'QUOTE',
    accent: 'text-amber-600 bg-amber-50',
    amountLabel: 'Quote amount',
    showAmount: true,
    showDueDate: false,
    showLocation: false,
    showAssignee: false,
    help: 'Create a clear quote with title, amount, and scope/notes.',
  },
  change_order: {
    title: 'Send Change Order',
    badge: 'CHANGE ORDER',
    accent: 'text-blue-600 bg-blue-50',
    amountLabel: 'Change amount (+ / -)',
    showAmount: true,
    showDueDate: false,
    showLocation: false,
    showAssignee: false,
    help: 'Use for scope or price changes. Amount can be positive or negative.',
  },
  invoice: {
    title: 'Send Invoice',
    badge: 'INVOICE',
    accent: 'text-emerald-600 bg-emerald-50',
    amountLabel: 'Invoice total',
    showAmount: true,
    showDueDate: true,
    showLocation: false,
    showAssignee: false,
    help: 'Send a simple invoice with title, amount, and due date.',
  },
  punch_item: {
    title: 'Create Punch Item',
    badge: 'PUNCH',
    accent: 'text-sky-600 bg-sky-50',
    amountLabel: '',
    showAmount: false,
    showDueDate: true,
    showLocation: true,
    showAssignee: true,
    help: 'Use punch items to track small fixes and final walkthrough items per project.',
  },
};

export default function StructuredMessageModal({
  type,        // 'quote' | 'change_order' | 'invoice' | 'punch_item'
  isOpen,
  onClose,
  onSubmit,
  contactName,
}) {
  const config = type ? TYPE_CONFIG[type] : null;

  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [assignee, setAssignee] = useState('');
  const [images, setImages] = useState([]);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!isOpen || !type) return;
    // reset form when opened / type changes
    setTitle('');
    setAmount('');
    setDueDate('');
    setDescription('');
    setLocation('');
    setAssignee(type === 'punch_item' ? (contactName || '') : '');
    setImages([]);
    setUploading(false);
  }, [isOpen, type, contactName]);

  if (!isOpen || !type || !config) return null;

  const handleImageUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploading(true);
    try {
      const { base44 } = await import('@/api/base44Client');
      const uploadPromises = files.map(file => 
        base44.integrations.Core.UploadFile({ file })
      );
      const results = await Promise.all(uploadPromises);
      const urls = results.map(r => r.file_url);
      setImages(prev => [...prev, ...urls]);
    } catch (err) {
      console.error(err);
      alert('Failed to upload images. Please try again.');
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const removeImage = (index) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    let payload;

    if (type === 'quote') {
      const numericAmount = Number(amount || 0);
      payload = {
        type: 'quote',
        title: title.trim(),
        amount: isNaN(numericAmount) ? 0 : numericAmount,
        description: description.trim(),
      };
    } else if (type === 'change_order') {
      const numericAmount = Number(amount || 0);
      payload = {
        type: 'change_order',
        title: title.trim(),
        deltaAmount: isNaN(numericAmount) ? 0 : numericAmount,
        description: description.trim(),
      };
    } else if (type === 'invoice') {
      const numericAmount = Number(amount || 0);
      payload = {
        type: 'invoice',
        title: title.trim(),
        amount: isNaN(numericAmount) ? 0 : numericAmount,
        dueDate: dueDate.trim(),
        description: description.trim(),
        status: 'unpaid',
      };
    } else if (type === 'punch_item') {
      payload = {
        type: 'punch_item',
        title: title.trim(),
        location: location.trim(),
        assigneeName: assignee.trim(),
        dueDate: dueDate.trim(),
        status: 'open',
        description: description.trim(),
        images: images,
      };
    }

    onSubmit?.(payload);
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/40 px-4">
      <div className="w-full max-w-md rounded-2xl bg-white shadow-xl border border-slate-200">
        {/* Header */}
        <div className="px-5 pt-4 pb-3 border-b border-slate-100 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold tracking-wide uppercase text-slate-400">
              {contactName ? `To: ${contactName}` : 'Project Conversation'}
            </p>
            <h2 className="text-base font-semibold text-slate-900">
              {config.title}
            </h2>
          </div>
          <span
            className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${config.accent}`}
          >
            {config.badge}
          </span>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="px-5 py-4 space-y-3">
          {/* Title */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-600">
              Title<span className="text-rose-500">*</span>
            </label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                type === 'quote'
                  ? 'Electrical rough-in – main house'
                  : type === 'change_order'
                  ? 'Lighting scope increase – can lights'
                  : type === 'invoice'
                  ? 'Invoice – 115 electrical final'
                  : 'Fix GFCI in master bath'
              }
            />
          </div>

          {/* Amount (for quote / change_order / invoice) */}
          {config.showAmount && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                {config.amountLabel}
              </label>
              <div className="flex items-center gap-1.5">
                <span className="text-sm text-slate-400">$</span>
                <Input
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder={
                    type === 'change_order' ? '500 or -250' : '4500'
                  }
                />
              </div>
            </div>
          )}

          {/* Location (punch only) */}
          {config.showLocation && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Location (optional)
              </label>
              <Input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Master bath – vanity wall"
              />
            </div>
          )}

          {/* Assignee (punch only) */}
          {config.showAssignee && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Assigned to (optional)
              </label>
              <Input
                value={assignee}
                onChange={(e) => setAssignee(e.target.value)}
                placeholder={contactName || 'Trade / company name'}
              />
            </div>
          )}

          {/* Due date (invoice + punch) */}
          {config.showDueDate && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Due date
              </label>
              <Input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </div>
          )}

          {/* Description / details */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-600">
              {type === 'punch_item'
                ? 'Details / notes (optional)'
                : 'Details / scope (optional)'}
            </label>
            <textarea
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 resize-y min-h-[80px] focus:outline-none focus:ring-2 focus:ring-slate-900/10 focus:border-slate-400"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={
                type === 'quote'
                  ? 'Outline what is included in this quote...'
                  : type === 'change_order'
                  ? 'Describe the change to scope, materials, or price...'
                  : type === 'invoice'
                  ? 'Add notes about this invoice, payment terms, etc...'
                  : 'Describe exactly what needs to be fixed or completed...'
              }
            />
          </div>

          {/* Images (punch only) */}
          {type === 'punch_item' && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600">
                Photos (optional)
              </label>
              <div className="space-y-2">
                {images.length > 0 && (
                  <div className="grid grid-cols-3 gap-2">
                    {images.map((url, index) => (
                      <div key={index} className="relative group">
                        <img 
                          src={url} 
                          alt=""
                          className="w-full h-20 object-cover rounded-lg border border-slate-200"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-1 right-1 w-5 h-5 bg-slate-900/80 hover:bg-slate-900 text-white rounded-full flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <label className="flex items-center justify-center gap-2 w-full h-10 border-2 border-dashed border-slate-200 rounded-lg hover:border-slate-300 hover:bg-slate-50 transition-colors cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    disabled={uploading}
                    className="hidden"
                  />
                  <span className="text-sm text-slate-500">
                    {uploading ? 'Uploading...' : 'Add photos'}
                  </span>
                </label>
              </div>
            </div>
          )}

          <p className="text-[11px] text-slate-400 pt-1">
            {config.help}
          </p>

          <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100 mt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-8 px-3 text-xs"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              size="sm"
              className="h-8 px-4 text-xs bg-slate-900 hover:bg-slate-800"
            >
              Send
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}