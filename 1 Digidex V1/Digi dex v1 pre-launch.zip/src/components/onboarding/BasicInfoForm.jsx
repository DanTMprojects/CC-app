import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { ArrowRight, Building2, User, Globe, Mail, Phone, MapPin } from 'lucide-react';

const TRADE_CATEGORIES = [
  { value: 'general_contractor', label: 'General Contractor' },
  { value: 'electrician', label: 'Electrician' },
  { value: 'plumber', label: 'Plumber' },
  { value: 'hvac', label: 'HVAC' },
  { value: 'carpenter', label: 'Carpenter' },
  { value: 'roofer', label: 'Roofer' },
  { value: 'excavator', label: 'Excavator' },
  { value: 'painter', label: 'Painter' },
  { value: 'mason', label: 'Mason' },
  { value: 'landscaper', label: 'Landscaper' },
  { value: 'flooring', label: 'Flooring' },
  { value: 'drywall', label: 'Drywall' },
  { value: 'insulation', label: 'Insulation' },
  { value: 'siding', label: 'Siding' },
  { value: 'windows_doors', label: 'Windows & Doors' },
  { value: 'concrete', label: 'Concrete' },
  { value: 'framing', label: 'Framing' },
  { value: 'demolition', label: 'Demolition' },
  { value: 'tile', label: 'Tile' },
  { value: 'cabinetry', label: 'Cabinetry' },
  { value: 'other', label: 'Other' }
];

export default function BasicInfoForm({ data, onChange, onNext }) {
  const isValid = data.company_name && data.owner_name && data.email && data.phone && data.zip_code && data.trade_category;

  const handleChange = (field, value) => {
    onChange({ ...data, [field]: value });
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-semibold text-slate-900">Tell us about your business</h2>
        <p className="text-slate-500 mt-2">This information will appear on your Rolodex card</p>
      </div>

      <div className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="space-y-2">
            <Label htmlFor="company_name" className="flex items-center gap-2 text-slate-700">
              <Building2 className="w-4 h-4" /> Company Name *
            </Label>
            <Input
              id="company_name"
              value={data.company_name || ''}
              onChange={(e) => handleChange('company_name', e.target.value)}
              placeholder="Your company name"
              className="h-12 bg-slate-50 border-slate-200 focus:bg-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="owner_name" className="flex items-center gap-2 text-slate-700">
              <User className="w-4 h-4" /> Owner Name *
            </Label>
            <Input
              id="owner_name"
              value={data.owner_name || ''}
              onChange={(e) => handleChange('owner_name', e.target.value)}
              placeholder="Your full name"
              className="h-12 bg-slate-50 border-slate-200 focus:bg-white"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="trade_category" className="text-slate-700">Trade Category *</Label>
          <Select
            value={data.trade_category || ''}
            onValueChange={(value) => handleChange('trade_category', value)}
          >
            <SelectTrigger className="h-12 bg-slate-50 border-slate-200">
              <SelectValue placeholder="Select your trade" />
            </SelectTrigger>
            <SelectContent>
              {TRADE_CATEGORIES.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>
                  {cat.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="space-y-2">
            <Label htmlFor="email" className="flex items-center gap-2 text-slate-700">
              <Mail className="w-4 h-4" /> Email *
            </Label>
            <Input
              id="email"
              type="email"
              value={data.email || ''}
              onChange={(e) => handleChange('email', e.target.value)}
              placeholder="email@company.com"
              className="h-12 bg-slate-50 border-slate-200 focus:bg-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone" className="flex items-center gap-2 text-slate-700">
              <Phone className="w-4 h-4" /> Phone *
            </Label>
            <Input
              id="phone"
              value={data.phone || ''}
              onChange={(e) => handleChange('phone', e.target.value)}
              placeholder="(555) 123-4567"
              className="h-12 bg-slate-50 border-slate-200 focus:bg-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="space-y-2">
            <Label htmlFor="zip_code" className="flex items-center gap-2 text-slate-700">
              <MapPin className="w-4 h-4" /> Zip Code *
            </Label>
            <Input
              id="zip_code"
              value={data.zip_code || ''}
              onChange={(e) => handleChange('zip_code', e.target.value)}
              placeholder="12345"
              className="h-12 bg-slate-50 border-slate-200 focus:bg-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="website_url" className="flex items-center gap-2 text-slate-700">
              <Globe className="w-4 h-4" /> Website (optional)
            </Label>
            <Input
              id="website_url"
              value={data.website_url || ''}
              onChange={(e) => handleChange('website_url', e.target.value)}
              placeholder="https://yourcompany.com"
              className="h-12 bg-slate-50 border-slate-200 focus:bg-white"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="profile_bio" className="text-slate-700">
            Bio ({(data.profile_bio || '').length}/180)
          </Label>
          <Textarea
            id="profile_bio"
            value={data.profile_bio || ''}
            onChange={(e) => {
              if (e.target.value.length <= 180) {
                handleChange('profile_bio', e.target.value);
              }
            }}
            placeholder="Tell others about your business and expertise..."
            className="min-h-[100px] bg-slate-50 border-slate-200 focus:bg-white resize-none"
          />
        </div>
      </div>

      <div className="pt-4">
        <Button
          onClick={onNext}
          disabled={!isValid}
          className="w-full h-12 bg-slate-900 hover:bg-slate-800 text-white font-medium"
        >
          Continue
          <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}