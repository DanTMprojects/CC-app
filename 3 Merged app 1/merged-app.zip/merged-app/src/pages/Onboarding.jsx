import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import OnboardingProgress from '@/components/onboarding/OnboardingProgress';
import PathSelectionForm from '@/components/onboarding/PathSelectionForm';
import BasicInfoForm from '@/components/onboarding/BasicInfoForm';
import ProjectsForm from '@/components/onboarding/ProjectsForm';
import ReferencesForm from '@/components/onboarding/ReferencesForm';
import ReviewForm from '@/components/onboarding/ReviewForm';

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    company_name: '',
    owner_name: '',
    website_url: '',
    email: '',
    phone: '',
    business_address: '',
    zip_code: '',
    service_radius: null,
    trade_category: '',
    gc_main_category: '',
    gc_license_number: '',
    gc_license_state: '',
    trade_tags: [],
    profile_bio: '',
    projects: [
      { photos: [], description: '' },
      { photos: [], description: '' },
      { photos: [], description: '' }
    ],
    references: [
      { name: '', phone: '', email: '' },
      { name: '', phone: '', email: '' },
      { name: '', phone: '', email: '' }
    ]
  });

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    const user = await base44.auth.me();
    if (user) {
      setFormData(prev => ({
        ...prev,
        email: user.email || prev.email,
        owner_name: user.full_name || prev.owner_name
      }));
    }

    // Check for invite code in URL
    const urlParams = new URLSearchParams(window.location.search);
    const inviteCode = urlParams.get('invite');
    if (inviteCode) {
      setFormData(prev => ({ ...prev, invited_by: inviteCode }));
    }
  };

  const generateInviteCode = () => {
    return Math.random().toString(36).substring(2, 10).toUpperCase();
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    const user = await base44.auth.me();
    const inviteCode = generateInviteCode();

    // Create the trade profile
    const profile = await base44.entities.TradeProfile.create({
      ...formData,
      onboarding_complete: true,
      invite_code: inviteCode
    });

    // If invited by someone, create mutual connections
    if (formData.invited_by) {
      const inviterProfiles = await base44.entities.TradeProfile.filter({
        invite_code: formData.invited_by
      });
      
      if (inviterProfiles.length > 0) {
        const inviter = inviterProfiles[0];
        
        // Add inviter to new user's rolodex
        await base44.entities.RolodexConnection.create({
          owner_user_id: user.id,
          contact_user_id: inviter.created_by,
          contact_profile_id: inviter.id,
          connection_type: 'invited'
        });

        // Add new user to inviter's rolodex
        await base44.entities.RolodexConnection.create({
          owner_user_id: inviter.created_by,
          contact_user_id: user.id,
          contact_profile_id: profile.id,
          connection_type: 'invited'
        });
      }
    }

    navigate(createPageUrl('Dashboard'));
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-2xl mx-auto px-4 py-8">
        {/* Logo */}
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">TradeRolodex</h1>
        </div>

{step > 0 && <OnboardingProgress currentStep={step} />}

        <div className="mt-8">
          {step === 0 && (
            <PathSelectionForm
              onSelect={(path) => {
                setFormData(prev => ({ 
                  ...prev, 
                  trade_category: path === 'general_contractor' ? 'general_contractor' : ''
                }));
                setStep(1);
              }}
            />
          )}
          {step === 1 && (
            <BasicInfoForm
              data={formData}
              onChange={setFormData}
              onNext={() => setStep(2)}
              onBack={() => setStep(0)}
            />
          )}
          {step === 2 && (
            <ProjectsForm
              data={formData}
              onChange={setFormData}
              onNext={() => setStep(3)}
              onBack={() => setStep(1)}
            />
          )}
          {step === 3 && (
            <ReferencesForm
              data={formData}
              onChange={setFormData}
              onNext={() => setStep(4)}
              onBack={() => setStep(2)}
            />
          )}
          {step === 4 && (
            <ReviewForm
              data={formData}
              onBack={() => setStep(3)}
              onSubmit={handleSubmit}
              isSubmitting={isSubmitting}
            />
          )}
        </div>
      </div>
    </div>
  );
}